# Averos
#### _the ultimate Rapid Responsive Web Application Development framework_

<br/>

<p align="center">
<img width="400" height="350" src="https://www.wiforge.com/assets/logo/averos.svg">
<br/> 


  <img src="https://img.shields.io/badge/averos-v1.8.1-blue">
    <img src="https://img.shields.io/badge/poweredby-angular-red">
</p>

<br/>

## Overview

**Averos** framework is the ultimate [Rapid Application Development](https://en.wikipedia.org/wiki/Rapid_application_development), LowCode & NoCode, fully [responsive](https://en.wikipedia.org/wiki/Responsive_web_design) [Angular](https://angular.io/)-powered web application development framework that is aimed to simplify enterprise web application development while hiding complex technical aspects; providing a full control on [time to market (TTM)](https://en.wikipedia.org/wiki/Time_to_market).
Averos let you create a fully angular blown, multi-purpose and highly responsive enterprise applications in only five steps: Design, Integrate, Customize, build and Deploy.
<br><br>

## Features
- generate applications with multiple language support (11 languages out of the box)
- generate application that are translatable to its finest view detail (11 languages out of the box)
- define your components validation workflow
- customize and internationalize your validation messages
- generate customizable menu
- full angular 12/13/14/15/16/17 support
- intelligent/multipurposes reusable atomic components
- complex various reusable CRUD use cases
- extendable components
- composable components for rich use cases
- optimized components
- complex components generation (nocode)
- complex use cases generation (nocode)
- customizable component view layout
- customizable use case view layout
- light / dark mode support
- fully responsive components
- scalable architecture
- microservice architecture compliant
- leverage command lines for basic application components and workflows development : add new entities, create entities relations, create use cases, add new language support, add translation records, create and assign services...
- leverage `averos designer` capabilities for NoCode application development by installing [Wibuild](https://appbuilder.wiforge.com/) application either on mobile or on desktop devices
- and much more...

## Benefits
- create stunning responsive web application in a jiffy
- focus on business logic rather than technical aspects
- leverage all angular benefits
- efficient control of time to market (TTM)
- backend agnostic
- build scalable applications
- leverage an intuitive user interface design powered by angular material, html5 and CSS
- target multiple languages by leveraging averos translation capabilities
- leverage **averos designer** for NoCode application development
- and much more...


## Installation

 `npm install @wiforge/averos` 

## Create your first application

Please refer to the [averos application Tutorials for Developers and Citizen Developers ](https://www.wiforge.com). 

