"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const schema_1 = require("./schema");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:averos-config"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup ////////////
        if (!options.id || options.id.trim() === '') {
            if (options.type === 'gateway') {
                options.id = 'APIServiceGateway';
            }
            else {
                throw new schematics_1.SchematicsException(`Configuration ID is mandatory! Please provide one`);
            }
        }
        if (!options.type || options.type.trim() === '') {
            throw new schematics_1.SchematicsException(`Configuration type is mandatory! Please provide one`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
        }
        return (0, schematics_1.chain)([
            options.type === 'service' ? (0, schematics_1.schematic)('service-config', getServiceConfigurationOptions(options)) : (0, schematics_1.noop)(),
            options.type === 'gateway' ? (0, schematics_1.schematic)('gateway-config', getGatewayConfigurationOptions(options)) : (0, schematics_1.noop)(),
        ]);
    };
}
function getServiceConfigurationOptions(options) {
    let serviceConfigOptions = new schema_1.ServiceConfigurationOption();
    serviceConfigOptions.type = options.type;
    if (isNotNull(options.id)) {
        serviceConfigOptions.id = (options.id);
    }
    if (isNotNull(options.host)) {
        serviceConfigOptions.apiHost = options.host;
    }
    if (isNotNull(options.port)) {
        serviceConfigOptions.apiPort = options.port;
    }
    if (isNotNull(options.protocol)) {
        serviceConfigOptions.apiProtocol = options.protocol;
    }
    if (isNotNull(options.endPoint)) {
        serviceConfigOptions.apiEndPoint = options.endPoint;
    }
    if (isNotNull(options.httpQueryBuilder)) {
        serviceConfigOptions.apiHTTPQueryBuilder = options.httpQueryBuilder;
    }
    if (isNotNull(options.externalEntityId)) {
        serviceConfigOptions.externalEntityId = options.externalEntityId;
    }
    return serviceConfigOptions;
}
function getGatewayConfigurationOptions(options) {
    let gatewayConfigOptions = new schema_1.GatewayConfigurationOption();
    gatewayConfigOptions.type = options.type;
    if (isNotNull(options.id)) {
        gatewayConfigOptions.id = (options.id);
    }
    if (isNotNull(options.host)) {
        gatewayConfigOptions.gatewayHost = options.host;
    }
    if (isNotNull(options.port)) {
        gatewayConfigOptions.gatewayPort = options.port;
    }
    if (isNotNull(options.protocol)) {
        gatewayConfigOptions.gatewayProtocol = options.protocol;
    }
    if (isNotNull(options.protocol)) {
        gatewayConfigOptions.gatewayProtocol = options.protocol;
    }
    if (isNotNull(options.endPoint) && isNotNull(options.endPoint)) {
        gatewayConfigOptions.endpoint = options.endPoint;
        gatewayConfigOptions.endpointId = options.endPointId;
        if (isNotNull(options.httpQueryBuilder) && isNotNull(options.httpQueryBuilder)) {
            gatewayConfigOptions.queryBuilder = options.httpQueryBuilder;
        }
        if (isNotNull(options.externalEntityId) && isNotNull(options.externalEntityId)) {
            gatewayConfigOptions.externalEntityId = options.externalEntityId;
        }
    }
    return gatewayConfigOptions;
}
function isNotNull(option) {
    if (typeof option === 'number') {
        return (option !== 0);
    }
    else if (typeof option === 'string') {
        return (option !== null && option.trim() !== '');
    }
    else {
        return (option !== null);
    }
}
//# sourceMappingURL=index.js.map