"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.createApiServiceConfiguration = createApiServiceConfiguration;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const workspace_1 = require("@schematics/angular/utility/workspace");
const util_1 = require("../util");
function default_1(serviceConfigOptions) {
    return async (host, context) => {
        /// Option Setup ////////////
        if (!serviceConfigOptions.id || serviceConfigOptions.id.trim() === '') {
            throw new schematics_1.SchematicsException(`Configuration ID is mandatory! Please provide one`);
        }
        if (!serviceConfigOptions.type || serviceConfigOptions.type.trim() === '') {
            throw new schematics_1.SchematicsException(`Configuration type is mandatory! Please provide one`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!serviceConfigOptions.project) {
            serviceConfigOptions.project = workspace.projects.keys().next().value;
            if (!serviceConfigOptions.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${serviceConfigOptions.project}`);
        const project = workspace.projects.get(serviceConfigOptions.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${serviceConfigOptions.project}`);
        }
        serviceConfigOptions.projectRootPath = `${project.root}/`;
        if (serviceConfigOptions.path === undefined) {
            serviceConfigOptions.path = (0, workspace_1.buildDefaultPath)(project);
        }
        ///// End Options Setup
        return (0, schematics_1.chain)([
            createApiServiceConfiguration(serviceConfigOptions)
        ]);
    };
}
function createApiServiceConfiguration(serviceConfigOptions) {
    return async (host, context) => {
        let environmentConfigurationLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(serviceConfigOptions.projectRootPath), `src/assets/environment/`));
        let dirEntry = host.getDir(environmentConfigurationLocation);
        let envConfigurationFileDirEntry = dirEntry.subfiles.find(e => e === `env-config.json`);
        let serviceConfigurationFile;
        if (!envConfigurationFileDirEntry) {
            serviceConfigurationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), `env-config.json`));
        }
        else {
            serviceConfigurationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), envConfigurationFileDirEntry));
        }
        if (!host.exists(serviceConfigurationFile)) {
            /// create the file if it does not exist
            let envConfig = new util_1.EnvironmentConfiguration();
            host.create(serviceConfigurationFile, JSON.stringify(envConfig));
        }
        let serviceConfigurationContent = host.read(serviceConfigurationFile);
        if (!serviceConfigurationContent) {
            throw new Error(`❌ No Service configuration found for the language for your application!`);
        }
        let serviceConfigData = JSON.parse(serviceConfigurationContent.toString());
        updateServiceConfiguration(serviceConfigData, serviceConfigOptions);
        host.overwrite(serviceConfigurationFile, JSON.stringify(serviceConfigData));
        context.logger.info(`✅ The requested service configuration entry has been added/updated successfully!`);
    };
}
function updateServiceConfiguration(srvConfigData, serviceConfigOptions) {
    let serviceConfigItem = srvConfigData.configurationItems.find(e => e.type === 'service' && e.id === serviceConfigOptions.id);
    if (isNull(serviceConfigItem)) { // a new entry
        let serviceConfigItem_ = new util_1.ServiceConfigurationItem();
        serviceConfigItem_.id = serviceConfigOptions.id;
        serviceConfigItem_.type = 'service';
        if (!isNull(serviceConfigOptions.apiHost) && serviceConfigOptions.apiHost !== undefined) {
            serviceConfigItem_.apiHost = serviceConfigOptions.apiHost;
        }
        if (!isNull(serviceConfigOptions.apiPort) && serviceConfigOptions.apiPort !== undefined) {
            serviceConfigItem_.apiPort = serviceConfigOptions.apiPort;
        }
        if (!isNull(serviceConfigOptions.apiProtocol) && serviceConfigOptions.apiProtocol !== undefined) {
            serviceConfigItem_.apiProtocol = serviceConfigOptions.apiProtocol;
        }
        if (!isNull(serviceConfigOptions.apiHTTPQueryBuilder) && serviceConfigOptions.apiHTTPQueryBuilder !== undefined) {
            serviceConfigItem_.apiHTTPQueryBuilder = serviceConfigOptions.apiHTTPQueryBuilder;
        }
        if (!isNull(serviceConfigOptions.apiEndPoint) && serviceConfigOptions.apiEndPoint !== undefined) {
            serviceConfigItem_.apiEndPoint = serviceConfigOptions.apiEndPoint;
        }
        if (!isNull(serviceConfigOptions.externalEntityId) && serviceConfigOptions.externalEntityId !== undefined) {
            serviceConfigItem_.externalEntityId = serviceConfigOptions.externalEntityId;
        }
        srvConfigData.configurationItems.push(serviceConfigItem_);
        return srvConfigData;
    }
    else { // an update
        let serviceConfigItem_ = serviceConfigItem;
        if (!isNull(serviceConfigOptions.apiHost) && serviceConfigOptions.apiHost !== undefined) {
            serviceConfigItem_.apiHost = serviceConfigOptions.apiHost;
        }
        if (!isNull(serviceConfigOptions.apiPort) && serviceConfigOptions.apiPort !== undefined) {
            serviceConfigItem_.apiPort = serviceConfigOptions.apiPort;
        }
        if (!isNull(serviceConfigOptions.apiProtocol) && serviceConfigOptions.apiProtocol !== undefined) {
            serviceConfigItem_.apiProtocol = serviceConfigOptions.apiProtocol;
        }
        if (!isNull(serviceConfigOptions.apiHTTPQueryBuilder) && serviceConfigOptions.apiHTTPQueryBuilder !== undefined) {
            serviceConfigItem_.apiHTTPQueryBuilder = serviceConfigOptions.apiHTTPQueryBuilder;
        }
        if (!isNull(serviceConfigOptions.apiEndPoint) && serviceConfigOptions.apiEndPoint !== undefined) {
            serviceConfigItem_.apiEndPoint = serviceConfigOptions.apiEndPoint;
        }
        if (!isNull(serviceConfigOptions.externalEntityId) && serviceConfigOptions.externalEntityId !== undefined) {
            serviceConfigItem_.externalEntityId = serviceConfigOptions.externalEntityId;
        }
        srvConfigData.configurationItems.splice(srvConfigData.configurationItems.indexOf(serviceConfigItem), 1);
        srvConfigData.configurationItems.push(serviceConfigItem_);
        return srvConfigData;
    }
}
function isNull(object) {
    if (object === null
        || object === undefined
        || (object instanceof Array && object.length === 0)
        || (typeof object === 'string' && object.trim() === '')
        || (typeof object === 'number' && object === 0)) {
        return true;
    }
    else {
        return false;
    }
}
//# sourceMappingURL=service-config.js.map