"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.createApiGatewayConfiguration = createApiGatewayConfiguration;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const workspace_1 = require("@schematics/angular/utility/workspace");
const util_1 = require("../util");
function default_1(gatewayConfigOptions) {
    return async (host, context) => {
        //  /// Option Setup ////////////
        //   if (!gatewayConfigOptions.id || gatewayConfigOptions.id.trim() === '') {
        //   throw new SchematicsException(`Configuration ID is mandatory! Please provide one`);
        //  }
        if (!gatewayConfigOptions.type || gatewayConfigOptions.type.trim() === '') {
            throw new schematics_1.SchematicsException(`Configuration type is mandatory! Please provide one`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!gatewayConfigOptions.project) {
            gatewayConfigOptions.project = workspace.projects.keys().next().value;
            if (!gatewayConfigOptions.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${gatewayConfigOptions.project}`);
        const project = workspace.projects.get(gatewayConfigOptions.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${gatewayConfigOptions.project}`);
        }
        gatewayConfigOptions.projectRootPath = `${project.root}/`;
        if (gatewayConfigOptions.path === undefined) {
            gatewayConfigOptions.path = (0, workspace_1.buildDefaultPath)(project);
        }
        gatewayConfigOptions.id = 'APIServiceGateway';
        return (0, schematics_1.chain)([
            createApiGatewayConfiguration(gatewayConfigOptions)
        ]);
    };
}
function createApiGatewayConfiguration(gatewayConfigOptions) {
    return async (host, context) => {
        let environmentConfigurationLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(gatewayConfigOptions.projectRootPath), `src/assets/environment/`));
        let dirEntry = host.getDir(environmentConfigurationLocation);
        let envConfigurationFileDirEntry = dirEntry.subfiles.find(e => e === `env-config.json`);
        let gatewayConfigurationFile;
        if (!envConfigurationFileDirEntry) {
            gatewayConfigurationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), `env-config.json`));
        }
        else {
            gatewayConfigurationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), envConfigurationFileDirEntry));
        }
        if (!host.exists(gatewayConfigurationFile)) {
            /// create the file if it does not exist
            let envConfig = new util_1.EnvironmentConfiguration();
            host.create(gatewayConfigurationFile, JSON.stringify(envConfig));
        }
        let gatewayConfigurationContent = host.read(gatewayConfigurationFile);
        if (!gatewayConfigurationContent) {
            throw new Error(`❌ No gateway configuration found for your application!`);
        }
        let gatewayConfigData = JSON.parse(gatewayConfigurationContent.toString());
        updateGatewayConfiguration(gatewayConfigData, gatewayConfigOptions);
        host.overwrite(gatewayConfigurationFile, JSON.stringify(gatewayConfigData));
        context.logger.info(`✅ The requested configuration entry has been added/updated successfully!`);
    };
}
function updateGatewayConfiguration(gatewayConfigData, gatewayConfigOptions) {
    let gatewayConfigItem = gatewayConfigData.configurationItems.find(e => e.type === 'gateway' && e.id === gatewayConfigOptions.id);
    if (isNull(gatewayConfigItem)) { // a new entry
        let gatewayConfigItem_ = new util_1.GatewayConfigurationItem();
        gatewayConfigItem_.id = gatewayConfigOptions.id;
        gatewayConfigItem_.type = 'gateway';
        if (!isNull(gatewayConfigOptions.gatewayHost) && gatewayConfigOptions.gatewayHost !== undefined) {
            gatewayConfigItem_.gatewayHost = gatewayConfigOptions.gatewayHost;
        }
        if (!isNull(gatewayConfigOptions.gatewayPort) && gatewayConfigOptions.gatewayPort !== undefined) {
            gatewayConfigItem_.gatewayPort = gatewayConfigOptions.gatewayPort;
        }
        if (!isNull(gatewayConfigOptions.gatewayProtocol) && gatewayConfigOptions.gatewayProtocol !== undefined) {
            gatewayConfigItem_.gatewayProtocol = gatewayConfigOptions.gatewayProtocol;
        }
        if (!isNull(gatewayConfigOptions.endpoint) && gatewayConfigOptions.endpoint !== undefined &&
            !isNull(gatewayConfigOptions.endpointId) && gatewayConfigOptions.endpointId !== undefined) {
            let apiEndPointItem = new util_1.ApiEndpoint();
            apiEndPointItem.endpoint = gatewayConfigOptions.endpoint;
            apiEndPointItem.id = gatewayConfigOptions.endpointId;
            if (!isNull(gatewayConfigOptions.queryBuilder) && gatewayConfigOptions.queryBuilder !== undefined) {
                apiEndPointItem.queryBuilder = gatewayConfigOptions.queryBuilder;
            }
            if (!isNull(gatewayConfigOptions.externalEntityId) && gatewayConfigOptions.externalEntityId !== undefined) {
                apiEndPointItem.externalEntityId = gatewayConfigOptions.externalEntityId;
            }
            gatewayConfigItem_.apiEndpoints.push(apiEndPointItem);
        }
        gatewayConfigData.configurationItems.push(gatewayConfigItem_);
        return gatewayConfigData;
    }
    else { // an update
        let gatewayConfigItem_ = gatewayConfigItem;
        if (!isNull(gatewayConfigOptions.gatewayHost) && gatewayConfigOptions.gatewayHost !== undefined) {
            gatewayConfigItem_.gatewayHost = gatewayConfigOptions.gatewayHost;
        }
        if (!isNull(gatewayConfigOptions.gatewayPort) && gatewayConfigOptions.gatewayPort !== undefined) {
            gatewayConfigItem_.gatewayPort = gatewayConfigOptions.gatewayPort;
        }
        if (!isNull(gatewayConfigOptions.gatewayProtocol) && gatewayConfigOptions.gatewayProtocol !== undefined) {
            gatewayConfigItem_.gatewayProtocol = gatewayConfigOptions.gatewayProtocol;
        }
        if (!isNull(gatewayConfigOptions.endpoint) && gatewayConfigOptions.endpoint !== undefined &&
            !isNull(gatewayConfigOptions.endpointId) && gatewayConfigOptions.endpointId !== undefined) {
            let apiEndpoint = gatewayConfigItem_.apiEndpoints.find(e => e.id === gatewayConfigOptions.endpointId);
            let apiEndPointItem = new util_1.ApiEndpoint();
            apiEndPointItem.endpoint = gatewayConfigOptions.endpoint;
            apiEndPointItem.id = gatewayConfigOptions.endpointId;
            if (!isNull(gatewayConfigOptions.queryBuilder) && gatewayConfigOptions.queryBuilder !== undefined) {
                apiEndPointItem.queryBuilder = gatewayConfigOptions.queryBuilder;
            }
            if (!isNull(gatewayConfigOptions.externalEntityId) && gatewayConfigOptions.externalEntityId !== undefined) {
                apiEndPointItem.externalEntityId = gatewayConfigOptions.externalEntityId;
            }
            if (!isNull(apiEndpoint) && apiEndpoint !== undefined) {
                /// update the related endpoint url
                gatewayConfigItem_.apiEndpoints.splice(gatewayConfigItem_?.apiEndpoints.indexOf(apiEndpoint), 1);
                gatewayConfigItem_.apiEndpoints.push(apiEndPointItem);
            }
            else {
                //create a new endpoint item
                gatewayConfigItem_.apiEndpoints.push(apiEndPointItem);
            }
        }
        gatewayConfigData.configurationItems.splice(gatewayConfigData.configurationItems.indexOf(gatewayConfigItem), 1);
        gatewayConfigData.configurationItems.push(gatewayConfigItem_);
        return gatewayConfigData;
    }
}
function isNull(object) {
    if (object === null
        || object === undefined
        || (object instanceof Array && object.length === 0)
        || (typeof object === 'string' && object.trim() === '')
        || (typeof object === 'number' && object === 0)) {
        return true;
    }
    else {
        return false;
    }
}
//# sourceMappingURL=gateway-config.js.map