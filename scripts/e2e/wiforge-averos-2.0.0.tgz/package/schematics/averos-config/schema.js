"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.GatewayConfigurationOption = exports.ServiceConfigurationOption = void 0;
class ServiceConfigurationOption {
    // The identifier of the configuration.
    id;
    // The type of the configuration
    type;
    // the api host/server
    apiHost;
    // the api port
    apiPort;
    //the api protocol
    apiProtocol;
    // the HTTP query builder
    apiHTTPQueryBuilder;
    //the api endpoint
    apiEndPoint;
    // The identifier that is used by the backend to identify the entity.
    externalEntityId;
    // The path to the sources.
    path;
    // The name of the project.
    project;
    // the project root path
    projectRootPath;
}
exports.ServiceConfigurationOption = ServiceConfigurationOption;
class GatewayConfigurationOption {
    // The identifier of the configuration.
    id;
    // The type of the configuration
    type;
    // the gateway host/server
    gatewayHost;
    // the gateway port
    gatewayPort;
    //the gateway protocol
    gatewayProtocol;
    endpoint;
    endpointId;
    queryBuilder;
    // The identifier that is used by the backend to identify the entity.
    externalEntityId;
    // The path to the sources.
    path;
    // The name of the project.
    project;
    // the project root path
    projectRootPath;
}
exports.GatewayConfigurationOption = GatewayConfigurationOption;
//# sourceMappingURL=schema.js.map