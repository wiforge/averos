/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
export interface AverosConfigOption {
    type: string;
    id?: string;
    host?: string;
    port?: number;
    protocol?: string;
    endPoint?: string;
    endPointId?: string;
    externalEntityId?: string;
    httpQueryBuilder?: string;
    path?: string;
    project?: string;
}
export declare class ServiceConfigurationOption {
    id: string;
    type: string;
    apiHost?: string;
    apiPort?: number;
    apiProtocol?: string;
    apiHTTPQueryBuilder?: string;
    apiEndPoint?: string;
    externalEntityId?: string;
    path?: string;
    project?: string;
    projectRootPath?: string;
}
export declare class GatewayConfigurationOption {
    id: string;
    type: string;
    gatewayHost?: string;
    gatewayPort?: number;
    gatewayProtocol?: string;
    endpoint?: string;
    endpointId?: string;
    queryBuilder?: string;
    externalEntityId?: string;
    path?: string;
    project?: string;
    projectRootPath?: string;
}
