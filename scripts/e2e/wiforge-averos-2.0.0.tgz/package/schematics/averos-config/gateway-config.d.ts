/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
import { Rule } from '@angular-devkit/schematics';
import { GatewayConfigurationOption } from './schema';
export default function (gatewayConfigOptions: GatewayConfigurationOption): Rule;
export declare function createApiGatewayConfiguration(gatewayConfigOptions: GatewayConfigurationOption): Rule;
