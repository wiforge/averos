"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
/**
 * file: averos-auth-config/index.ts
 */
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const path_1 = require("path");
const change_1 = require("@schematics/angular/utility/change");
const util_1 = require("../util");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:averos-auth-config"`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        // UPDATED VALIDATION: provider required only when NOT in httpConfig mode
        if (!options.httpConfig && (!options.provider || options.provider.trim() === '')) {
            context.logger.error(`❌ Provider name is required when --http-config is not set`);
            return (0, schematics_1.noop)();
        }
        if (!options.key || options.key.trim() === '') {
            context.logger.error(`❌ Configuration key is required`);
            return (0, schematics_1.noop)();
        }
        if (options.value === undefined || options.value === null) {
            context.logger.error(`❌ Configuration value is required`);
            return (0, schematics_1.noop)();
        }
        if (options.httpConfig) {
            context.logger.info(`🔧 Configuring HTTP auth: ${options.key} = ${options.value}`);
        }
        else {
            context.logger.info(`🔧 Configuring ${options.provider} provider: ${options.key} = ${options.value}`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot retrieve the project.`);
            }
        }
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
        }
        return updateAuthProviderConfig(options);
    };
}
function updateAuthProviderConfig(options) {
    return (host, context) => {
        const modulePath = (0, path_1.normalize)((0, path_1.join)((0, path_1.normalize)(options.path), '/app-module.ts'));
        if (!host.exists(modulePath)) {
            throw new Error(`❌ Unable to find the main application module at: ${modulePath}`);
        }
        context.logger.info(`🔧 Module found at: ${modulePath}`);
        const source = (0, util_1.readIntoSourceFile)(host, modulePath);
        const changes = (0, util_1.configureAverosAuthProvider)(source, modulePath, options, context);
        if (changes.length === 0) {
            return (0, schematics_1.noop)();
        }
        const updateRecorder = host.beginUpdate(modulePath);
        changes.forEach(change => {
            (0, change_1.applyToUpdateRecorder)(updateRecorder, [change]);
        });
        host.commitUpdate(updateRecorder);
        context.logger.info(`✅ Configuration updated successfully!`);
    };
}
//# sourceMappingURL=index.js.map