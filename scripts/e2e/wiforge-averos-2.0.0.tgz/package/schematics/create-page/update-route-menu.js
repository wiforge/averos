"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.registerDefaultRoute = registerDefaultRoute;
exports.createDefaultEntityMenuRoutes = createDefaultEntityMenuRoutes;
exports.createDefaultTranslationKeys = createDefaultTranslationKeys;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const core_1 = require("@angular-devkit/core");
const change_1 = require("@schematics/angular/utility/change");
const util_1 = require("../util");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:update-route-menu"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup //////////////
        if (!options.name || options.name.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ No target space to host the component was defined!`);
        }
        // transform the class name into a valid class identifier
        options.name = (0, util_1.toValidIdentifier)(options.name, 'class');
        /// Option Setup //////////////
        if (!options.targetMenu || options.targetMenu.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ No target menu to host the component was defined!`);
        }
        /// Option Setup //////////////
        if (!options.space || options.space.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The Page Name is mandatory! Please provide one`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        ///// END Option Setup////////////////////////
        let registerRouteOptions = {
            name: options.name,
            path: options.path,
            space: options.space,
        };
        options.path = (0, core_1.normalize)('/' + (0, core_1.dirname)((0, core_1.join)((0, core_1.normalize)(options.path), '/view', (0, core_1.basename)((0, core_1.normalize)(core_1.strings.dasherize(options.name))))));
        let menuRouteOptions = {
            name: options.name,
            projectRootPath: options.projectRootPath,
            space: options.space,
            targetMenu: options.targetMenu
        };
        context.logger.info(`🌱 Route and Default Menu will be updated`);
        return (0, schematics_1.chain)([
            registerDefaultRoute(registerRouteOptions),
            createDefaultEntityMenuRoutes(menuRouteOptions),
            createDefaultTranslationKeys(menuRouteOptions),
            (options) => {
                return async (host, context) => {
                    context.logger.info(`✅ A new entry is added to the module's route and to the default Menu`);
                };
            }
        ]);
    };
}
function registerDefaultRoute(options) {
    return async (host, context) => {
        context.logger.info(`☑️ UseCase route related to ${options.name} will be added...`);
        let routerModulePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'app-routing-module.ts'));
        if (!host.exists(routerModulePath)) {
            throw new schematics_1.SchematicsException(`❌ Unable to find the main application routing module in the following location: ${routerModulePath}`);
        }
        let source = (0, util_1.readIntoSourceFile)(host, routerModulePath);
        let registerRouteOptions = {
            name: options.name,
            useCaseComponentPath: `./view/${core_1.strings.dasherize(options.name)}/${core_1.strings.dasherize(options.name)}`,
            space: options.space
        };
        const updateRoutes = registerRouteDeclaration(source, routerModulePath, registerRouteOptions);
        const changes = updateRoutes;
        const recorder = host.beginUpdate(routerModulePath);
        for (const change of changes) {
            if (change instanceof change_1.InsertChange) {
                recorder.insertLeft(change.pos, change.toAdd);
            }
        }
        host.commitUpdate(recorder);
    };
}
// function getRelatedEntityPath(path: string): string{
//   return join(normalize('../../../'), 'model');
// }
// function getRelatedEntityServicePath(path: string): string{
//   return join(normalize('../../../'), 'service');
// }
function toLowerCase(str) {
    return (str ? str.toLowerCase() : '');
}
function registerRouteDeclaration(source, routerModulePath, options) {
    if (!source || !routerModulePath) {
        return [new change_1.NoopChange()];
    }
    const routesListNode = (0, util_1.extractRoutesListNode)(source, routerModulePath);
    const routeToRegister = `{ path: '${toLowerCase(options.name)}', component: ${options.name}${(options.space === 'logged' ? ', canActivate: [AuthenticationGuard]}' : '}')}`;
    const { insertPos, toAdd } = (0, util_1.getRouteInsertionPoint)(routesListNode, [routeToRegister]);
    return [
        new change_1.InsertChange(routerModulePath, insertPos, toAdd),
        (0, util_1.insertImport)(source, routerModulePath, `${options.name}`, options.useCaseComponentPath, false)
    ];
}
function createDefaultEntityMenuRoutes(options) {
    return async (host, context) => {
        let applicationDefaultMenuFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/menu/menu.default.json`));
        // reading the json i18n file
        if (!host.exists(applicationDefaultMenuFile)) {
            host.create(applicationDefaultMenuFile, `{"sideMenu": [],"topMenu": []}`);
        }
        let menuContent = host.read(applicationDefaultMenuFile);
        if (!menuContent) {
            menuContent = Buffer.from(`{
              "sideMenu": [],
            "topMenu": []
            }`);
        }
        let menu = JSON.parse(menuContent.toString());
        updateDefaultMenu(options, menu);
        host.overwrite(applicationDefaultMenuFile, JSON.stringify(menu));
        context.logger.info(`✅ The Page route have been added to the default menu!`);
    };
}
function updateDefaultMenu(options, menuContent) {
    let isPublicPage = options.space === 'public' ? true : false;
    let menuChild = {
        "displayName": `${(0, util_1.labelize)(options.name)}`,
        "translationID": `menu.${toLowerCase(options.name)}`,
        "iconName": "chevron_right",
        "type": "link",
        "route": `/${toLowerCase(options.name)}`
    };
    if (options.targetMenu !== 'both') {
        let menuEntry = options.targetMenu === 'side' ? menuContent.sideMenu : menuContent.topMenu;
        let entityMenuGroup = menuEntry.find(value => value.displayName === (isPublicPage ? 'Default Pages' : 'My Pages'));
        if (!entityMenuGroup) {
            entityMenuGroup = {
                "displayName": (isPublicPage ? 'Default Pages' : 'My Pages'),
                "loggedSpace": !isPublicPage,
                "iconName": "chevron_right",
                "type": "sub",
                "children": [menuChild]
            };
            if (options.targetMenu === 'side') {
                menuContent.sideMenu.push(entityMenuGroup);
            }
            else {
                menuContent.topMenu.push(entityMenuGroup);
            }
        }
        else { // entityMenuGroup already exists
            const itemIndex = menuEntry.indexOf(entityMenuGroup);
            if (entityMenuGroup.children) {
                if (!entityMenuGroup.children.find(e => e.displayName === menuChild.displayName)) {
                    entityMenuGroup.children.push(menuChild);
                }
            }
            else {
                entityMenuGroup.children = [menuChild];
            }
            menuEntry[itemIndex] = entityMenuGroup;
            if (options.targetMenu === 'side') {
                menuContent.sideMenu = menuEntry;
            }
            else {
                menuContent.topMenu = menuEntry;
            }
        }
    }
    else { // to both menus
        let sideMenuEntry = menuContent.sideMenu;
        let topMenuEntry = menuContent.topMenu;
        let sideMenuGroup = sideMenuEntry.find(value => value.displayName === 'Default Pages');
        let topMenuGroup = topMenuEntry.find(value => value.displayName === 'Default Pages');
        let isLoggedSpace = options.space === 'logged' ? true : false;
        // add menu entry to Side Menu
        if (!sideMenuGroup) {
            sideMenuGroup = {
                "displayName": (isPublicPage ? 'Default Pages' : 'My Pages'),
                "loggedSpace": isLoggedSpace,
                "iconName": "chevron_right",
                "type": "sub",
                "children": [menuChild]
            };
            menuContent.sideMenu.push(sideMenuGroup);
        }
        else { // sideMenuGroup already exists
            const itemIndex = sideMenuEntry.indexOf(sideMenuGroup);
            if (sideMenuGroup.children) {
                if (!sideMenuGroup.children.find(e => e.displayName === menuChild.displayName)) {
                    sideMenuGroup.children.push(menuChild);
                }
            }
            else {
                sideMenuGroup.children = [menuChild];
            }
            sideMenuEntry[itemIndex] = sideMenuGroup;
            menuContent.sideMenu = sideMenuEntry;
        }
        // add menu entry to Top Menu
        if (!topMenuGroup) {
            topMenuGroup = {
                "displayName": (isPublicPage ? 'Default Pages' : 'My Pages'),
                "loggedSpace": isLoggedSpace,
                "iconName": "chevron_right",
                "type": "sub",
                "children": [menuChild]
            };
            menuContent.topMenu.push(topMenuGroup);
        }
        else { // topMenuGroup already exists
            const itemIndex = topMenuEntry.indexOf(topMenuGroup);
            if (topMenuGroup.children) {
                if (!topMenuGroup.children.find(e => e.displayName === menuChild.displayName)) {
                    topMenuGroup.children.push(menuChild);
                }
            }
            else {
                topMenuGroup.children = [menuChild];
            }
            topMenuEntry[itemIndex] = topMenuGroup;
            menuContent.topMenu = topMenuEntry;
        }
    }
    return menuContent;
}
function createDefaultTranslationKeys(options) {
    return async (host, context) => {
        let translationFilesLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/i18n/`));
        let dirEntry = host.getDir(translationFilesLocation);
        let translationFilesDirEntry = dirEntry.subfiles;
        translationFilesDirEntry.forEach(tFile => {
            let translationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), tFile));
            if (!host.exists(translationFile)) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.\n`);
            }
            let translationContent = host.read(translationFile);
            if (!translationContent) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.\n`);
            }
            let translationData = JSON.parse(translationContent.toString());
            if (!translationData[`menu.${toLowerCase(options.name)}`]) {
                translationData[`menu.${toLowerCase(options.name)}`] = (0, util_1.labelize)(options.name);
            }
            host.overwrite(translationFile, JSON.stringify(translationData));
        });
    };
}
//# sourceMappingURL=update-route-menu.js.map