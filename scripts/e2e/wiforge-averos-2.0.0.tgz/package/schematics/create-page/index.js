"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const core_1 = require("@angular-devkit/core");
const util_1 = require("../util");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:create-page"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup //////////////
        if (!options.name || options.name.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The Page Name is mandatory! Please provide one`);
        }
        // transform the class name into a valid class identifier
        options.name = (0, util_1.toValidIdentifier)(options.name, 'class');
        // Check wether the use case is already created
        const pageFilePath = (0, util_1.findClassImplementationFilePath)(host, core_1.strings.classify(options.name));
        if (pageFilePath) {
            context.logger.info(`⚠️ The Page ${core_1.strings.classify(options.name)} does already exist!\n ⏭️ Skipping the Page creation \n`);
            return (0, schematics_1.noop)();
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        ///// END Option Setup////////////////////////
        let registerRouteAndMenuOptions = {
            name: options.name,
            path: options.path,
            project: options.project,
            space: options.space,
            targetMenu: options.targetMenu,
            updateRouteMenu: options.updateRouteMenu,
            projectRootPath: options.projectRootPath
        };
        options.path = (0, core_1.normalize)('/' + (0, core_1.dirname)((0, core_1.join)((0, core_1.normalize)(options.path), '/view', (0, core_1.basename)((0, core_1.normalize)(options.name)))));
        let ngCreatePageComponentOptions = {
            name: options.name,
            path: (0, core_1.join)((0, core_1.normalize)(options.path)),
            project: options.project,
            style: 'scss',
            standalone: false
        };
        context.logger.info(`🌱 A new page seed named ${options.name} is being sown...`);
        const templateSource = (0, schematics_1.apply)((0, schematics_1.url)('./files'), [
            (0, schematics_1.applyTemplates)({
                ...core_1.strings,
                classifyPreserveTrailingIndex: util_1.classifyPreserveTrailingIndex,
                getRelatedEntityPath,
                getRelatedEntityServicePath,
                toLowerCase,
                labelize: util_1.labelize,
                ...options
            }),
            (0, schematics_1.move)(options.path)
        ]);
        return (0, schematics_1.chain)([
            // create a new angular component
            (0, schematics_1.externalSchematic)('@schematics/angular', 'component', ngCreatePageComponentOptions),
            // update compoent with the averos use case template
            (0, schematics_1.mergeWith)(templateSource, schematics_1.MergeStrategy.Overwrite),
            options.updateRouteMenu ? (0, schematics_1.schematic)('update-route-menu', registerRouteAndMenuOptions) : (0, schematics_1.noop)(),
            (options) => {
                return async (host, context) => {
                    context.logger.info(`🎉🎉🎉🎉🎉  Congratulations! Your new page is created successfully! 🎉🎉🎉🎉🎉`);
                };
            }
        ]);
    };
}
function getRelatedEntityPath(path) {
    return (0, core_1.join)((0, core_1.normalize)('../../../'), 'model');
}
function getRelatedEntityServicePath(path) {
    return (0, core_1.join)((0, core_1.normalize)('../../../'), 'service');
}
function toLowerCase(str) {
    return (str ? str.toLowerCase() : '');
}
//# sourceMappingURL=index.js.map