/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
import { Rule } from '@angular-devkit/schematics';
import { CreatePageOptions } from './schema';
export default function (options: CreatePageOptions): Rule;
export declare function registerDefaultRoute(options: any): Rule;
export declare function createDefaultEntityMenuRoutes(options: any): Rule;
export declare function createDefaultTranslationKeys(options: any): Rule;
