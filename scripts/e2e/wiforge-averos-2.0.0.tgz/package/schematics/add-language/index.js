"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.addLanguageSupport = addLanguageSupport;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const core_1 = require("@angular-devkit/core");
const change_1 = require("@schematics/angular/utility/change");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const ts = require("typescript");
const util_1 = require("../util");
const rxjs_1 = require("rxjs");
const language_data_1 = require("./language-data");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:add-language"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup //////////////
        if (!options.languageCode || options.languageCode.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ language code is mandatory! Please provide one`);
        }
        if (options.languageCode &&
            options.languageCode.trim() !== 'ar' &&
            options.languageCode.trim() !== 'cn' &&
            options.languageCode.trim() !== 'en' &&
            options.languageCode.trim() !== 'es' &&
            options.languageCode.trim() !== 'fr' &&
            options.languageCode.trim() !== 'de' &&
            options.languageCode.trim() !== 'jp' &&
            options.languageCode.trim() !== 'nl' &&
            options.languageCode.trim() !== 'ru' &&
            options.languageCode.trim() !== 'se' &&
            options.languageCode.trim() !== 'no') {
            throw new Error(`❌ The language requested is not supported yet! Please submit a support request [https://github.com/averos-io/averos-io-starter/issues] so that it could be included in future releases.`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.srcPath === undefined) {
            options.srcPath = (0, core_1.join)((0, core_1.normalize)(`${project.root}/`), 'src'); //buildDefaultPath(project);
            context.logger.info(`✅ Using the default source path: ${options.srcPath}`);
        }
        context.logger.info(`🌱 << ${options.languageCode} >> language support will be added to the application...`);
        return (0, schematics_1.chain)([
            addLanguageSupport(options)
        ]);
    };
}
function addLanguageSupport(options) {
    return async (host, context) => {
        let modulePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.srcPath), '/app/app-module.ts'));
        if (!host.exists(modulePath)) {
            throw new Error(`❌ Unable to find the main application module in the following location: ${modulePath}`);
        }
        let i18nConfigFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.srcPath), `/assets/i18n/${options.languageCode}.json`));
        let countryFlag = `${options.languageCode}.svg`;
        if (options.languageCode && options.languageCode === 'en') {
            countryFlag = 'gb.svg';
        }
        if (options.languageCode && options.languageCode === 'ar') {
            countryFlag = 'ar.svg';
        }
        let i18nLanguageFlag = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.srcPath), `/assets/icons/svg/default/flags/${countryFlag}`));
        // reading the json i18n file
        if (!host.exists(i18nConfigFile)) {
            host.create(i18nConfigFile, '{}');
        }
        else {
            context.logger.warn(`⚠️ The requested language <<${options.languageCode}>> is already configured!\n Skipping the language configuration \n`);
            return (0, rxjs_1.noop)();
        }
        if (!host.exists(i18nLanguageFlag)) {
            host.create(i18nLanguageFlag, '');
        }
        // insert a translation keys
        const insertTKeysChange = new change_1.InsertChange(i18nConfigFile, 1, `${(0, language_data_1.getTranslationKeys)(options.languageCode)}`);
        const tKeysRecorder = host.beginUpdate(i18nConfigFile);
        tKeysRecorder.insertLeft(insertTKeysChange.pos, insertTKeysChange.toAdd);
        // insert the language flag
        const insertLanguageFlagChange = new change_1.InsertChange(i18nLanguageFlag, 0, `\n${(0, language_data_1.getTranslationFlag)(options.languageCode)}\n`);
        const langFlagRecorder = host.beginUpdate(i18nLanguageFlag);
        langFlagRecorder.insertLeft(insertLanguageFlagChange.pos, insertLanguageFlagChange.toAdd);
        /// Register Language into the main app module
        let source = (0, util_1.readIntoSourceFile)(host, modulePath);
        const updateModuleLanguage = insertLanguage(source, modulePath, options, context);
        const changes = updateModuleLanguage;
        const registerModuleLanguageRecorder = host.beginUpdate(modulePath);
        for (const change of changes) {
            if (change instanceof change_1.InsertChange) {
                registerModuleLanguageRecorder.insertLeft(change.pos, change.toAdd);
            }
        }
        // commit changes
        host.commitUpdate(registerModuleLanguageRecorder);
        host.commitUpdate(tKeysRecorder);
        host.commitUpdate(langFlagRecorder);
        context.logger.info(`✅ The << ${options.languageCode} >> language support has been successfully added to your application!`);
    };
}
function insertLanguage(source, modulePath, options, context) {
    if (!source || !modulePath) {
        return [new change_1.NoopChange()];
    }
    const nodes_ = (0, util_1.getDecoratorMetadata)(source, 'NgModule', '@angular/core');
    let node = nodes_[0];
    // Find the decorator declaration.
    if (!node) {
        return [];
    }
    // Get all the children property assignment of object literals.
    const matchingProperties = (0, util_1.getMetadataField)(node, 'imports');
    if (matchingProperties.length === 0) {
        throw new Error(`❌ Could not register the language! Please check your averos project configuration.`);
    }
    const supportedLanguageParameterNode = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.Identifier)?.find(n => n.getText() === 'supportedLanguages');
    if (!supportedLanguageParameterNode || !supportedLanguageParameterNode.parent) {
        const averosCoreModuleNode = (0, ast_utils_1.findNodes)(node, ts.SyntaxKind.Identifier, 200, true)?.find(n => n.getText() === 'AverosCoreModule');
        if (!averosCoreModuleNode) {
            throw new Error(`❌ Expected AverosCoreModule.forRoot() ${modulePath} was not found! \nPlease check your project configuration!`);
        }
        const averosCoreModuleForRootNode = (0, ast_utils_1.findNodes)(node, ts.SyntaxKind.CallExpression, 200, true)?.
            find(n => n.getChildren().find(c => (0, ast_utils_1.findNodes)(c, ts.SyntaxKind.Identifier, 200, true)?.find(i => i.getText() === 'AverosCoreModule')));
        if (!averosCoreModuleForRootNode) {
            throw new Error(`❌ Expected AverosCoreModule.forRoot() ${modulePath} was not found! \nPlease check your project configuration!`);
        }
        let parameterUpdatePositionNode = averosCoreModuleForRootNode.getChildAt(2);
        if (!parameterUpdatePositionNode) {
            throw new Error(`❌ Expected AverosCoreModule.forRoot() ${modulePath} was not found! \nPlease check your project configuration!`);
        }
        else {
            let data = parameterUpdatePositionNode.getChildren()?.length > 0 ? `, supportedLanguages: ['${options.languageCode}']` : `{ supportedLanguages: ['${options.languageCode}']}`;
            let createLanguageParameterChange = new change_1.InsertChange(modulePath, (parameterUpdatePositionNode.getChildren()?.length > 0 ? parameterUpdatePositionNode.getChildAt(0).getChildAt(1).getEnd() : parameterUpdatePositionNode.getEnd()), data);
            return [createLanguageParameterChange];
        }
    }
    else {
        // define supportedLanguageParameterNode's sibling nodes and remove supportedLanguageParameterNode from it
        let supportedLanguageParameterNodeSiblings = supportedLanguageParameterNode.parent.getChildren();
        let supportedLanguageNodeIndex = supportedLanguageParameterNodeSiblings?.indexOf(supportedLanguageParameterNode);
        supportedLanguageParameterNodeSiblings = supportedLanguageParameterNodeSiblings?.slice(supportedLanguageNodeIndex);
        // get supportedLanguageParameter array literal expression from the siblings
        let supportedLanguageParameterArrayLiteralExpressionNode = supportedLanguageParameterNodeSiblings.find(n => n.kind === ts.SyntaxKind.ArrayLiteralExpression);
        if (!supportedLanguageParameterArrayLiteralExpressionNode) {
            throw new schematics_1.SchematicsException(`❌ supportedLanguages array is not defined`);
        }
        // get supportedLanguages array node which is in the children of supportedLanguageParameterArrayLiteralExpressionNode and its kind of SyntaxList
        let supportedLanguageListNode = supportedLanguageParameterArrayLiteralExpressionNode.getChildren().find(n => n.kind === ts.SyntaxKind.SyntaxList);
        if (!supportedLanguageListNode) {
            throw new schematics_1.SchematicsException(`❌ supportedLanguages array is not defined`);
        }
        let data = supportedLanguageListNode.getWidth() > 0 ? `, '${options.languageCode}'` : `'${options.languageCode}'`;
        let registerLanguageChange = new change_1.InsertChange(modulePath, supportedLanguageListNode.getEnd(), data);
        return [registerLanguageChange];
    }
}
//# sourceMappingURL=index.js.map