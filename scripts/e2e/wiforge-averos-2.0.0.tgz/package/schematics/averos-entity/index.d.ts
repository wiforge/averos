/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
import { Rule } from '@angular-devkit/schematics';
import { AverosEntityOption } from './schema';
export default function (options: AverosEntityOption): Rule;
export declare function registerEntity(options: AverosEntityOption): Rule;
export declare function createDefaultEntityViewLayout(options: AverosEntityOption): Rule;
export declare function createDefaultTranslationKeys(options: AverosEntityOption): Rule;
