"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApplication = createApplication;
const schematics_1 = require("@angular-devkit/schematics");
const deplib_versions_json_1 = require("../deplib-versions.json");
const path = require("path");
const child_process_1 = require("child_process");
function createApplication(options) {
    return (tree, context) => {
        const appName = options.applicationName || "myapplication";
        context.logger.info(`Creating a new Averos application: ${appName}`);
        return (0, schematics_1.chain)([
            addAverosFramework(options)
        ]);
    };
}
function addAverosFramework(options) {
    return async (tree, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:create-application"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        let appOtions = {
            name: options.applicationName,
            inlineStyle: false, // --no-inline-style
            inlineTemplate: false, // --no-inline-template
            zoneless: false, // --no-zoneless
            aiConfig: 'none', // --ai-config=none
            routing: true, // --routing
            strict: true, // --strict
            style: "scss", // --style=scss
            skipInstall: true,
            standalone: false, // --no-standalone
            ssr: false // --no-ssr
        };
        /// ng new applicationName --no-zoneless --no-inline-style --no-inline-template --ai-config=none --routing --strict --style=scss --no-standalone --no-ssr
        let newAppOptions = toAngularOptionsArray(appOtions);
        if (tree.exists(options.applicationName)) {
            context.logger.error(`❌ The directory ${options.applicationName} already exists. Please remove it or choose a different name.`);
            return tree;
        }
        context.logger.info(`📦 Running "ng new ${options.applicationName}"...`);
        const result = (0, child_process_1.spawnSync)("npx", ["ng", "new", options.applicationName, ...newAppOptions], {
            stdio: "inherit",
            shell: true,
        });
        if (result.error) {
            context.logger.error(`❌ Failed to create a new application: ${result.error.message}`);
            return tree; // Stop further execution if error occurs
        }
        const appPath = path.join(process.cwd(), options.applicationName);
        process.chdir(appPath); // Change directory
        context.logger.info(`📌 Switched to ${appPath}`);
        /// DEVELOPMENT MODE FOR TESTING PURPOSES: DO NOT USE FOR PRODUCTION ////////
        if (options.development && options.averosVersion) {
            context.logger.info(`  ℹ️ ########## INSTALLING A LOCAL AVEROS VERSION ${options.averosVersion} FOR TESTING PURPOSES  ############  `);
            context.logger.info(`  ℹ️ ##########   PLEASE DO NOT USE DEVELOPMENT OPTION PRODUCTION  ############  `);
            // const npmInstallTestLibraryResult = spawnSync("npm", ["install", "../wiforge-averos-2.0.0.tgz --legacy-peer-deps"], {
            //   stdio: "inherit",
            //   shell: true,
            // });
            const npmInstallTestLibraryResult = (0, child_process_1.spawnSync)("npm", ["install", `../wiforge-averos-${options.averosVersion}.tgz`], {
                stdio: "inherit",
                shell: true,
            });
            if (npmInstallTestLibraryResult.error) {
                context.logger.error(`❌ Failed to install Test library: ${npmInstallTestLibraryResult.error.message}`);
            }
            else {
                context.logger.info(`  ℹ️ npm install ../wiforge-averos-${options.averosVersion}.tgz executed successfully! `);
            }
        }
        //////////////////// FOR TESTING PURPOSES END //////////////////////
        // Define libraries to add
        // const libraries = ["@wiforge/averos", "@angular/localize"];
        const averosVersion = !options.averosVersion ? getDependencyLibVersion("@wiforge/averos") : options.averosVersion;
        const localizeVersion = getDependencyLibVersion("@angular/localize");
        const libraries = [`@wiforge/averos@${averosVersion}`, `@angular/localize@${localizeVersion}`];
        // Loop through each library and execute "ng add"
        libraries.forEach((lib) => {
            context.logger.info(`📦 Running "ng add ${lib}"...`);
            let optionsArray = [];
            if (lib === `@wiforge/averos@${averosVersion}`) {
                optionsArray = toAngularOptionsArray(options);
                if (!optionsArray.find(e => e === '--defaults'))
                    optionsArray.push('--defaults');
            }
            if (!optionsArray.find(e => e === '--skip-confirmation'))
                optionsArray.push('--skip-confirmation');
            context.logger.info(`🔧 Using options: ${JSON.stringify(optionsArray)}`);
            const result = (0, child_process_1.spawnSync)("npx", ["ng", "add", lib, ...optionsArray], {
                stdio: "inherit",
                shell: true,
            });
            if (result.error) {
                context.logger.error(`❌ Failed to install ${lib}: ${result.error.message}`);
            }
        });
        return tree;
    };
}
// Convert camelCase to kebab-case
const toKebabCase = (str) => str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
// Convert JSON options to CLI arguments with kebab-case keys
function toAngularOptionsArray(optionArray) {
    return Object.entries(optionArray).filter(([_, value]) => value !== undefined) // Remove undefined values
        .map(([key, value]) => `--${toKebabCase(key)}=${value}`);
}
/**
 * Retrieves dependency lib package version
 */
function getDependencyLibVersion(packageName) {
    const version = deplib_versions_json_1.dependencies[packageName];
    if (!version) {
        throw new schematics_1.SchematicsException(`❌ Version not found for package: ${packageName}`);
    }
    return version;
}
//# sourceMappingURL=index.js.map