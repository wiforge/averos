"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.registerUseCaseRoute = registerUseCaseRoute;
exports.createDefaultEntityMenuRoutes = createDefaultEntityMenuRoutes;
exports.createDefaultTranslationKeys = createDefaultTranslationKeys;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const core_1 = require("@angular-devkit/core");
const change_1 = require("@schematics/angular/utility/change");
const ts = require("typescript");
const util_1 = require("../util");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:search-entity-uc"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup //////////////
        if (!options.name || options.name.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ Name is mandatory! Please provide one`);
        }
        if (!options.ename || options.ename.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ Entity Name is mandatory! Please provide one`);
        }
        // transform the class name into a valid class identifier
        options.name = (0, util_1.toValidIdentifier)(options.name, 'class');
        options.ename = (0, util_1.toValidIdentifier)(options.ename, 'class');
        // Check wether the use case is already created
        const useCaseFilePath = (0, util_1.findClassImplementationFilePath)(host, (0, util_1.classifyPreserveTrailingIndex)(options.name));
        if (useCaseFilePath) {
            context.logger.info(`⚠️ The use case ${(0, util_1.classifyPreserveTrailingIndex)(options.name)} does already exist!\n ⏭️ Skipping the use case creation \n`);
            return (0, schematics_1.noop)();
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        //Retrieve the related service if it already exists
        if (options.sname === undefined && options.ename) {
            const entityFilePath = (0, util_1.findClassImplementationFilePath)(host, options.ename);
            if (!entityFilePath) {
                context.logger.error(`❌ Entity with name ${options.ename} does not exist!`);
                throw new schematics_1.SchematicsException(`❌ Entity with name ${options.ename} does not exist!`);
            }
            const text = host.read(entityFilePath);
            if (text !== null) {
                const sourceText = text.toString('utf-8');
                let entitySource = ts.createSourceFile(entityFilePath, sourceText, ts.ScriptTarget.Latest, true);
                let sname = (0, util_1.getServiceName)(entitySource);
                if (sname && sname !== '') {
                    options.sname = sname;
                }
                else { // Create a default service name
                    context.logger.info(`⚠️ Entity with name ${options.ename} does not have a managing service!`);
                    options.sname = `${options.ename}Service`;
                    context.logger.info(`⚠️ Using the default entity service: ${options.sname}`);
                }
            }
            else { // Create a default service name
                context.logger.info(`⚠️ Entity with name ${options.ename} does not have a managing service!`);
                options.sname = `${options.ename}Service`;
                context.logger.info(`⚠️ Using the default entity service: ${options.sname}`);
            }
        }
        ///// END Option Setup////////////////////////
        let registerRoutesOptions = {
            name: options.name,
            path: options.path,
            ename: options.ename
        };
        options.path = (0, core_1.normalize)('/' + (0, core_1.dirname)((0, core_1.join)((0, core_1.normalize)(options.path), '/view', core_1.strings.dasherize(options.ename))));
        let menuRouteOptions = {
            name: options.name,
            ename: options.ename,
            projectRootPath: options.projectRootPath
        };
        let ngSearchUCComponentOptions = {
            name: options.name,
            path: (0, core_1.join)((0, core_1.normalize)(options.path), '/', core_1.strings.dasherize(options.ename)),
            project: options.project,
            style: 'scss',
            standalone: false
        };
        let ngEntityDetailsUCComponentOptions = {
            name: `${options.ename}-Details`,
            path: (0, core_1.join)((0, core_1.normalize)(options.path), '/', `${core_1.strings.dasherize(options.ename)}`),
            project: options.project,
            style: 'scss',
            standalone: false
        };
        context.logger.info(`🌱 Entity Search use case seeds named ${options.name} are being sown...`);
        context.logger.info(`🌱 Entity Details use case seeds named ${options.ename}Details are being sown...`);
        const templateSource = (0, schematics_1.apply)((0, schematics_1.url)('./files'), [
            (0, schematics_1.applyTemplates)({
                ...core_1.strings,
                classifyPreserveTrailingIndex: util_1.classifyPreserveTrailingIndex,
                getRelatedEntityPath,
                getRelatedEntityServicePath,
                toLowerCase,
                ...options
            }),
            (0, schematics_1.move)(options.path)
        ]);
        return (0, schematics_1.chain)([
            // create related entity Details use case component
            (0, schematics_1.externalSchematic)('@schematics/angular', 'component', ngEntityDetailsUCComponentOptions),
            // create search entity use case component
            (0, schematics_1.externalSchematic)('@schematics/angular', 'component', ngSearchUCComponentOptions),
            // update both use cases with the averos template
            (0, schematics_1.mergeWith)(templateSource, schematics_1.MergeStrategy.Overwrite),
            registerUseCaseRoute(registerRoutesOptions),
            createDefaultEntityMenuRoutes(menuRouteOptions),
            createDefaultTranslationKeys(menuRouteOptions),
            (options) => {
                return async (host, context) => {
                    context.logger.info(`🎉🎉🎉🎉🎉  Congratulations! Your entity Search use case is ready! Enjoy!  🎉🎉🎉🎉🎉`);
                };
            }
        ]);
    };
}
function registerUseCaseRoute(options) {
    return async (host, context) => {
        context.logger.info(`☑️ UseCase route related to ${options.name} will be added...`);
        context.logger.info(`☑️ UseCase route related to ${options.ename}Details will be added...`);
        let routerModulePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'app-routing-module.ts'));
        if (!host.exists(routerModulePath)) {
            throw new schematics_1.SchematicsException(`❌ Unable to find the main application routing module in the following location: ${routerModulePath}`);
        }
        let source = (0, util_1.readIntoSourceFile)(host, routerModulePath);
        let registerRouteOptions = {
            name: options.name,
            ename: options.ename,
            searchEntityUseCaseComponentPath: `./view/${core_1.strings.dasherize(options.ename)}/${core_1.strings.dasherize(options.name)}/${core_1.strings.dasherize(options.name)}`,
            entityDetailsUseCaseComponentPath: `./view/${core_1.strings.dasherize(options.ename)}/${core_1.strings.dasherize(options.ename)}-details/${core_1.strings.dasherize(options.ename)}-details`
        };
        const updateRoutes = registerRoutesDeclaration(source, routerModulePath, registerRouteOptions);
        const changes = updateRoutes;
        const recorder = host.beginUpdate(routerModulePath);
        for (const change of changes) {
            if (change instanceof change_1.InsertChange) {
                recorder.insertLeft(change.pos, change.toAdd);
            }
        }
        host.commitUpdate(recorder);
    };
}
function registerRoutesDeclaration(source, routerModulePath, options) {
    if (!source || !routerModulePath) {
        return [new change_1.NoopChange()];
    }
    const routesListNode = (0, util_1.extractRoutesListNode)(source, routerModulePath);
    const entitySearchRoute = `{ path: '${toLowerCase(options.ename)}s/search', component: ${options.name}, canActivate: [AuthenticationGuard] }`;
    const viewEntityRoute = `{ path: '${toLowerCase(options.ename)}s/view/:id', component: ${options.ename}Details, canActivate: [AuthenticationGuard] }`;
    const editEntityRoute = `{ path: '${toLowerCase(options.ename)}s/edit/:id', component: ${options.ename}Details, canActivate: [AuthenticationGuard] }`;
    const { insertPos, toAdd } = (0, util_1.getRouteInsertionPoint)(routesListNode, [entitySearchRoute, viewEntityRoute, editEntityRoute]);
    return [
        new change_1.InsertChange(routerModulePath, insertPos, toAdd),
        (0, util_1.insertImport)(source, routerModulePath, `${options.name}`, options.searchEntityUseCaseComponentPath, false),
        (0, util_1.insertImport)(source, routerModulePath, `${options.ename}Details`, options.entityDetailsUseCaseComponentPath, false)
    ];
}
function getRelatedEntityPath(path) {
    return (0, core_1.join)((0, core_1.normalize)('../../../'), 'model');
}
function getRelatedEntityServicePath(path) {
    return (0, core_1.join)((0, core_1.normalize)('../../../'), 'service');
}
function toLowerCase(str) {
    return (str ? str.toLowerCase() : '');
}
function createDefaultEntityMenuRoutes(options) {
    return async (host, context) => {
        let applicationDefaultMenuFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/menu/menu.default.json`));
        // reading the json i18n file
        if (!host.exists(applicationDefaultMenuFile)) {
            host.create(applicationDefaultMenuFile, `{"sideMenu": [],"topMenu": []}`);
        }
        let menuContent = host.read(applicationDefaultMenuFile);
        if (!menuContent) {
            menuContent = Buffer.from(`{
            "sideMenu": [],
          "topMenu": []
          }`);
        }
        let menu = JSON.parse(menuContent.toString());
        updateDefaultMenu(options.ename, menu);
        host.overwrite(applicationDefaultMenuFile, JSON.stringify(menu));
        context.logger.info(`✅ The Entity routes have been added to the default menu!`);
    };
}
function updateDefaultMenu(ename, menuContent) {
    let menuChild = {
        "displayName": `Search ${ename}`,
        "translationID": `menu.${toLowerCase(ename)}.search`,
        "iconName": "search",
        "type": "link",
        "route": `/${toLowerCase(ename)}s/search`
    };
    let sideMenu = menuContent.sideMenu;
    let entityMenuGroup = sideMenu.find(value => value.displayName === ename);
    if (!entityMenuGroup) {
        entityMenuGroup = {
            "displayName": `${ename}`,
            "translationID": `menu.${toLowerCase(ename)}`,
            "loggedSpace": false,
            "iconName": "chevron_right",
            "type": "sub",
            "children": [menuChild]
        };
        menuContent.sideMenu.push(entityMenuGroup);
    }
    else {
        const itemIndex = sideMenu.indexOf(entityMenuGroup);
        if (entityMenuGroup.children) {
            if (!entityMenuGroup.children.find(e => e.displayName === menuChild.displayName)) {
                entityMenuGroup.children.push(menuChild);
            }
        }
        else {
            entityMenuGroup.children = [menuChild];
        }
        sideMenu[itemIndex] = entityMenuGroup;
        menuContent.sideMenu = sideMenu;
    }
    return menuContent;
}
function createDefaultTranslationKeys(options) {
    return async (host, context) => {
        let translationFilesLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/i18n/`));
        let dirEntry = host.getDir(translationFilesLocation);
        let translationFilesDirEntry = dirEntry.subfiles;
        translationFilesDirEntry.forEach(tFile => {
            let translationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), tFile));
            if (!host.exists(translationFile)) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.\n`);
            }
            let translationContent = host.read(translationFile);
            if (!translationContent) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.\n`);
            }
            let translationData = JSON.parse(translationContent.toString());
            // MENU ENTRIES
            if (!translationData[`menu.${toLowerCase(options.ename)}.search`]) {
                translationData[`menu.${toLowerCase(options.ename)}.search`] = `Search ${(0, util_1.labelize)(options.ename)}`;
            }
            if (!translationData[`menu.${toLowerCase(options.ename)}`]) {
                translationData[`menu.${toLowerCase(options.ename)}`] = (0, util_1.labelize)(options.ename);
            }
            // SEARCH VIEW LAYOUT TRANSLATION ENTRIES
            if (!translationData[`uc.search.${toLowerCase(options.ename)}.title`]) {
                translationData[`uc.search.${toLowerCase(options.ename)}.title`] = `Search ${(0, util_1.labelize)(options.ename)}`;
            }
            if (!translationData[`uc.search.${toLowerCase(options.ename)}.label`]) {
                translationData[`uc.search.${toLowerCase(options.ename)}.label`] = `Search Criteria`;
            }
            // ///////////CREATE/VIEW/EDIT VIEW LAYOUT TRANSLATION ENTRIES /////////
            //create
            if (!translationData[`uc.create.${toLowerCase(options.ename)}.title`]) {
                translationData[`uc.create.${toLowerCase(options.ename)}.title`] = `Create ${(0, util_1.labelize)(options.ename)}`;
            }
            if (!translationData[`uc.create.${toLowerCase(options.ename)}.label`]) {
                translationData[`uc.create.${toLowerCase(options.ename)}.label`] = `${(0, util_1.labelize)(options.ename)} Details`;
            }
            ///edit
            if (!translationData[`uc.edit.${toLowerCase(options.ename)}.title`]) {
                translationData[`uc.edit.${toLowerCase(options.ename)}.title`] = `Edit ${(0, util_1.labelize)(options.ename)}`;
            }
            if (!translationData[`uc.edit.${toLowerCase(options.ename)}.label`]) {
                translationData[`uc.edit.${toLowerCase(options.ename)}.label`] = `${(0, util_1.labelize)(options.ename)} Details`;
            }
            //view
            if (!translationData[`uc.view.${toLowerCase(options.ename)}.title`]) {
                translationData[`uc.view.${toLowerCase(options.ename)}.title`] = `View ${(0, util_1.labelize)(options.ename)}`;
            }
            if (!translationData[`uc.view.${toLowerCase(options.ename)}.label`]) {
                translationData[`uc.view.${toLowerCase(options.ename)}.label`] = `${(0, util_1.labelize)(options.ename)} Details`;
            }
            host.overwrite(translationFile, JSON.stringify(translationData));
        });
        context.logger.info(`✅ Default translation entries values have been created for this Use Case keys!\nPlease note that these translation entries are by default created for all existing configured languages (including the default one).\nIn order to update a translation entry value use the command:\n{ ng g @wiforge/averos:add-translation-entry --lang=[LANGUAGE] --key=[KEY] --value=[valueInTargetLang] }`);
    };
}
//# sourceMappingURL=index.js.map