"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AverosEntityRelationDeleteStrategy = void 0;
var AverosEntityRelationDeleteStrategy;
(function (AverosEntityRelationDeleteStrategy) {
    AverosEntityRelationDeleteStrategy["KEEP_CHILDREN"] = "KEEP_CHILDREN";
    AverosEntityRelationDeleteStrategy["DELETE_CHILDREN"] = "DELETE_CASCADE";
})(AverosEntityRelationDeleteStrategy || (exports.AverosEntityRelationDeleteStrategy = AverosEntityRelationDeleteStrategy = {}));
//# sourceMappingURL=schema.js.map