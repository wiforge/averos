"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const workspace_1 = require("@schematics/angular/utility/workspace");
const change_1 = require("@schematics/angular/utility/change");
const schema_1 = require("./schema");
const util_1 = require("../util");
const ts = require("typescript");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:add-composite-member"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup //////////////
        if (!options.ename || options.ename.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ Entity Name is mandatory! Please provide one`);
        }
        if (!options.fename || options.fename.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The field entity type Name is mandatory! Please provide one`);
        }
        if (!options.fieldRelationType || options.fieldRelationType.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The relation type with the member you wish to add is mandatory! Please provide one`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        // transform the class name into a valid class identifier
        options.ename = (0, util_1.toValidIdentifier)(options.ename, 'class');
        options.fename = (0, util_1.toValidIdentifier)(options.fename, 'class');
        // transform the member name into a valid Class Identifier
        options.memberName = (0, util_1.toValidIdentifier)(options.memberName);
        options.memberName = getCompositeMemberName(options);
        ///// END Option Setup////////////////////////
        const templatesPath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'model') + '/');
        const entityRelativePath = `${templatesPath}/${core_1.strings.dasherize(options.ename)}.ts`;
        const memberEntityFilePath = `${templatesPath}/${core_1.strings.dasherize(options.fename)}.ts`;
        if (!host.exists(entityRelativePath)) {
            throw new schematics_1.SchematicsException(`❌ Entity ${options.ename} does not exist in the following location: ${entityRelativePath}!\n Please create your entities (parent and child) before adding any composite members.`);
        }
        if (!host.exists(memberEntityFilePath)) {
            throw new schematics_1.SchematicsException(`❌ Target entity member type << ${options.fename} >> does not exist in the following location: ${memberEntityFilePath}!\n Please create your entities (parent and child) before adding any composite members.`);
        }
        //// UPDATE ////
        // 1- get the service path
        // 2- load the service class src file
        //repeat for parent entity service & child entity service
        //let entityHasService: boolean = parent entity service or child entity service are null 
        const parentEntityServiceFilePath = (0, util_1.findClassImplementationFilePath)(host, options.ename);
        if (parentEntityServiceFilePath !== null || parentEntityServiceFilePath !== undefined) {
            // parentEntityHasService = true;
        }
        else {
            context.logger.info(`⚠️ Entity with name ${options.ename} does not have a managing service!`);
        }
        ///////
        context.logger.info(`🌱 Entity '${options.fieldRelationType}' relation with the field seeds named '${options.memberName}' is being sown...`);
        context.logger.info(`🌱 Entity View layout default configuration seeds are being sown...`);
        /**
         * updateCompositeRelationInSearchEntityUC() and updateCollectionRelationInSearchEntityUC()
         * are no more needed in averos 1.8.0 since now viewCompositeOject dynamically retrieves the composite entity class type
         */
        return (0, schematics_1.chain)([
            registerEntityMember(options),
            // options.fieldRelationType==='ManyToOne' || options.fieldRelationType==='OneToOne' ? updateCompositeRelationInSearchEntityUC(options) : noop(),
            // options.fieldRelationType==='OneToMany' ? updateCollectionRelationInSearchEntityUC(options) : noop(),
            createDefaultTranslationKeys(options),
            addDefaultMemberViewLayoutToEntityVL(options)
        ]);
    };
}
function registerEntityMember(options) {
    return async (host, context) => {
        context.logger.info(`☑️ Entity with name ${options.ename} will be Updated...`);
        let entityFilePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), `model/${core_1.strings.dasherize(options.ename)}.ts`));
        if (!host.exists(entityFilePath)) {
            throw new schematics_1.SchematicsException(`❌ Unable to find the averos entity << ${options.ename} >> in the following location: ${entityFilePath}`);
        }
        let source = (0, util_1.readIntoSourceFile)(host, entityFilePath);
        const importMemberEntityType = (0, util_1.insertImport)(source, entityFilePath, options.fename, `./${core_1.strings.dasherize(options.fename)}`);
        const importAverosDecorator = (0, util_1.insertImport)(source, entityFilePath, options.fieldRelationType, `@wiforge/averos`);
        const updateEntityWithNewMember = addMemberToEntity(source, entityFilePath, options, context);
        let changes = [importMemberEntityType, importAverosDecorator, updateEntityWithNewMember];
        if (options.deleteStrategy !== null && options.deleteStrategy !== undefined) {
            const importEntityRelationDeleteStrategy = (0, util_1.insertImport)(source, entityFilePath, `EntityRelationDeleteStrategy`, `@wiforge/averos`);
            changes.push(importEntityRelationDeleteStrategy);
        }
        const recorder = host.beginUpdate(entityFilePath);
        for (const change of changes) {
            if (change instanceof change_1.InsertChange) {
                recorder.insertLeft(change.pos, change.toAdd);
            }
        }
        host.commitUpdate(recorder);
    };
}
// function updateCompositeRelationInSearchEntityUC(options: AverosAddCompositeMemberOption): Rule {
//   return async (host: Tree, context: SchematicContext) => { 
//         let searchEntityFilePath = normalize(join(normalize(options.path as string), `view/${strings.dasherize(options.ename)}/search-${strings.dasherize(options.ename)}/search-${strings.dasherize(options.ename)}.ts`));
//         if (!host.exists(searchEntityFilePath)){
//           context.logger.info(`Unable to find the search entity use case << search-${strings.dasherize(options.ename)} >> in the following location: ${searchEntityFilePath}`);
//           return;
//           // throw new SchematicsException(`❌ Unable to find the search entity use case << search-${strings.dasherize(options.ename)} >> in the following location: ${searchEntityFilePath}`);
//         }
//         context.logger.info(`☑️ Search Entity Use Case with name << search-${strings.dasherize(options.ename)} >> will be Updated...`);
//         let source  = readIntoSourceFile(host, searchEntityFilePath);
//         const importMemberEntityType = insertImport(source as any, searchEntityFilePath, options.fename, `../../../model/${strings.dasherize(options.fename)}`);
//         const updateEntityWithLogic = addCompositeMemberLogicParentToSearchUseCase(source, searchEntityFilePath, options);
//         const changes = [importMemberEntityType, updateEntityWithLogic];
//         const recorder = host.beginUpdate(searchEntityFilePath);
//         for (const change of changes) {
//           if (change instanceof InsertChange) {
//             recorder.insertLeft(change.pos, change.toAdd);
//           }
//         }
//         host.commitUpdate(recorder);
//       };
// }
// function updateCollectionRelationInSearchEntityUC(options: AverosAddCompositeMemberOption): Rule {
//   return async (host: Tree, context: SchematicContext) => { 
//         let searchEntityFilePath = normalize(join(normalize(options.path as string), `view/${strings.dasherize(options.ename)}/search-${strings.dasherize(options.ename)}/search-${strings.dasherize(options.ename)}.ts`));
//         if (!host.exists(searchEntityFilePath)){
//           context.logger.info(`❌ Unable to find the search entity use case << search-${strings.dasherize(options.ename)} >> in the following location: ${searchEntityFilePath}`);
//           return;
//           // throw new SchematicsException(`❌ Unable to find the search entity use case << search-${strings.dasherize(options.ename)} >> in the following location: ${searchEntityFilePath}`);
//         }
//         context.logger.info(`☑️ Search Entity Use Case with name << search-${strings.dasherize(options.ename)} >> will be Updated...\n`);
//         let source  = readIntoSourceFile(host, searchEntityFilePath);
//         const importMemberEntityType = insertImport(source as any, searchEntityFilePath, options.fename, `../../../model/${strings.dasherize(options.fename)}`);
//         const updateEntityWithLogic = addCollectionMemberLogicToParentSearchUseCase(source, searchEntityFilePath, options);
//         const changes = [importMemberEntityType, updateEntityWithLogic];
//         const recorder = host.beginUpdate(searchEntityFilePath);
//         for (const change of changes) {
//           if (change instanceof InsertChange) {
//             recorder.insertLeft(change.pos, change.toAdd);
//           }
//         }
//         host.commitUpdate(recorder);
//       };
// }
function addMemberToEntity(source, entityPath, options, context) {
    if (!source || !entityPath) {
        return new change_1.NoopChange();
    }
    let memberName = options.memberName;
    const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
    if (!classDeclarationNode) { // no entity class declaration found
        throw new Error(`❌ No Class Declaration Found!`);
    }
    const propertiesDeclarationNodes__ = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.PropertyDeclaration);
    const memberDeclaration = propertiesDeclarationNodes__?.find((n) => n.name?.text === memberName);
    if (memberDeclaration) { // no entity class declaration found
        // throw new Error(
        //   `❌ Member << ${memberName} >> is already declared in the entity << ${options.ename} >>!`
        // )
        context.logger.warn(`⚠️ Composite field {${memberName}} is already declared in the entity  {${options.ename}} !\n ⏭️ Skipping the composite field creation \n`);
        return new change_1.NoopChange();
    }
    // add the new member declaration to the entity
    let positionToInsertMember = classDeclarationNode.getChildAt(classDeclarationNode.getChildCount() - 3).getEnd();
    if (propertiesDeclarationNodes__ && propertiesDeclarationNodes__.length > 0) {
        positionToInsertMember = propertiesDeclarationNodes__.reduce((previous, current) => {
            return previous + current.getFullWidth();
        }, positionToInsertMember);
    }
    let data = `\n    @${options.fieldRelationType}('${options.fename}', import('./${core_1.strings.dasherize(options.fename)}')`;
    if (options.deleteStrategy !== null && options.deleteStrategy !== undefined) {
        if (options.deleteStrategy !== schema_1.AverosEntityRelationDeleteStrategy.DELETE_CHILDREN &&
            options.deleteStrategy !== schema_1.AverosEntityRelationDeleteStrategy.KEEP_CHILDREN) {
            options.deleteStrategy = schema_1.AverosEntityRelationDeleteStrategy.KEEP_CHILDREN;
        }
        data = data.concat(`, EntityRelationDeleteStrategy.${options.deleteStrategy}) `);
    }
    else {
        data = data.concat(') ');
    }
    data = data.concat(memberName).concat(`!: ${options.fename}`);
    if (options.fieldRelationType === `OneToOne` || options.fieldRelationType === `ManyToOne`) {
        data = data.concat(`;\n`);
    }
    else {
        data = data.concat(`[];\n`); //array
    }
    return new change_1.InsertChange(entityPath, positionToInsertMember, data);
}
// function addCompositeMemberLogicParentToSearchUseCase(source: ts.SourceFile, entityPath: string,  
//   options: AverosAddCompositeMemberOption): Change {
//     if(!source || !entityPath){
//        return new NoopChange();
//     }
//     let methodName = 'viewCompositeObject';
//     const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
//     if (!classDeclarationNode){ // no entity class declaration found
//       throw new Error(
//         `❌ No Class Declaration Found!`
//       )
//     }
//     const methodDeclarationNodes__ = (findNodes(source as any, ts.SyntaxKind.MethodDeclaration) as unknown) as ts.DeclarationStatement[];
//     const methodDeclaration = methodDeclarationNodes__?.find((n: ts.DeclarationStatement ) => n.name?.text === methodName);
//     if (!methodDeclaration){ // no entity class declaration found
//       throw new Error(
//         `❌ Cannot find << ${methodName} >> method implementation withn the use case << search-${strings.dasherize(options.ename)} >>!\n Please use this workflow command within an averos generated application.\n`
//       )
//     }
//      // add the new member declaration to the entity
//      const ifStatementNodes_ = findNodes(methodDeclaration as any, ts.SyntaxKind.IfStatement);
//     if (ifStatementNodes_.length<1){
//       return new NoopChange();
//     }
//      const targetBloc = ifStatementNodes_[0].getChildAt(ifStatementNodes_[0].getChildCount() - 1);
//      let positionToInsertMember = targetBloc.getEnd() - targetBloc.getChildAt(targetBloc.getChildCount() - 1).getWidth(); 
//      let data = `\n      if (compositeObjectMetaData.type === '${options.fename}'){
//       averosDialogViewConfig.objectClass= ${options.fename}.instanceMetadata();
//     }
//       \n`;
//     return new InsertChange(entityPath, positionToInsertMember , data);
// }
// function addCollectionMemberLogicToParentSearchUseCase(source: ts.SourceFile, entityPath: string,  
//   options: AverosAddCompositeMemberOption): Change {
//     if(!source || !entityPath){
//        return new NoopChange();
//     }
//     let methodName = 'viewCompositeObject';
//     const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
//     if (!classDeclarationNode){ // no entity class declaration found
//       throw new Error(
//         `❌ No Class Declaration Found!`
//       )
//     }
//     const methodDeclarationNodes__ = (findNodes(source as any, ts.SyntaxKind.MethodDeclaration) as unknown) as ts.DeclarationStatement[];
//     const methodDeclaration = methodDeclarationNodes__?.find((n: ts.DeclarationStatement ) => n.name?.text === methodName);
//     if (!methodDeclaration){ // no entity class declaration found
//       throw new Error(
//         `❌ Cannot find << ${methodName} >> method implementation withn the use case << search-${strings.dasherize(options.ename)} >>!\n Please use this workflow command within an averos generated application.\n`
//       )
//     }
//      // add the new member declaration to the entity
//      const ifStatementNodes_ = findNodes(methodDeclaration as any, ts.SyntaxKind.IfStatement);
//     if (ifStatementNodes_.length<1){
//       return new NoopChange();
//     }
//      const targetBloc = ifStatementNodes_[0].getChildAt(4).getFirstToken();
//      let positionToInsertMember = targetBloc!.getEnd(); 
//      let data = `\n      if (compositeObjectMetaData.type === '${options.fename}'){
//       averosDialogViewConfig.objectClass= ${options.fename}.instanceMetadata();
//       averosDialogViewConfig.viewLayout.useCase = UseCase.SEARCH_RESULT_TABLE;    
//       averosDialogViewConfig.onLoadCallback = (entities: any[]): Observable<any> => of(entities); 
//     }
//       \n`;
//     return new InsertChange(entityPath, positionToInsertMember , data);
// }
function addDefaultMemberViewLayoutToEntityVL(options) {
    return async (host, context) => {
        let entityVLFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/viewlayout/${options.ename.toLocaleLowerCase()}VL.json`));
        if (!host.exists(entityVLFile)) {
            throw new Error(`❌ The requested entity view layout config related to the entity {${options.ename}} does not exist!\n Is the entity provided an averos entity?`);
        }
        let vlContent = host.read(entityVLFile);
        if (!vlContent) {
            return;
        }
        let entityViewLayout = JSON.parse(vlContent.toString());
        updateDefaultEntityViewLayout(entityViewLayout, options);
        host.overwrite(entityVLFile, JSON.stringify(entityViewLayout));
        context.logger.info(`✅ Member << ${options.fename} >> view layout have been successfully added to << ${options.ename} >> Entity View Layout!`);
    };
}
function updateDefaultEntityViewLayout(viewLayoutContent, options) {
    let entityFieldName = options.fieldRelationType === `OneToOne` ||
        options.fieldRelationType === `ManyToOne`
        ? (0, util_1.toValidIdentifier)(options.fename)
        : (0, util_1.toValidIdentifier)(options.fename).concat('s');
    let childType = options.fieldRelationType === `OneToOne` ||
        options.fieldRelationType === `ManyToOne`
        ? 'composite'
        : 'collection';
    let labelTranslationID = options.ename.toLowerCase().concat('.').concat(entityFieldName.toLowerCase());
    let label = labelize(entityFieldName);
    let tableUCViewLayoutEntry = `{
  "entityFieldName": "${entityFieldName}",
  "label": "${label}",
  "labelTranslationID": "${labelTranslationID}",
  "visible": true,
  "type": "${childType}",
  "typeName": "${options.fename}",
  "order": ${getOrderForCompositeField(viewLayoutContent.tableUCViewLayout.ucViewLayout) + 1}
}`;
    let viewUCViewLayoutEntry = `{
  "entityFieldName": "${entityFieldName}",
  "label": "${label}",
  "labelTranslationID": "${labelTranslationID}",
  "visible": true,
  "type": "${childType}",
  "typeName": "${options.fename}",
  "order": ${getOrderForCompositeField(viewLayoutContent.viewUCViewLayout.ucViewLayout) + 1},
  "fieldGroup": {
    "groupId": ${getOrderForCompositeField(viewLayoutContent.viewUCViewLayout.ucViewLayout) + 1},
    "layout": "inline",
    "groupLabel": "${label}",
    "groupLabelTranslationID": "${labelTranslationID}",
    "groupOrder": 1
  }
}`;
    let createUCViewLayoutEntry = `{
  "entityFieldName": "${entityFieldName}",
  "label": "${label}",
  "labelTranslationID": "${labelTranslationID}",
  "visible": true,
  "type": "${childType}",
  "typeName": "${options.fename}",
  "order": ${getOrderForCompositeField(viewLayoutContent.createUCViewLayout.ucViewLayout) + 1},
  "fieldGroup": {
    "groupId": ${getOrderForCompositeField(viewLayoutContent.createUCViewLayout.ucViewLayout) + 1},
    "layout": "inline",
    "groupLabel": "${label}",
    "groupLabelTranslationID": "${labelTranslationID}",
    "groupOrder": 1
  }
}`;
    let editUCViewLayoutEntry = `{
  "entityFieldName": "${entityFieldName}",
  "label": "${label}",
  "labelTranslationID": "${labelTranslationID}",
  "visible": true,
  "type": "${childType}",
  "typeName": "${options.fename}",
  "order": ${getOrderForCompositeField(viewLayoutContent.editUCViewLayout.ucViewLayout) + 1},
  "fieldGroup": {
    "groupId": ${getOrderForCompositeField(viewLayoutContent.editUCViewLayout.ucViewLayout) + 1},
    "layout": "inline",
    "groupLabel": "${label}",
    "groupLabelTranslationID": "${labelTranslationID}",
    "groupOrder": 1
  }
}`;
    if (!viewLayoutContent.createUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.createUCViewLayout.ucViewLayout.push(JSON.parse(createUCViewLayoutEntry));
    }
    if (!viewLayoutContent.editUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.editUCViewLayout.ucViewLayout.push(JSON.parse(editUCViewLayoutEntry));
    }
    if (!viewLayoutContent.viewUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.viewUCViewLayout.ucViewLayout.push(JSON.parse(viewUCViewLayoutEntry));
    }
    if (!viewLayoutContent.tableUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.tableUCViewLayout.ucViewLayout.push(JSON.parse(tableUCViewLayoutEntry));
    }
    return viewLayoutContent;
}
function labelize(str) {
    if (str) {
        return core_1.strings.dasherize(str).split('-').reduce((previous, current) => {
            return (previous !== '' ? previous.concat(' ').concat(core_1.strings.capitalize(current)) : previous.concat(core_1.strings.capitalize(current)));
        }, '');
    }
    return '';
}
function getOrderForCompositeField(fvLayouts) {
    let compositeElements = fvLayouts.filter(e => e.type === 'composite' || e.type === 'collection');
    if (compositeElements.length > 0) {
        return (compositeElements.length + 1);
    }
    else {
        return 1;
    }
}
function createDefaultTranslationKeys(options) {
    return async (host, context) => {
        let translationFilesLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/i18n/`));
        let dirEntry = host.getDir(translationFilesLocation);
        let translationFilesDirEntry = dirEntry.subfiles;
        translationFilesDirEntry.forEach(tFile => {
            let translationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), tFile));
            if (!host.exists(translationFile)) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.\n`);
            }
            let translationContent = host.read(translationFile);
            if (!translationContent) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.\n`);
            }
            let translationData = JSON.parse(translationContent.toString());
            if (options.fieldRelationType && options.fieldRelationType === 'ManyToOne') {
                if (!translationData[`${options.ename.toLocaleLowerCase()}.${options.fename.toLocaleLowerCase()}`]) {
                    translationData[`${options.ename.toLocaleLowerCase()}.${options.fename.toLocaleLowerCase()}`] = labelize(options.fename);
                }
            }
            if (options.fieldRelationType && options.fieldRelationType === 'OneToOne') {
                if (!translationData[`${options.ename.toLocaleLowerCase()}.${options.fename.toLocaleLowerCase()}`]) {
                    translationData[`${options.ename.toLocaleLowerCase()}.${options.fename.toLocaleLowerCase()}`] = labelize(options.fename);
                }
            }
            if (options.fieldRelationType && options.fieldRelationType === 'OneToMany') {
                const label = labelize(options.fename);
                const targetLabel = label.concat('s');
                if (!translationData[`${options.ename.toLocaleLowerCase()}.${options.fename.toLocaleLowerCase()}s`]) {
                    translationData[`${options.ename.toLocaleLowerCase()}.${options.fename.toLocaleLowerCase()}s`] = targetLabel;
                }
            }
            host.overwrite(translationFile, JSON.stringify(translationData));
        });
        context.logger.info(`✅ A default translation entry value have been created for this composite field key!\nPlease note this translation entry is by default created for all existing configured languages (including the default one).\nIn order to update the translation entry value for this key use the command:\n{ ng g @wiforge/averos:add-translation-entry --lang=[LANGUAGE] --key=[KEY] --value=[valueInTargetLang] }`);
    };
}
function getCompositeMemberName(options) {
    if (options.memberName !== null && options.memberName !== undefined && options.memberName !== "") {
        return options.memberName;
    }
    else if (options.fieldRelationType === `OneToOne` ||
        options.fieldRelationType === `ManyToOne`) {
        return (0, util_1.toValidIdentifier)(options.fename);
    }
    else if (options.fieldRelationType === `OneToMany`) {
        return (0, util_1.toValidIdentifier)(options.fename).concat('s');
    }
    else {
        throw new Error('Cannot construct member name! please provide either a member-name parameter or a valid field-relation-type parameter.');
    }
}
//# sourceMappingURL=index.js.map