"use strict";
/**
 * Averos Application Specification v1.0.0
 * TypeScript Type Definitions
 *
 * Use these types in your orchestrator to ensure type safety
 * and IDE auto-completion when working with spec files.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ID_PATTERNS = exports.ID_PREFIXES = void 0;
exports.isSimpleMember = isSimpleMember;
exports.isCompositeMember = isCompositeMember;
exports.generateId = generateId;
exports.validateId = validateId;
/**
 * Type guards for entity members
 */
function isSimpleMember(member) {
    return member.memberNature === "simple";
}
function isCompositeMember(member) {
    return member.memberNature === "composite";
}
/**
 * ID prefix constants
 */
exports.ID_PREFIXES = {
    APPLICATION: "app_",
    ENTITY: "ent_",
    MEMBER: "mem_",
    SERVICE: "svc_",
    CONFIGURATION: "cfg_",
    MAPPING: "map_",
    USE_CASE: "uc_",
    PAGE: "page_",
    AUTH_PROVIDER: "auth_",
    VALIDATOR: "val_",
};
/**
 * ID validation regex patterns
 */
exports.ID_PATTERNS = {
    APPLICATION: /^app_[a-z0-9]{8}$/,
    ENTITY: /^ent_[a-z0-9]{8}$/,
    MEMBER: /^mem_[a-z0-9]{8}$/,
    SERVICE: /^svc_[a-z0-9]{8}$/,
    CONFIGURATION: /^cfg_[a-z0-9]{8}$/,
    MAPPING: /^map_[a-z0-9]{8}$/,
    USE_CASE: /^uc_[a-z0-9]{8}$/,
    PAGE: /^page_[a-z0-9]{8}$/,
    AUTH_PROVIDER: /^auth_[a-z0-9]{8}$/,
    VALIDATOR: /^val_[a-z0-9]{8}$/,
};
/**
 * Utility function to generate unique IDs
 */
function generateId(prefix) {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let id = '';
    for (let i = 0; i < 8; i++) {
        id += chars[Math.floor(Math.random() * chars.length)];
    }
    return `${prefix}${id}`;
}
/**
 * Utility function to validate ID format
 */
function validateId(id, expectedPrefix) {
    const pattern = new RegExp(`^${expectedPrefix}[a-z0-9]{8}$`);
    return pattern.test(id);
}
//# sourceMappingURL=averos-spec-types.js.map