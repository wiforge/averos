/**
 * Averos Application Specification v1.0.0
 * TypeScript Type Definitions
 *
 * Use these types in your orchestrator to ensure type safety
 * and IDE auto-completion when working with spec files.
 */
/**
 * Root specification structure
 */
export interface AverosApplicationSpec {
    /** Specification version (must be "1.0.0") */
    specVersion: "1.0.0";
    /** Application metadata and identification */
    metadata: ApplicationMetadata;
    /** Application-level configuration */
    application: ApplicationConfiguration;
    /** Entity definitions (optional) */
    entities?: Entity[];
    /** Service definitions (optional) */
    services?: Service[];
    /** Service API configurations (optional) */
    serviceConfigurations?: ServiceConfiguration[];
    /** Entity field mappings (optional) */
    fieldMappings?: FieldMapping[];
    /** Use case definitions (optional) */
    useCases?: UseCase[];
    /** Custom page definitions (optional) */
    pages?: Page[];
    /** Authentication configuration (optional) */
    authentication?: AuthenticationConfig;
    /** Localization configuration (optional) */
    localization?: LocalizationConfig;
}
/**
 * Application metadata
 */
export interface ApplicationMetadata {
    /** Unique application ID (format: app_xxxxxxxx) */
    id: string;
    /** Human-readable application name (PascalCase) */
    name: string;
    /** Application description (optional) */
    description?: string;
    /** ISO 8601 creation timestamp */
    createdAt: string;
    /** ISO 8601 last update timestamp (optional) */
    updatedAt?: string;
    /** Author name or email (optional) */
    author?: string;
    /** Application version (semantic versioning, optional) */
    version?: string;
    /** Categorization tags (optional) */
    tags?: string[];
}
/**
 * Application configuration
 */
export interface ApplicationConfiguration {
    /** Default language code (ISO 639-1) */
    defaultLanguageCode: string;
    /** Enable authentication features */
    enableAuthentication?: boolean;
    /** Enable external entity ID mapping */
    enableExternalEntityMapping?: boolean;
    /** Development mode flag */
    development?: boolean;
    /** Target Averos framework version */
    averosVersion?: string;
}
/**
 * Entity definition
 */
export interface Entity {
    /** Unique entity ID (format: ent_xxxxxxxx) */
    id: string;
    /** Entity name (PascalCase) */
    name: string;
    /** Associated service name (optional) */
    serviceName?: string;
    /** Auto-create service for this entity */
    createService?: boolean;
    /** Entity members (fields and relationships) */
    members?: EntityMember[];
}
/**
 * Base entity member interface
 */
export interface EntityMemberBase {
    /** Unique member ID (format: mem_xxxxxxxx) */
    id: string;
    /** Member field name (camelCase or snake_case) */
    name: string;
}
/**
 * Simple member (primitive field)
 */
export interface SimpleMember extends EntityMemberBase {
    /** Member type discriminator */
    memberNature: "simple";
    /** Field data type */
    type: "string" | "number" | "boolean" | "date" | "enumeration";
    /** Enumeration values (required if type is 'enumeration') */
    enumValues?: string[];
    /** Member tags (ID markers) */
    tags?: Array<"ID" | "BusinessID" | "TechnicalID">;
    /** Field validators */
    validators?: Validator[];
}
/**
 * Composite member (relationship)
 */
export interface CompositeMember extends EntityMemberBase {
    /** Member type discriminator */
    memberNature: "composite";
    /** ID of the related entity */
    targetEntityId: string;
    /** Type of relationship */
    relationType: "OneToOne" | "OneToMany" | "ManyToOne" | "ManyToMany";
    /** Deletion strategy for related entities */
    deleteStrategy?: "CASCADE" | "KEEP_CHILDREN" | "RESTRICT";
}
/**
 * Union type for entity members
 */
export type EntityMember = SimpleMember | CompositeMember;
/**
 * Field validator
 */
export interface Validator {
    /** Unique validator ID (format: val_xxxxxxxx) */
    id: string;
    /** Validator type */
    validatorType: "predefined" | "custom";
    /** Validator identifier (e.g., 'required', 'maxLength') */
    validatorId: string;
    /** Validation error key */
    validatorKey: string;
    /** Validation nature */
    nature?: "sync" | "async";
    /** Validator parameters (e.g., [5] for maxLength) */
    parameters?: any[];
    /** Default validation error message */
    defaultMessage?: string;
    /** Translation ID for error message */
    translationId?: string;
}
/**
 * Service definition
 */
export interface Service {
    /** Unique service ID (format: svc_xxxxxxxx) */
    id: string;
    /** Service name (PascalCase ending with 'Service') */
    name: string;
    /** Associated entity ID (optional) */
    entityId?: string;
}
/**
 * Service API configuration
 */
export interface ServiceConfiguration {
    /** Unique configuration ID (format: cfg_xxxxxxxx) */
    id: string;
    /** Service ID this configuration applies to */
    serviceId: string;
    /** API host (IP or domain) */
    apiHost: string;
    /** API port number (optional) */
    apiPort?: number;
    /** API protocol */
    apiProtocol: "http" | "https";
    /** API endpoint path (must start with /) */
    apiEndPoint: string;
    /** HTTP query builder type */
    httpQueryBuilder?: "regular" | "mongodb" | "graphql";
    /** External entity ID field name */
    externalEntityId?: string;
}
/**
 * Entity field mapping
 */
export interface FieldMapping {
    /** Unique mapping ID (format: map_xxxxxxxx) */
    id: string;
    /** Entity ID */
    entityId: string;
    /** Internal field name */
    fieldKey: string;
    /** External field name (API response field) */
    externalKey: string;
    /** Service IDs this mapping applies to, or '*' for all */
    targetServices: string[] | "*";
}
/**
 * Use case definition
 */
export interface UseCase {
    /** Unique use case ID (format: uc_xxxxxxxx) */
    id: string;
    /** Use case name (PascalCase) */
    name: string;
    /** Entity ID this use case operates on */
    entityId: string;
    /** Use case type */
    type: "CRUD" | "Create" | "Search" | "Edit" | "View" | "Delete";
}
/**
 * Custom page definition
 */
export interface Page {
    /** Unique page ID (format: page_xxxxxxxx) */
    id: string;
    /** Page name (PascalCase) */
    name: string;
    /** Menu location */
    targetMenu?: "top" | "side" | "both";
    /** Page access level */
    targetSpace?: "public" | "private";
    /** Whether to update routing and menu */
    updateRouteMenu?: boolean;
}
/**
 * Authentication configuration
 */
export interface AuthenticationConfig {
    /** Authentication providers */
    providers?: AuthProvider[];
    /** ID of the default authentication provider */
    defaultProvider?: string;
    /** HTTP authentication configuration */
    httpConfig?: HttpAuthConfig;
}
/**
 * Authentication provider
 */
export interface AuthProvider {
    /** Unique auth provider ID (format: auth_xxxxxxxx) */
    id: string;
    /** Authentication provider type */
    provider: "dummy" | "keycloak" | "google" | "firebase" | "oauth2";
    /** Set as default provider */
    setAsDefault?: boolean;
    /** Provider-specific configuration */
    config?: Record<string, any>;
}
/**
 * HTTP authentication configuration
 */
export interface HttpAuthConfig {
    /** Header name for auth tokens */
    tokenHeader?: string;
    /** Token prefix (e.g., 'Bearer') */
    tokenPrefix?: string;
    /** Routes that don't require authentication */
    publicRoutes?: string[];
    /** Redirect path for unauthorized users */
    unauthorizedRedirect?: string;
    /** Include credentials in requests */
    withCredentials?: boolean;
    /** Token refresh retry limit */
    maxRefreshRetries?: number;
}
/**
 * Localization configuration
 */
export interface LocalizationConfig {
    /** Language definitions */
    languages?: Language[];
}
/**
 * Language definition
 */
export interface Language {
    /** Language code (ISO 639-1) */
    languageCode: string;
    /** Translation entries */
    translationEntries?: TranslationEntry[];
}
/**
 * Translation entry
 */
export interface TranslationEntry {
    /** Entity ID this translation applies to (optional) */
    targetEntityId?: string;
    /** Translation key (dot notation) */
    localeId: string;
    /** Translated value */
    localeValue: string;
}
/**
 * Type guards for entity members
 */
export declare function isSimpleMember(member: EntityMember): member is SimpleMember;
export declare function isCompositeMember(member: EntityMember): member is CompositeMember;
/**
 * ID prefix constants
 */
export declare const ID_PREFIXES: {
    readonly APPLICATION: "app_";
    readonly ENTITY: "ent_";
    readonly MEMBER: "mem_";
    readonly SERVICE: "svc_";
    readonly CONFIGURATION: "cfg_";
    readonly MAPPING: "map_";
    readonly USE_CASE: "uc_";
    readonly PAGE: "page_";
    readonly AUTH_PROVIDER: "auth_";
    readonly VALIDATOR: "val_";
};
/**
 * ID validation regex patterns
 */
export declare const ID_PATTERNS: {
    readonly APPLICATION: RegExp;
    readonly ENTITY: RegExp;
    readonly MEMBER: RegExp;
    readonly SERVICE: RegExp;
    readonly CONFIGURATION: RegExp;
    readonly MAPPING: RegExp;
    readonly USE_CASE: RegExp;
    readonly PAGE: RegExp;
    readonly AUTH_PROVIDER: RegExp;
    readonly VALIDATOR: RegExp;
};
/**
 * Utility function to generate unique IDs
 */
export declare function generateId(prefix: string): string;
/**
 * Utility function to validate ID format
 */
export declare function validateId(id: string, expectedPrefix: string): boolean;
