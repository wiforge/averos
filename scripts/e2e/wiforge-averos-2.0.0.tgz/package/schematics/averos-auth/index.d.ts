/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * file: averos-auth/index.ts
 */
import { Rule } from '@angular-devkit/schematics';
import { AverosAuthOption } from './schema';
/**
 * Supported authentication providers
 */
export declare enum AverosAuthProviderType {
    FIREBASE = "firebase",
    GOOGLE = "google",
    GITHUB = "github",
    KEYCLOAK = "keycloak",
    DUMMY = "dummy",
    CUSTOM = "custom"
}
export default function (option: AverosAuthOption): Rule;
