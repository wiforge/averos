"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AverosAuthProviderType = void 0;
exports.default = default_1;
/**
 * file: averos-auth/index.ts
 */
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const path_1 = require("path");
const util_1 = require("../util");
const change_1 = require("@schematics/angular/utility/change");
const package_util_1 = require("../util/package-util");
const rxjs_1 = require("rxjs");
const dependencies_1 = require("@schematics/angular/utility/dependencies");
/**
 * Supported authentication providers
 */
var AverosAuthProviderType;
(function (AverosAuthProviderType) {
    AverosAuthProviderType["FIREBASE"] = "firebase";
    AverosAuthProviderType["GOOGLE"] = "google";
    AverosAuthProviderType["GITHUB"] = "github";
    AverosAuthProviderType["KEYCLOAK"] = "keycloak";
    AverosAuthProviderType["DUMMY"] = "dummy";
    AverosAuthProviderType["CUSTOM"] = "custom";
})(AverosAuthProviderType || (exports.AverosAuthProviderType = AverosAuthProviderType = {}));
function default_1(option) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:averos-auth" `);
        context.logger.info(`🔧 Using options: ${JSON.stringify(option)}`);
        if (!option.provider || option.provider.trim() === '') {
            context.logger.error(`auth provider = ${option.provider} is INVALID`);
            context.logger.info('⏭️  Skipping authentication setup');
            return (0, schematics_1.noop)();
        }
        context.logger.info(`🔐 Configuring authentication provider: ${option.provider}`);
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!option.project) {
            option.project = workspace.projects.keys().next().value;
            if (!option.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`☑️ Authentication capability will be added to the project.`);
        context.logger.info(`🔍 Preparing to retrieve the project using: ${option.project}`);
        const project = workspace.projects.get(option.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${option.project}`);
        }
        if (option.path === undefined) { // source path
            option.path = (0, workspace_1.buildDefaultPath)(project);
        }
        return (0, schematics_1.chain)([
            addAuthProvider(option),
            installAuthProviderDependencies(option)
        ]);
    };
}
function addAuthProvider(option) {
    return async (host, context) => {
        let modulePath = (0, path_1.normalize)((0, path_1.join)((0, path_1.normalize)(option.path), '/app-module.ts'));
        if (!host.exists(modulePath)) {
            throw new Error(`❌ Unable to find the main application module in the following location: ${modulePath}`);
        }
        context.logger.info(`🔧 Module found at: ${modulePath}`);
        let source = (0, util_1.readIntoSourceFile)(host, modulePath);
        const updateModuleLanguage = integrateAuthToAverosModule(source, modulePath, option);
        const changes = updateModuleLanguage;
        const updateMainModulesRecorder = host.beginUpdate(modulePath);
        for (const change of changes) {
            (0, change_1.applyToUpdateRecorder)(updateMainModulesRecorder, [change]);
        }
        host.commitUpdate(updateMainModulesRecorder);
        context.logger.info(`🚀 The main application module has been successfully configured!`);
    };
}
function integrateAuthToAverosModule(source, modulePath, options) {
    if (!source || !modulePath) {
        return [new change_1.NoopChange()];
    }
    let providerType = '';
    let providerPackage = '@wiforge/averos';
    switch (options.provider) {
        case AverosAuthProviderType.DUMMY:
            providerType = 'AverosDummyAuthProvider';
            break;
        case AverosAuthProviderType.FIREBASE:
            providerType = 'AverosFirebaseAuthProvider';
            break;
        case AverosAuthProviderType.GITHUB:
            providerType = 'AverosFirebaseAuthProvider';
            break;
        case AverosAuthProviderType.GOOGLE:
            providerType = 'AverosFirebaseAuthProvider';
            break;
        case AverosAuthProviderType.KEYCLOAK:
            providerType = 'AverosKeycloakAuthProvider';
            break;
        case AverosAuthProviderType.CUSTOM:
            if (!options.customProviderClassName && !options.customProviderPackage) {
                return [new change_1.NoopChange()];
            }
            providerType = options.customProviderClassName;
            providerPackage = options.customProviderPackage;
            break;
        default:
            providerType = 'AverosDummyAuthProvider';
            break;
    }
    return (0, util_1.addOrUpdateAverosAuthProvider)(source, modulePath, providerType, providerPackage, options);
}
/**
 * Installs the required dependencies for the selected authentication provider
 */
function installAuthProviderDependencies(option) {
    return (host, context) => {
        const packageName = getAuthProviderPackageName(option.provider);
        if (!packageName) {
            context.logger.info(`ℹ️  No external dependencies required for provider: ${option.provider}`);
            return host;
        }
        context.logger.info(`📦 Installing required package: ${packageName}`);
        const packageMetadata = {
            packageName: packageName,
            type: dependencies_1.NodeDependencyType.Default
        };
        // Get package version and install
        (0, package_util_1.getPackageCompliantVersion)(packageMetadata)
            .pipe((0, rxjs_1.concatMap)((packageInfo) => {
            (0, package_util_1.addDependencyToPackageJson)(host, context, packageInfo);
            return (0, rxjs_1.of)(null);
            ;
        }))
            .subscribe({
            error: (err) => {
                context.logger.error(`❌ Failed to install ${packageName}: ${err.message}`);
            }
        });
        return host;
    };
}
/**
 * Maps authentication provider type to its required package name
 */
function getAuthProviderPackageName(provider) {
    switch (provider) {
        case AverosAuthProviderType.FIREBASE:
        case AverosAuthProviderType.GOOGLE:
        case AverosAuthProviderType.GITHUB:
            return 'firebase';
        case AverosAuthProviderType.KEYCLOAK:
            return 'keycloak-js';
        case AverosAuthProviderType.DUMMY:
        case AverosAuthProviderType.CUSTOM:
        default:
            return null;
    }
}
//# sourceMappingURL=index.js.map