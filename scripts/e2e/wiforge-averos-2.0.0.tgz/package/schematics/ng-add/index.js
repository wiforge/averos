"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const workspace_1 = require("@schematics/angular/utility/workspace");
const tasks_1 = require("@angular-devkit/schematics/tasks");
const rxjs_1 = require("rxjs");
const operators_1 = require("rxjs/operators");
const package_util_1 = require("../util/package-util");
/**
 * Main ng-add schematic entry point
 */
function default_1(options) {
    return (0, schematics_1.chain)([
        validateAndSetupOptions(options),
        addPackageJsonDependencies(),
        scheduleTaskChain(options)
    ]);
}
/**
 * Validates and sets up default options
 */
function validateAndSetupOptions(options) {
    return async (host, context) => {
        context.logger.info('🚀 Setting up Averos...');
        context.logger.info(`Options: ${JSON.stringify(options)}`);
        // Set default application name
        if (!options.applicationName?.trim()) {
            options.applicationName = 'MyFancyApplication';
            context.logger.info(`✅  Using default application name: ${options.applicationName}`);
        }
        // Set default language
        if (!options.defaultLanguageCode?.trim()) {
            options.defaultLanguageCode = 'en';
            context.logger.info('✅  Using default language: English (en)');
        }
        // Get workspace and project
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException('❌ Cannot retrieve the project.');
            }
        }
        context.logger.info(`🔍 Project: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        // Set default paths
        if (options.srcPath === undefined) {
            options.srcPath = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅  Source path: ${options.srcPath}`);
        }
        if (options.projectRootPath === undefined) {
            options.projectRootPath = `${project.root}/`;
            context.logger.info(`✅  Project root: ${options.projectRootPath}`);
        }
        return host;
    };
}
/**
 * Adds required dependencies to package.json
 */
function addPackageJsonDependencies() {
    return (host, context) => {
        context.logger.info('📦 Adding dependencies to package.json...');
        return (0, rxjs_1.of)(...package_util_1.REQUIRED_PACKAGES).pipe((0, operators_1.concatMap)((packageMetaData) => (0, package_util_1.getPackageCompliantVersion)(packageMetaData)), (0, operators_1.map)(packageInfo => {
            (0, package_util_1.addDependencyToPackageJson)(host, context, packageInfo);
            return host;
        }));
    };
}
/**
 * Schedules the task chain for Averos setup
 */
function scheduleTaskChain(options) {
    return (host, context) => {
        context.logger.info('🔧 Scheduling Averos setup tasks...');
        // Build task chain
        const installTaskId = undefined; // schedulePackageInstall(options, context); (REMOVED PACKAGE INSTALLATION)
        const initTaskId = scheduleInitialization(options, context, installTaskId);
        const defaultLangTaskId = scheduleDefaultLanguage(options, context, initTaskId);
        const additionalLangTaskId = scheduleAdditionalLanguage(options, context, defaultLangTaskId);
        const finalTaskId = additionalLangTaskId || defaultLangTaskId;
        schedulePostAdd(options, context, finalTaskId);
        context.logger.info('');
        context.logger.info('✨ Averos has been successfully configured!');
        context.logger.info('');
        context.logger.info('📝 Next step: Start building your application');
        context.logger.info('');
        return host;
    };
}
/**
 * Schedules npm install task
 */
function schedulePackageInstall(options, context) {
    if (options.skipInstall) {
        context.logger.info('⏭️  Skipping package installation');
        return undefined;
    }
    context.logger.info('📥 Scheduling package installation...');
    return context.addTask(new tasks_1.NodePackageInstallTask());
}
/**
 * Schedules Averos project initialization
 */
function scheduleInitialization(options, context, dependsOn) {
    context.logger.info('🔧 Scheduling project initialization...');
    const task = new tasks_1.RunSchematicTask('initialize-averos-project', options);
    return dependsOn !== undefined
        ? context.addTask(task, [dependsOn])
        : context.addTask(task);
}
/**
 * Schedules default language addition
 */
function scheduleDefaultLanguage(options, context, dependsOn) {
    context.logger.info(`🌐 Scheduling default language: ${options.defaultLanguageCode}`);
    const langOptions = {
        languageCode: options.defaultLanguageCode
    };
    const task = new tasks_1.RunSchematicTask('add-language', langOptions);
    return context.addTask(task, [dependsOn]);
}
/**
 * Schedules additional language addition (optional)
 */
function scheduleAdditionalLanguage(options, context, dependsOn) {
    if (!options.addNewLanguage) {
        context.logger.info('⏭️  Skipping additional language');
        return undefined;
    }
    context.logger.info('🌐 Scheduling additional language...');
    const task = new tasks_1.RunSchematicTask('add-language', {});
    return context.addTask(task, [dependsOn]);
}
/**
 * Schedules post-add tasks
 */
function schedulePostAdd(options, context, dependsOn) {
    context.logger.info('🎬 Scheduling post-add tasks...');
    const task = new tasks_1.RunSchematicTask('post-add', options);
    return context.addTask(task, [dependsOn]);
}
//# sourceMappingURL=index.js.map