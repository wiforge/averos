"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const workspace_1 = require("@schematics/angular/utility/workspace");
const default_icons_1 = require("./default-icons");
function default_1(options) {
    return (host, context) => {
        if (!options.projectRootPath) {
            throw new schematics_1.SchematicsException(`❌ Cannot find a valid project root path! Make sure to run the command inside an angular project.`);
        }
        const templatesPath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), 'src'));
        const templateSource = (0, schematics_1.apply)((0, schematics_1.url)('./files'), [
            (0, schematics_1.applyTemplates)({
                ...options
            }),
            (0, schematics_1.move)(templatesPath)
        ]);
        return (0, schematics_1.chain)([
            (0, schematics_1.mergeWith)(templateSource, schematics_1.MergeStrategy.Overwrite),
            updateAngularJSON(options),
            addCoreIcons(options),
            (options) => {
                return async (host, context) => {
                    context.logger.info(`🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉   GOOD JOB!  🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉`);
                    context.logger.info(`🎉                                                                                                      🎉`);
                    context.logger.info(`🎉  Congratulations! Your averos project is ready to grow! Go ahead and grow your business!             🎉`);
                    context.logger.info(`🎉                                                                                                      🎉`);
                    context.logger.info(`🎉                           🔥  Enjoy your AVEROS journey!  🔥                                         🎉`);
                    context.logger.info(`🎉                                                                                                      🎉`);
                    context.logger.info(`🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉`);
                };
            }
        ])(host, context);
    };
}
function updateAngularJSON(options) {
    return async (host, context) => {
        let angularJSONFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `angular.json`));
        if (!host.exists(angularJSONFile)) {
            throw new Error(`❌ Unable to find angular.json on the following location: ${angularJSONFile}!\n Make sure you are in an angular project!`);
        }
        else {
            // add averos style
            const angularjsonFile = host.read(angularJSONFile);
            if (!angularjsonFile) {
                throw new Error(`❌ No angular.json file found for this project! Please make sure this is an angular project.`);
            }
            let fileUpdated = false;
            // if(!angularjsonFile.includes('stylePreprocessorOptions')){
            let angularJSONData = JSON.parse(angularjsonFile.toString());
            const workspace = await (0, workspace_1.getWorkspace)(host);
            let projectName = workspace.projects.keys().next().value;
            // configure @angular/localize/init in polyfills
            if (angularJSONData?.projects[`${projectName}`]?.architect?.build?.options) {
                angularJSONData.projects[`${projectName}`].architect.build.options.polyfills =
                    [
                        "zone.js", "@angular/localize/init"
                    ];
                fileUpdated = true;
            }
            if (angularJSONData?.projects[`${projectName}`]?.architect?.test?.options) {
                angularJSONData.projects[`${projectName}`].architect.build.options.polyfills =
                    [
                        "zone.js", "@angular/localize/init"
                    ];
                fileUpdated = true;
            }
            // Add assets/favicon.ico to the assets
            if (angularJSONData?.projects[`${projectName}`]?.architect?.build?.options?.assets) {
                angularJSONData.projects[`${projectName}`].architect.build.options.assets =
                    [
                        {
                            "glob": "**/*",
                            "input": "public"
                        },
                        "src/favicon.ico", "src/assets"
                    ];
                fileUpdated = true;
            }
            if (angularJSONData?.projects[`${projectName}`]?.architect?.test?.options?.assets) {
                angularJSONData.projects[`${projectName}`].architect.test.options.assets =
                    [
                        {
                            "glob": "**/*",
                            "input": "public"
                        },
                        "src/favicon.ico", "src/assets"
                    ];
                fileUpdated = true;
            }
            //Add StylePreprocessorOptions attributes to angular.json file
            if (!angularJSONData?.projects[`${projectName}`]?.architect?.build?.options?.stylePreprocessorOptions) {
                angularJSONData.projects[`${projectName}`].architect.build.options.stylePreprocessorOptions =
                    {
                        includePaths: [
                            "node_modules",
                            "src/assets/styles"
                        ]
                    };
                fileUpdated = true;
            }
            //Add allowedCommonJsDependencies attribute to angular.json file
            if (!angularJSONData?.projects[`${projectName}`]?.architect?.build?.options?.allowedCommonJsDependencies) {
                angularJSONData.projects[`${projectName}`].architect.build.options.allowedCommonJsDependencies =
                    [
                        "file-saver"
                    ];
                fileUpdated = true;
            }
            //Update build budget for production
            if (!!angularJSONData?.projects[`${projectName}`]?.architect?.build?.configurations?.production?.budgets) {
                angularJSONData.projects[`${projectName}`].architect.build.configurations.production.budgets =
                    [
                        {
                            type: "initial",
                            maximumWarning: "5mb",
                            maximumError: "7mb"
                        },
                        {
                            type: "anyComponentStyle",
                            maximumWarning: "6kb",
                            maximumError: "10kb"
                        }
                    ];
                fileUpdated = true;
            }
            if (fileUpdated) {
                host.overwrite(angularJSONFile, JSON.stringify(angularJSONData));
            }
            // }
            context.logger.info(`✅ Your application angular.json file was updated successfully!`);
        }
    };
}
function addCoreIcons(options) {
    return async (host, context) => {
        options.srcPath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), 'src'));
        context.logger.info(`✅ Using the default application source path for icons: ${options.srcPath}`);
        let iconsConfigFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.srcPath), `/assets/icons/svg/icons.json`));
        // reading the json icon configuration file
        if (!host.exists(iconsConfigFile)) {
            host.create(iconsConfigFile, '{}');
        }
        // create default theme icons
        (0, default_icons_1.getDefaultIconsTheme)().forEach(iconMetadata => {
            let svgIcon = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.srcPath), `/assets/icons/svg/default/${iconMetadata.iconName}.svg`));
            if (!host.exists(svgIcon)) {
                host.create(svgIcon, '');
            }
            // create the icon
            host.overwrite(svgIcon, iconMetadata.iconContent);
        });
        // create filled theme icons
        (0, default_icons_1.getFilledIconsTheme)().forEach(iconMetadata => {
            let svgIcon = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.srcPath), `/assets/icons/svg/filled/${iconMetadata.iconName}.svg`));
            if (!host.exists(svgIcon)) {
                host.create(svgIcon, '');
            }
            // create the icon
            host.overwrite(svgIcon, iconMetadata.iconContent);
        });
        // create outlined theme icons
        (0, default_icons_1.getOutlinedIconsTheme)().forEach(iconMetadata => {
            let svgIcon = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.srcPath), `/assets/icons/svg/outlined/${iconMetadata.iconName}.svg`));
            if (!host.exists(svgIcon)) {
                host.create(svgIcon, '');
            }
            // create the icon
            host.overwrite(svgIcon, iconMetadata.iconContent);
        });
        // insert icons.json config file
        host.overwrite(iconsConfigFile, (0, default_icons_1.getDefaultIconsConfig)());
        context.logger.info(`✅ Default icons template was successfully added to your application!`);
    };
}
//# sourceMappingURL=post-add.js.map