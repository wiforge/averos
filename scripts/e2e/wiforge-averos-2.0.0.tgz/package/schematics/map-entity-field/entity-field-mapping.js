"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.mapEntityFieldToExternalField = mapEntityFieldToExternalField;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const workspace_1 = require("@schematics/angular/utility/workspace");
const util_1 = require("../util");
function mapEntityFieldToExternalField(entityFieldMappingOption) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:map-entity-field"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(entityFieldMappingOption)}`);
        /// Option Setup ////////////
        if (!entityFieldMappingOption.entityName || entityFieldMappingOption.entityName.trim() === '') {
            throw new schematics_1.SchematicsException(`Entity Name is mandatory! Please provide one`);
        }
        if (!entityFieldMappingOption.fieldKey || entityFieldMappingOption.fieldKey.trim() === '') {
            throw new schematics_1.SchematicsException(`Entity field key name is mandatory! Please provide one`);
        }
        if (!entityFieldMappingOption.externalKey || entityFieldMappingOption.externalKey.trim() === '') {
            throw new schematics_1.SchematicsException(`External field key name is mandatory! Please provide one`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!entityFieldMappingOption.project) {
            entityFieldMappingOption.project = workspace.projects.keys().next().value;
            if (!entityFieldMappingOption.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${entityFieldMappingOption.project}`);
        const project = workspace.projects.get(entityFieldMappingOption.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${entityFieldMappingOption.project}`);
        }
        entityFieldMappingOption.projectRootPath = `${project.root}/`;
        if (entityFieldMappingOption.path === undefined) {
            entityFieldMappingOption.path = (0, workspace_1.buildDefaultPath)(project);
        }
        ///// End Options Setup
        return (0, schematics_1.chain)([
            createEntityFieldMapping(entityFieldMappingOption)
        ]);
    };
}
function createEntityFieldMapping(entityFieldMappingOption) {
    return async (host, context) => {
        let environmentConfigurationLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(entityFieldMappingOption.projectRootPath), `src/assets/entity/`));
        let dirEntry = host.getDir(environmentConfigurationLocation);
        let entityConfigurationFileDirEntry = dirEntry.subfiles.find(e => e === `entity-config.json`);
        let entityConfigurationFile;
        if (!entityConfigurationFileDirEntry) {
            entityConfigurationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), `entity-config.json`));
        }
        else {
            entityConfigurationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), entityConfigurationFileDirEntry));
        }
        if (!host.exists(entityConfigurationFile)) {
            /// create the file if it does not exist
            let envConfig = new util_1.EntityConfiguration();
            host.create(entityConfigurationFile, JSON.stringify(envConfig));
        }
        let entityConfigurationContent = host.read(entityConfigurationFile);
        if (!entityConfigurationContent) {
            throw new Error(`❌ No entity configuration found for your application!`);
        }
        let entityConfigData = JSON.parse(entityConfigurationContent.toString());
        entityConfigData = updateEntityConfiguration(entityConfigData, entityFieldMappingOption, context);
        host.overwrite(entityConfigurationFile, JSON.stringify(entityConfigData));
        context.logger.info(`✅ The requested entity configuration entry has been added/updated successfully!`);
    };
}
//V1
// function updateEntityConfiguration(
//   config: EntityConfiguration,
//   mappingOption: EntityFieldMappingOption,
//   context: SchematicContext
// ): EntityConfiguration {
//   const targetServicesArray = parseToArray(mappingOption.targetServices);
//   const entityName = strings.classify(toValidIdentifier(mappingOption.entityName, 'class'));
//   const fieldKey = mappingOption.fieldKey;
//   const externalKey = mappingOption.externalKey;
//   const updatedConfig = new EntityConfiguration();
//   updatedConfig.globalAPICollectionResponseMappingLookup = config.globalAPICollectionResponseMappingLookup;
//   const originalEntityItem = config.configurationItems
//     .map(EntityConfigurationItem.fromJSON)
//     .find(e => e.configurationId === entityName);
//   updatedConfig.configurationItems = config.configurationItems
//     .map(EntityConfigurationItem.fromJSON)
//     .filter(item => item.configurationId !== entityName)
//     .map(item => item.clone());
//   if (isNull(originalEntityItem)) {
//     const newItem = new EntityConfigurationItem(
//       entityName,
//       entityName,
//       `${mappingOption.entityName.toLowerCase()}_lifecycle`
//     );
//     const newMapping = new EntityKeysMapping(targetServicesArray, {
//       [fieldKey]: externalKey
//     });
//     newItem.externalKeysMapping.push(newMapping);
//     updatedConfig.configurationItems.push(newItem);
//     return updatedConfig;
//   }
//   const updatedItem = originalEntityItem.clone();
//   const newMappings: EntityKeysMapping[] = [];
//   const serviceToMapping: Map<string, EntityKeysMapping> = new Map();
//   // Flatten current mappings to a map (service -> mapping)
//   for (const ekm of updatedItem.externalKeysMapping) {
//     for (const service of ekm.targetServices) {
//       if (!serviceToMapping.has(service)) {
//         // throw new Error(`Duplicate mapping found for service: ${service}`);
//         // context.logger.warn(`⚠️ Duplicate mapping found for service: {${service}} !\n Updating the current existing mapping record...\n`);
//         serviceToMapping.set(service, ekm);
//         // continue;
//       } 
//       // else {
//       //   serviceToMapping.set(service, ekm);
//       // }
//     }
//   }
//   const servicesToUpdate = new Set(targetServicesArray);
//   const processedMappings = new Set<EntityKeysMapping>();
//   for (const ekm of updatedItem.externalKeysMapping) {
//     const intersection = ekm.targetServices.filter(s => servicesToUpdate.has(s));
//     if (intersection.length === 0) {
//       newMappings.push(ekm.clone());
//       continue;
//     }
//     // Remaining services after removing intersection
//     const remainingServices = ekm.targetServices.filter(s => !servicesToUpdate.has(s));
//     if (remainingServices.length > 0) {
//       const remainingMapping = ekm.clone();
//       remainingMapping.targetServices = remainingServices;
//       newMappings.push(remainingMapping);
//     }
//     // Build new mapping for intersecting services with updated keys
//     const updatedKeysMapping = { ...ekm.keysMapping, [fieldKey]: externalKey };
//     const updatedMapping = new EntityKeysMapping(intersection, updatedKeysMapping);
//     newMappings.push(updatedMapping);
//     processedMappings.add(ekm);
//   }
//   // Special case: wildcard
//   if (targetServicesArray.includes("*")) {
//     const wildcard = updatedItem.externalKeysMapping.find(
//       ekm => ekm.targetServices.length === 1 && ekm.targetServices[0] === "*"
//     );
//     if (wildcard) {
//       wildcard.keysMapping[fieldKey] = externalKey;
//       newMappings.push(wildcard.clone());
//     } else {
//       const wildcardMapping = new EntityKeysMapping(["*"], {
//         [fieldKey]: externalKey
//       });
//       newMappings.push(wildcardMapping);
//     }
//   } else {
//     for (const service of targetServicesArray) {
//       if (!serviceToMapping.has(service)) {
//         // New service mapping
//         const newMapping = new EntityKeysMapping([service], {
//           [fieldKey]: externalKey
//         });
//         newMappings.push(newMapping);
//       }
//     }
//   }
//   // Group mappings by identical key mappings
//   const groupedMap = new Map<string, EntityKeysMapping>();
//   for (const ekm of newMappings) {
//     const key = JSON.stringify(ekm.keysMapping);
//     if (groupedMap.has(key)) {
//       const existing = groupedMap.get(key)!;
//       existing.targetServices.push(...ekm.targetServices);
//     } else {
//       groupedMap.set(key, ekm.clone());
//     }
//   }
//   // Remove duplicate services across groups and ensure uniqueness (Rule10 + Rule11)
//   const finalMappings: EntityKeysMapping[] = [];
//   const seenServices = new Set<string>();
//   for (const mapping of groupedMap.values()) {
//     const uniqueServices = mapping.targetServices.filter(s => !seenServices.has(s));
//     if (uniqueServices.length === 0) continue;
//     const keysMap = Object.entries(mapping.keysMapping).reduce((acc, [k, v]) => {
//       acc[k] = v;
//       return acc;
//     }, {} as Record<string, string | number>);
//     // Remove potential duplicate keys
//     const seenKeys = new Set<string>();
//     for (const k of Object.keys(keysMap)) {
//       if (seenKeys.has(k)) delete keysMap[k];
//       else seenKeys.add(k);
//     }
//     finalMappings.push(
//       new EntityKeysMapping([...uniqueServices].sort(), keysMap)
//     );
//     uniqueServices.forEach(s => seenServices.add(s));
//   }
//   updatedItem.externalKeysMapping = finalMappings;
//   updatedConfig.configurationItems.push(updatedItem);
//   return updatedConfig;
// }
// V2
// function updateEntityConfiguration(
//   config: EntityConfiguration,
//   mappingOption: EntityFieldMappingOption,
//   context: SchematicContext
// ): EntityConfiguration {
//   const targetServicesArray = parseToArray(mappingOption.targetServices);
//   const entityName = strings.classify(toValidIdentifier(mappingOption.entityName, 'class'));
//   const fieldKey = mappingOption.fieldKey;
//   const externalKey = mappingOption.externalKey;
//   const updatedConfig = new EntityConfiguration();
//   updatedConfig.globalAPICollectionResponseMappingLookup = config.globalAPICollectionResponseMappingLookup;
//   const originalEntityItem = config.configurationItems
//     .map(EntityConfigurationItem.fromJSON)
//     .find(e => e.configurationId === entityName);
//   updatedConfig.configurationItems = config.configurationItems
//     .map(EntityConfigurationItem.fromJSON)
//     .filter(item => item.configurationId !== entityName)
//     .map(item => item.clone());
//   if (isNull(originalEntityItem)) {
//     const newItem = new EntityConfigurationItem(
//       entityName,
//       entityName,
//       `${mappingOption.entityName.toLowerCase()}_lifecycle`
//     );
//     const newMapping = new EntityKeysMapping(targetServicesArray, {
//       [fieldKey]: externalKey
//     });
//     newItem.externalKeysMapping.push(newMapping);
//     updatedConfig.configurationItems.push(newItem);
//     return updatedConfig;
//   }
//   const updatedItem = originalEntityItem.clone();
//   const newMappings: EntityKeysMapping[] = [];
//   const serviceToMapping: Map<string, EntityKeysMapping> = new Map();
//   for (const ekm of updatedItem.externalKeysMapping) {
//     for (const service of ekm.targetServices) {
//       if (serviceToMapping.has(service)) {
//         context.logger.warn(`⚠️ Duplicate mapping found for service: {${service}} !\n Updating the current existing mapping record...\n`);
//       } else {
//         serviceToMapping.set(service, ekm);
//       }
//     }
//   }
//   const servicesToUpdate = new Set(targetServicesArray);
//   const isWildcard = targetServicesArray.includes("*");
//   if (isWildcard) {
//     // Handle wildcard exclusively — update existing or create new
//     const existingWildcard = updatedItem.externalKeysMapping.find(
//       ekm => ekm.targetServices.length === 1 && ekm.targetServices[0] === "*"
//     );
//     // Keep all non-wildcard mappings unchanged
//     for (const ekm of updatedItem.externalKeysMapping) {
//       if (!(ekm.targetServices.length === 1 && ekm.targetServices[0] === "*")) {
//         newMappings.push(ekm.clone());
//       }
//     }
//     if (existingWildcard) {
//       // Update the existing wildcard mapping in place
//       const updated = existingWildcard.clone();
//       updated.keysMapping[fieldKey] = externalKey;
//       newMappings.push(updated);
//     } else {
//       newMappings.push(new EntityKeysMapping(["*"], { [fieldKey]: externalKey }));
//     }
//   } else {
//     // Normal (non-wildcard) path
//     for (const ekm of updatedItem.externalKeysMapping) {
//       const intersection = ekm.targetServices.filter(s => servicesToUpdate.has(s));
//       if (intersection.length === 0) {
//         newMappings.push(ekm.clone());
//         continue;
//       }
//       const remainingServices = ekm.targetServices.filter(s => !servicesToUpdate.has(s));
//       if (remainingServices.length > 0) {
//         const remainingMapping = ekm.clone();
//         remainingMapping.targetServices = remainingServices;
//         newMappings.push(remainingMapping);
//       }
//       const updatedKeysMapping = { ...ekm.keysMapping, [fieldKey]: externalKey };
//       newMappings.push(new EntityKeysMapping(intersection, updatedKeysMapping));
//     }
//     // Add mappings for services not yet seen
//     for (const service of targetServicesArray) {
//       if (!serviceToMapping.has(service)) {
//         newMappings.push(new EntityKeysMapping([service], { [fieldKey]: externalKey }));
//       }
//     }
//   }
//   // Group mappings by identical key mappings
//   const groupedMap = new Map<string, EntityKeysMapping>();
//   for (const ekm of newMappings) {
//     const key = JSON.stringify(ekm.keysMapping);
//     if (groupedMap.has(key)) {
//       groupedMap.get(key)!.targetServices.push(...ekm.targetServices);
//     } else {
//       groupedMap.set(key, ekm.clone());
//     }
//   }
//   // Deduplicate services across groups
//   const finalMappings: EntityKeysMapping[] = [];
//   const seenServices = new Set<string>();
//   for (const mapping of groupedMap.values()) {
//     const uniqueServices = mapping.targetServices.filter(s => !seenServices.has(s));
//     if (uniqueServices.length === 0) continue;
//     const keysMap = { ...mapping.keysMapping };
//     finalMappings.push(new EntityKeysMapping([...uniqueServices].sort(), keysMap));
//     uniqueServices.forEach(s => seenServices.add(s));
//   }
//   updatedItem.externalKeysMapping = finalMappings;
//   updatedConfig.configurationItems.push(updatedItem);
//   return updatedConfig;
// }
// V3
function updateEntityConfiguration(config, mappingOption, context) {
    const targetServicesArray = parseToArray(mappingOption.targetServices);
    const entityName = core_1.strings.classify((0, util_1.toValidIdentifier)(mappingOption.entityName, 'class'));
    const fieldKey = mappingOption.fieldKey;
    const externalKey = mappingOption.externalKey;
    const updatedConfig = new util_1.EntityConfiguration();
    updatedConfig.globalAPICollectionResponseMappingLookup = config.globalAPICollectionResponseMappingLookup;
    const originalEntityItem = config.configurationItems
        .map(util_1.EntityConfigurationItem.fromJSON)
        .find(e => e.configurationId === entityName);
    updatedConfig.configurationItems = config.configurationItems
        .map(util_1.EntityConfigurationItem.fromJSON)
        .filter(item => item.configurationId !== entityName)
        .map(item => item.clone());
    if (isNull(originalEntityItem)) {
        const newItem = new util_1.EntityConfigurationItem(entityName, entityName, `${mappingOption.entityName.toLowerCase()}_lifecycle`);
        newItem.externalKeysMapping.push(new util_1.EntityKeysMapping(targetServicesArray, { [fieldKey]: externalKey }));
        updatedConfig.configurationItems.push(newItem);
        return updatedConfig;
    }
    const updatedItem = originalEntityItem.clone();
    // Flatten to a per-service map ────────────────────────────────────
    // Each service gets its own independent keysMapping copy
    const perServiceMap = new Map();
    for (const ekm of updatedItem.externalKeysMapping) {
        for (const service of ekm.targetServices) {
            if (perServiceMap.has(service)) {
                context.logger.warn(`⚠️ Duplicate mapping found for service: {${service}} !\n Updating the current existing mapping record...\n`);
                // Merge keys into the existing entry (last-write wins per key)
                Object.assign(perServiceMap.get(service), ekm.keysMapping);
            }
            else {
                perServiceMap.set(service, { ...ekm.keysMapping });
            }
        }
    }
    // Apply the update to targeted services ───────────────────────────
    for (const service of targetServicesArray) {
        if (perServiceMap.has(service)) {
            // Update the specific field on this service's mapping
            perServiceMap.get(service)[fieldKey] = externalKey;
        }
        else {
            // New service — start with just this key
            perServiceMap.set(service, { [fieldKey]: externalKey });
        }
    }
    // Re-group services with identical kesMappings ───────────────────
    // Use a stable JSON key so order doesn't matter
    const groupedMap = new Map();
    for (const [service, keysMapping] of perServiceMap.entries()) {
        const groupKey = stableStringify(keysMapping);
        if (groupedMap.has(groupKey)) {
            groupedMap.get(groupKey).services.push(service);
        }
        else {
            groupedMap.set(groupKey, { services: [service], keysMapping: { ...keysMapping } });
        }
    }
    // Build final EntityKeysMapping list ──────────────────────────────
    updatedItem.externalKeysMapping = Array.from(groupedMap.values()).map(({ services, keysMapping }) => new util_1.EntityKeysMapping([...services].sort(), keysMapping));
    updatedConfig.configurationItems.push(updatedItem);
    return updatedConfig;
}
// Stable stringify: sorts keys so {a:1, b:2} and {b:2, a:1} produce the same string
function stableStringify(obj) {
    return JSON.stringify(Object.keys(obj).sort().reduce((acc, k) => ({ ...acc, [k]: obj[k] }), {}));
}
function isNull(object) {
    if (object === null
        || object === undefined
        || (object instanceof Array && object.length === 0)
        || (typeof object === 'string' && object.trim() === '')
        || (typeof object === 'number' && object === 0)) {
        return true;
    }
    else {
        return false;
    }
}
function parseToArray(input) {
    if (!input) {
        return ["*"];
    }
    return input.split(',').map(item => item.trim());
}
//# sourceMappingURL=entity-field-mapping.js.map