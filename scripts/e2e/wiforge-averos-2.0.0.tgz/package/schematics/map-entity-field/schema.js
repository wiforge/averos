"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EntityFieldMappingOption = void 0;
class EntityFieldMappingOption {
    // The name of the entity.
    entityName;
    // The entity field key name
    fieldKey;
    // The target field key name
    externalKey;
    // The target external managing service
    targetServices;
    // The path to the sources.
    path;
    // The name of the project.
    project;
    // the project root path
    projectRootPath;
}
exports.EntityFieldMappingOption = EntityFieldMappingOption;
//# sourceMappingURL=schema.js.map