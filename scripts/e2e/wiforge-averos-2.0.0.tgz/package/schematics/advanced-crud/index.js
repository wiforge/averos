"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const path_1 = require("path");
const workspace_1 = require("@schematics/angular/utility/workspace");
const util_1 = require("../util");
const ts = require("typescript");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:advanced-crud"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        let entityAlreadyExists = false;
        if (!options.ename || options.ename.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ Entity Name is mandatory! Please provide one`);
        }
        // transform the class name into a valid class identifier
        options.ename = (0, util_1.toValidIdentifier)(options.ename, 'class');
        // Check wether the use case is already created
        const createUseCaseFilePath = (0, util_1.findClassImplementationFilePath)(host, core_1.strings.classify(`Create${options.ename}`));
        const searcheUseCaseFilePath = (0, util_1.findClassImplementationFilePath)(host, core_1.strings.classify(`Search${options.ename}`));
        if (createUseCaseFilePath || searcheUseCaseFilePath) {
            context.logger.info(`⚠️ The advanced crud use case does already exist!\n ⏭️ Skipping the use case creation \n`);
            return (0, schematics_1.noop)();
        }
        //Retrieve the related service if it already exists
        if ((!options.sname || options.sname === undefined) && options.ename) {
            let entityFilePath = (0, path_1.normalize)((0, path_1.join)((0, path_1.normalize)(options.path), `model/${core_1.strings.dasherize(options.ename)}.ts`));
            const text = host.read(entityFilePath);
            if (text !== null) {
                const sourceText = text.toString('utf-8');
                let entitySource = ts.createSourceFile(entityFilePath, sourceText, ts.ScriptTarget.Latest, true);
                let sname = (0, util_1.getServiceName)(entitySource);
                if (sname && sname !== '') {
                    // if (sname.endsWith("Service")){
                    //   sname = sname.slice(0, sname.length - 7)
                    // }
                    options.sname = sname;
                }
                else { // Create a default service name
                    options.sname = `${options.ename}Service`;
                    context.logger.info(`✅ Using the default entity service: ${options.sname}`);
                }
            }
            else { // Create a default service name
                options.sname = `${options.ename}Service`;
                context.logger.info(`✅ Using the default entity service: ${options.sname}`);
            }
        }
        context.logger.info(`⚙️⚙️⚙️⚙️⚙️⚙️⚙️⚙️⚙️  STARTING A NEW AVEROS WORKFLOW : CREATE AVEROS ADVANCED CRUD COMPONENTS  ⚙️⚙️⚙️⚙️⚙️⚙️⚙️⚙️⚙️`);
        let averosEntityOptions = {
            name: options.ename,
            sname: options.sname,
            createService: true
        };
        let createEntityUCOptions = {
            name: `Create${options.ename}`,
            ename: options.ename,
            sname: options.sname
        };
        let searchEntityUCOptions = {
            name: `Search${options.ename}`,
            ename: options.ename,
            sname: options.sname
        };
        const templatesPath = (0, path_1.normalize)((0, path_1.join)((0, path_1.normalize)(options.path), 'model') + '/');
        const entityRelativePath = `${templatesPath}/${core_1.strings.dasherize(options.ename)}.ts`;
        if (host.exists(entityRelativePath)) {
            entityAlreadyExists = true;
        }
        return (0, schematics_1.chain)([
            entityAlreadyExists ? (0, schematics_1.noop)() : (0, schematics_1.schematic)('averos-entity', averosEntityOptions),
            (0, schematics_1.schematic)('create-entity-uc', createEntityUCOptions),
            (0, schematics_1.schematic)('search-entity-uc', searchEntityUCOptions),
            (options) => {
                return async (host, context) => {
                    context.logger.info(`🎉🎉🎉🎉🎉🎉🎉  Congratulations! Your AVEROS ADVANCED CRUD have been implemented successfully! Enjoy!  🎉🎉🎉🎉🎉🎉🎉`);
                };
            }
        ]);
    };
}
//# sourceMappingURL=index.js.map