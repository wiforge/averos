"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.addDefaultMemberViewLayoutToEntityVL = addDefaultMemberViewLayoutToEntityVL;
exports.createDefaultTranslationKeys = createDefaultTranslationKeys;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const workspace_1 = require("@schematics/angular/utility/workspace");
const change_1 = require("@schematics/angular/utility/change");
const util_1 = require("../util");
const ts = require("typescript");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:add-simple-member"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup //////////////
        if (!options.ename || options.ename.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ Entity Name is mandatory! Please provide one`);
        }
        if (!options.mname || options.mname.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The field type is mandatory! Please provide one`);
        }
        if (!options.memberType || options.memberType.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The relation type with the member you wish to add is mandatory! Please provide one`);
        }
        if (options.memberType.toLowerCase() === 'enumeration' && (!options.listOfEnumValues || options.listOfEnumValues.trim() === '')) {
            throw new schematics_1.SchematicsException(`❌ The member you are trying to add is of type << enumeration >> but no values were provided!\n Please provide a list of values for the new eumeration member [--listOfEnumValues]`);
        }
        // transform the member name into a valid Class Identifier
        options.mname = (0, util_1.toValidIdentifier)(options.mname);
        // transform the entity class name into a valid Class name if not already
        options.ename = (0, util_1.toValidIdentifier)(options.ename, 'class');
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        ///// END Option Setup////////////////////////
        const templatesPath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'model') + '/');
        const entityRelativePath = `${templatesPath}/${core_1.strings.dasherize(options.ename)}.ts`;
        if (!host.exists(entityRelativePath)) {
            throw new schematics_1.SchematicsException(`❌ Entity ${options.ename} does not exist in the following location: ${entityRelativePath} `);
        }
        if (options.technicalId && options.businessId) {
            throw new schematics_1.SchematicsException(`❌ The entity member to be added could not be qualified as technical identifier and business identifier in the same time! Please use one of the qualification but not both on the same field.`);
        }
        if (options.memberType !== 'string' && options.memberType !== 'number' && (options.technicalId || options.businessId)) {
            throw new schematics_1.SchematicsException(`❌ A techical identifier or a business identifier should either be 'number' or 'string'.`);
        }
        context.logger.info(`🌱 Entity ${options.memberType} relation with the field seeds named ${options.mname} is being sown...`);
        context.logger.info(`🌱 Entity View layout default configuration seeds are being sown...`);
        return (0, schematics_1.chain)([
            options.memberType === 'enumeration' ? (0, schematics_1.schematic)('add-enumeration-member', { ename: options.ename, mname: options.mname, listOfEnumValues: options.listOfEnumValues }) : (0, schematics_1.noop)(),
            options.memberType !== 'enumeration' ? registerSimpleMember(options) : (0, schematics_1.noop)(),
            options.memberType !== 'enumeration' && !options.technicalId ? addDefaultMemberViewLayoutToEntityVL(options) : (0, schematics_1.noop)(),
            options.memberType !== 'enumeration' ? createDefaultTranslationKeys(options) : (0, schematics_1.noop)()
        ]);
    };
}
function registerSimpleMember(options) {
    return async (host, context) => {
        context.logger.info(`☑️ Entity with name ${options.ename} will be Updated...`);
        let entityFilePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), `model/${core_1.strings.dasherize(options.ename)}.ts`));
        if (!host.exists(entityFilePath)) {
            throw new schematics_1.SchematicsException(`❌ Unable to find the averos entity << ${options.ename} >> in the following location: ${entityFilePath}`);
        }
        let source = (0, util_1.readIntoSourceFile)(host, entityFilePath);
        // const importMemberEntityType = insertImport(source as any, entityFilePath, options.mname, `./${strings.dasherize(options.mname)}`);
        const updateEntityWithNewMember = addMemberToEntity(source, entityFilePath, options, context);
        const changes = [updateEntityWithNewMember];
        const recorder = host.beginUpdate(entityFilePath);
        for (const change of changes) {
            if (change instanceof change_1.InsertChange) {
                recorder.insertLeft(change.pos, change.toAdd);
            }
            else {
                (0, change_1.applyToUpdateRecorder)(recorder, [change]);
            }
        }
        host.commitUpdate(recorder);
    };
}
function addMemberToEntity(source, entityPath, options, context) {
    if (options.technicalId) {
        return addSimpleAnnotatedMemberToEntity(source, entityPath, options, 'ID', context);
    }
    else if (options.businessId) {
        return addSimpleAnnotatedMemberToEntity(source, entityPath, options, 'BusinessID', context);
    }
    else {
        return addSimpleMemberToEntity(source, entityPath, options, context);
    }
}
function addSimpleMemberToEntity(source, entityPath, options, context) {
    if (!source || !entityPath) {
        return new change_1.NoopChange();
    }
    let memberName = options.mname;
    const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
    if (!classDeclarationNode) { // no entity class declaration found
        throw new Error(`❌ No Class Declaration Found!`);
    }
    const propertiesDeclarationNodes__ = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.PropertyDeclaration);
    const memberDeclaration = propertiesDeclarationNodes__?.find((n) => n.name?.text === memberName);
    if (memberDeclaration) { // Member already declared
        // throw new Error(
        //   `❌ Member << ${memberName} >> is already declared in the entity << ${options.ename} >>!`
        // )
        context.logger.warn(`⚠️ Field {${memberName}} is already declared in the entity  {${options.ename}} !\n ⏭️ Skipping the field creation \n`);
        return new change_1.NoopChange();
    }
    // add the new member declaration to the entity
    let positionToInsertMember = classDeclarationNode.getChildAt(classDeclarationNode.getChildCount() - 3).getEnd();
    if (propertiesDeclarationNodes__ && propertiesDeclarationNodes__.length > 0) {
        positionToInsertMember = propertiesDeclarationNodes__.reduce((previous, current) => {
            return previous + current.getFullWidth();
        }, positionToInsertMember);
    }
    let mType = getMemberType(options.memberType.toLowerCase());
    let data = `\n    ${memberName.concat(`!: ${mType}`)};\n`;
    return new change_1.InsertChange(entityPath, positionToInsertMember, data);
}
function addSimpleAnnotatedMemberToEntity(source, entityPath, options, annotation, context) {
    if (!source || !entityPath) {
        return new change_1.NoopChange();
    }
    let memberName = options.mname;
    const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
    if (!classDeclarationNode) { // no entity class declaration found
        throw new Error(`❌ No Class Declaration Found!`);
    }
    const propertiesDeclarationNodes__ = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.PropertyDeclaration);
    const memberDeclaration = propertiesDeclarationNodes__?.find((n) => n.name?.text === memberName);
    if (memberDeclaration) { // Member already declared
        // throw new Error(
        //   `❌ Member << ${memberName} >> is already declared in the entity << ${options.ename} >>!`
        // )
        context.logger.warn(`⚠️ Field {${memberName}} is already declared in the entity  {${options.ename}} !\n ⏭️ Skipping the field creation \n`);
        return new change_1.NoopChange();
    }
    const idMemberDeclaration = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.Decorator);
    const idDecorator = idMemberDeclaration?.find((decorator) => decorator.getText() === `@${annotation}()`);
    if (!!idDecorator) {
        let positionToInsertMember = idDecorator.parent.getStart();
        let mType = getMemberType(options.memberType.toLowerCase());
        let newData = `\n    @${annotation}()\n    ${memberName.concat(`!: ${mType}`)};\n`;
        return new change_1.ReplaceChange(entityPath, positionToInsertMember, idDecorator.parent.getText(), newData);
    }
    else {
        // add the new member declaration to the entity
        let positionToInsertMember = classDeclarationNode.getChildAt(classDeclarationNode.getChildCount() - 3).getEnd();
        if (propertiesDeclarationNodes__ && propertiesDeclarationNodes__.length > 0) {
            positionToInsertMember = propertiesDeclarationNodes__.reduce((previous, current) => {
                return previous + current.getFullWidth();
            }, positionToInsertMember);
        }
        let mType = getMemberType(options.memberType.toLowerCase());
        let data = `\n    @${annotation}()\n    ${memberName.concat(`!: ${mType}`)};\n`;
        return new change_1.InsertChange(entityPath, positionToInsertMember, data);
    }
}
function addDefaultMemberViewLayoutToEntityVL(options) {
    return async (host, context) => {
        let entityVLFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/viewlayout/${options.ename.toLocaleLowerCase()}VL.json`));
        if (!host.exists(entityVLFile)) {
            throw new Error(`❌ The requested entity view layout config related to the entity <<${options.ename}>>does not exist!\n Is the entity provided an averos entity?`);
        }
        let vlContent = host.read(entityVLFile);
        if (!vlContent) {
            return;
        }
        let entityViewLayout = JSON.parse(vlContent.toString());
        updateDefaultEntityViewLayout(entityViewLayout, options);
        host.overwrite(entityVLFile, JSON.stringify(entityViewLayout));
        context.logger.info(`✅ Member {${options.mname}} view layout have been successfully added to {${options.ename}} Entity View Layout!`);
    };
}
function updateDefaultEntityViewLayout(viewLayoutContent, options) {
    let entityFieldName = options.mname;
    let labelTranslationID = options.ename.toLowerCase().concat('.').concat(entityFieldName.toLowerCase());
    let label = labelize(entityFieldName);
    let memberIcon = 'label';
    switch (options.memberType.toLowerCase()) {
        case 'date':
            memberIcon = 'today';
            break;
        case 'boolean':
            memberIcon = 'flaky';
            break;
        case 'textarea':
            memberIcon = 'description';
            break;
        case 'password':
            memberIcon = 'lock';
            break;
        case 'phone':
            memberIcon = 'local_phone';
            break;
        case 'number':
            memberIcon = 'pin';
            break;
        case 'numberslider':
            memberIcon = 'pin';
            break;
        default:
            memberIcon = 'label';
            break;
    }
    let tableUCViewLayoutEntry = `{
    "entityFieldName": "${entityFieldName}",
    "label": "${label}",
    "labelTranslationID": "${labelTranslationID}",
    "visible": true,
    "type": "${options.memberType.toLowerCase() === 'numberslider' ? 'number' : options.memberType.toLowerCase()}",
    ${options.memberType.toLowerCase() === 'date' ? '"format": "dd/MM/yyyy",' : ''}
    "order": ${viewLayoutContent.tableUCViewLayout.ucViewLayout.length + 1}
  }`;
    let viewUCViewLayoutEntry = `{
  "entityFieldName": "${entityFieldName}",
  "label": "${label}",
  "labelTranslationID": "${labelTranslationID}",
  "visible": true,
  "type": "${options.memberType.toLowerCase() === 'numberslider' ? 'number' : options.memberType.toLowerCase()}",
  ${options.memberType.toLowerCase() === 'date' ? '"format": "dd/MM/yyyy",' : ''}
  "icon": "${memberIcon}",
  "order": ${viewLayoutContent.viewUCViewLayout.ucViewLayout.length + 1},
  "fieldGroup": {
    "groupId": 1,
    "groupOrder": 1
  }
}`;
    let createUCViewLayoutEntry = `{
  "entityFieldName": "${entityFieldName}",
  "label": "${label}",
  "labelTranslationID": "${labelTranslationID}",
  "visible": true,
  "type": "${options.memberType.toLowerCase() === 'numberslider' ? 'number' : options.memberType.toLowerCase()}",
  ${options.memberType.toLowerCase() === 'date' ? '"format": "dd/MM/yyyy",' : ''}
  "icon": "${memberIcon}",
  "required": false,
	"disabled": false,
  "defaultValue": "",
  "order": ${viewLayoutContent.createUCViewLayout.ucViewLayout.length + 1},
  "fieldGroup": {
    "groupId": 1,
    "groupOrder": 1
  }
}`;
    let editUCViewLayoutEntry = `{
  "entityFieldName": "${entityFieldName}",
  "label": "${label}",
  "labelTranslationID": "${labelTranslationID}",
  "visible": true,
  "type": "${options.memberType.toLowerCase() === 'numberslider' ? 'number' : options.memberType.toLowerCase()}",
  ${options.memberType.toLowerCase() === 'date' ? '"format": "dd/MM/yyyy",' : ''}
  "icon": "${memberIcon}",
  "required": false,
	"disabled": false,
  "defaultValue": "",
  "order": ${viewLayoutContent.createUCViewLayout.ucViewLayout.length + 1},
  "fieldGroup": {
    "groupId": 1,
    "groupOrder": 1
  }
}`;
    if (!viewLayoutContent.createUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.createUCViewLayout.ucViewLayout.push(JSON.parse(createUCViewLayoutEntry));
    }
    if (!viewLayoutContent.editUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.editUCViewLayout.ucViewLayout.push(JSON.parse(editUCViewLayoutEntry));
    }
    if (!viewLayoutContent.viewUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.viewUCViewLayout.ucViewLayout.push(JSON.parse(viewUCViewLayoutEntry));
    }
    if (!viewLayoutContent.tableUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.tableUCViewLayout.ucViewLayout.push(JSON.parse(tableUCViewLayoutEntry));
    }
    return viewLayoutContent;
}
function labelize(str) {
    if (str) {
        return core_1.strings.dasherize(str).split('-').reduce((previous, current) => {
            return (previous !== '' ? previous.concat(' ').concat(core_1.strings.capitalize(current)) : previous.concat(core_1.strings.capitalize(current)));
        }, '');
    }
    return '';
}
function getMemberType(memberType) {
    switch (memberType) {
        case 'date':
            return 'Date';
        case 'number':
            return 'number';
        case 'textarea':
            return 'string';
        case 'password':
            return 'string';
        case 'phone':
            return 'string';
        default:
            return 'string';
    }
}
function createDefaultTranslationKeys(options) {
    return async (host, context) => {
        let translationFilesLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/i18n/`));
        let dirEntry = host.getDir(translationFilesLocation);
        let translationFilesDirEntry = dirEntry.subfiles;
        translationFilesDirEntry.forEach(tFile => {
            let translationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), tFile));
            if (!host.exists(translationFile)) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.\n`);
            }
            let translationContent = host.read(translationFile);
            if (!translationContent) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.`);
            }
            let translationData = JSON.parse(translationContent.toString());
            translationData[`${options.ename.toLocaleLowerCase()}.${options.mname.toLocaleLowerCase()}`] = labelize(options.mname);
            if (!translationData[`${options.ename.toLocaleLowerCase()}.${options.mname.toLocaleLowerCase()}`]) {
            }
            host.overwrite(translationFile, JSON.stringify(translationData));
        });
        context.logger.info(`✅ A default translation entry value have been created for this simple field key!\nPlease note this translation entry is by default created for all existing configured languages (including the default one).\nIn order to update the translation entry value for this key use the command:\n{ ng g @wiforge/averos:add-translation-entry --lang=[LANGUAGE] --key=[KEY] --value=[valueInTargetLang] }`);
    };
}
//# sourceMappingURL=index.js.map