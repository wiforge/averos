"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.registerEnumeration = registerEnumeration;
exports.registerEnumMember = registerEnumMember;
exports.addDefaultMemberViewLayoutToEntityVL = addDefaultMemberViewLayoutToEntityVL;
exports.createDefaultTranslationKeys = createDefaultTranslationKeys;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
const workspace_1 = require("@schematics/angular/utility/workspace");
const change_1 = require("@schematics/angular/utility/change");
const util_1 = require("../util");
const ts = require("typescript");
function default_1(options) {
    return async (host, context) => {
        /// Option Setup //////////////
        if (!options.ename || options.ename.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ Entity Name is mandatory! Please provide one`);
        }
        if (!options.mname || options.mname.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The field type is mandatory! Please provide one`);
        }
        // transform the class name into a valid class identifier
        options.ename = (0, util_1.toValidIdentifier)(options.ename, 'class');
        // transform the member name into a valid member name
        options.mname = (0, util_1.toValidIdentifier)(options.mname);
        if (!options.listOfEnumValues || options.listOfEnumValues.trim() === '') {
            throw new schematics_1.SchematicsException(`❌ The field enumeration values are mandatory! Please provide them`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        ///// END Option Setup////////////////////////
        const templatesPath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'model') + '/');
        const entityRelativePath = `${templatesPath}/${core_1.strings.dasherize(options.ename)}.ts`;
        if (!host.exists(entityRelativePath)) {
            throw new schematics_1.SchematicsException(`❌ Entity ${options.ename} does not exist in the following location: ${entityRelativePath} `);
        }
        context.logger.info(`🌱 Entity field seeds named ${options.mname} of ype Enumeration is being sown...`);
        context.logger.info(`🌱 Entity View layout default configuration seeds are being sown...`);
        return (0, schematics_1.chain)([
            registerEnumeration(options),
            registerEnumMember(options),
            addDefaultMemberViewLayoutToEntityVL(options),
            createDefaultTranslationKeys(options)
        ]);
    };
}
function registerEnumeration(options) {
    return async (host, context) => {
        let enumFieldName = `${options.ename}${options.mname}`;
        let enumTypeFilePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), `model/${core_1.strings.dasherize(enumFieldName)}.ts`));
        if (!host.exists(enumTypeFilePath)) {
            context.logger.info(`☑️ Enum with name ${enumFieldName} will be created...`);
        }
        else {
            context.logger.info(`☑️ Enum with name ${enumFieldName} already exists! Proceding with the existing enum...`);
            return;
        }
        let enumerations = options.listOfEnumValues.split(',');
        let addedEnumFields = [];
        let enumerationvalues = enumerations.reduce((p, c) => {
            let enumFieldName = c.toUpperCase();
            if (addedEnumFields.indexOf(enumFieldName) < 0) {
                addedEnumFields.push(enumFieldName);
                let enumFieldValue = core_1.strings.capitalize(c);
                let enumFieldEntry = `${enumFieldName} = '${enumFieldValue}'`;
                if (p === '') {
                    p = p.concat(`${enumFieldEntry}`);
                }
                else {
                    p = p.concat(`, \n    ${enumFieldEntry}`);
                }
            }
            return p;
        }, '');
        host.create(enumTypeFilePath, `\n
export enum ${enumFieldName} {
            
    ${enumerationvalues}

}`);
        const recorder = host.beginUpdate(enumTypeFilePath);
        host.commitUpdate(recorder);
    };
}
function registerEnumMember(options) {
    return async (host, context) => {
        context.logger.info(`☑️ Entity with name ${options.ename} will be Updated...`);
        let enumFieldName = `${options.ename}${options.mname}`;
        let entityFilePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), `model/${core_1.strings.dasherize(options.ename)}.ts`));
        if (!host.exists(entityFilePath)) {
            throw new schematics_1.SchematicsException(`❌ Unable to find the averos entity << ${enumFieldName} >> in the following location: ${entityFilePath}`);
        }
        let source = (0, util_1.readIntoSourceFile)(host, entityFilePath);
        const importMemberEntityType = (0, util_1.insertImport)(source, entityFilePath, enumFieldName, `./${core_1.strings.dasherize(enumFieldName)}`);
        const updateEntityWithNewMember = addMemberToEntity(source, entityFilePath, options, context);
        const changes = [importMemberEntityType, updateEntityWithNewMember];
        const recorder = host.beginUpdate(entityFilePath);
        for (const change of changes) {
            if (change instanceof change_1.InsertChange) {
                recorder.insertLeft(change.pos, change.toAdd);
            }
        }
        host.commitUpdate(recorder);
    };
}
function addMemberToEntity(source, entityPath, options, context) {
    if (!source || !entityPath) {
        return new change_1.NoopChange();
    }
    let memberName = options.mname;
    const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
    if (!classDeclarationNode) { // no entity class declaration found
        throw new Error(`❌ No Class Declaration Found!`);
    }
    const propertiesDeclarationNodes__ = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.PropertyDeclaration);
    const memberDeclaration = propertiesDeclarationNodes__?.find((n) => n.name?.text === memberName);
    if (memberDeclaration) { // Member already declared
        // throw new Error(
        //   `❌ Member << ${memberName} >> is already declared in the entity << ${options.ename} >>!`
        // )
        context.logger.warn(`⚠️ Field {${memberName}} is already declared in the entity  {${options.ename}} !\n ⏭️ Skipping the field creation \n`);
        return new change_1.NoopChange();
    }
    // add the new member declaration to the entity
    let positionToInsertMember = classDeclarationNode.getChildAt(classDeclarationNode.getChildCount() - 3).getEnd();
    if (propertiesDeclarationNodes__ && propertiesDeclarationNodes__.length > 0) {
        positionToInsertMember = propertiesDeclarationNodes__.reduce((previous, current) => {
            return previous + current.getFullWidth();
        }, positionToInsertMember);
    }
    let enumFieldName = `${options.ename}${options.mname}`;
    let data = `\n    ${memberName.concat(`!: ${enumFieldName}`)};\n`;
    return new change_1.InsertChange(entityPath, positionToInsertMember, data);
}
function addDefaultMemberViewLayoutToEntityVL(options) {
    return async (host, context) => {
        let entityVLFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/viewlayout/${options.ename.toLocaleLowerCase()}VL.json`));
        if (!host.exists(entityVLFile)) {
            throw new Error(`❌ The requested entity view layout config related to the entity <<${options.ename}>>does not exist!\n Is the entity provided an averos entity?`);
        }
        let vlContent = host.read(entityVLFile);
        if (!vlContent) {
            return;
        }
        let entityViewLayout = JSON.parse(vlContent.toString());
        updateDefaultEntityViewLayout(entityViewLayout, options);
        host.overwrite(entityVLFile, JSON.stringify(entityViewLayout));
        context.logger.info(`✅ Member {${options.mname}} view layout have been successfully added to {${options.ename}} Entity View Layout!`);
    };
}
function updateDefaultEntityViewLayout(viewLayoutContent, options) {
    let entityFieldName = options.mname;
    let labelTranslationID = options.ename.toLowerCase().concat('.').concat(entityFieldName.toLowerCase());
    let label = labelize(entityFieldName);
    let memberDomain = options.listOfEnumValues.split(',').reduce((p, c) => {
        p.push({
            key: `${core_1.strings.capitalize(c)}`,
            value: `${core_1.strings.capitalize(c)}`,
            translationID: `${labelTranslationID}.${c.toUpperCase()}`
        });
        return p;
    }, []);
    let tableUCViewLayoutEntry = `{
      "entityFieldName": "${entityFieldName}",
      "label": "${label}",
      "labelTranslationID": "${labelTranslationID}",
      "visible": true,
      "order": ${viewLayoutContent.tableUCViewLayout.ucViewLayout.length + 1}
    }`;
    let viewUCViewLayoutEntry = `{
    "entityFieldName": "${entityFieldName}",
    "label": "${label}",
    "labelTranslationID": "${labelTranslationID}",
    "visible": true,
    "order": ${viewLayoutContent.viewUCViewLayout.ucViewLayout.length + 1},
    "fieldGroup": {
      "groupId": 1,
      "groupOrder": 1
    }
  }`;
    let createUCViewLayoutEntry = `{
    "entityFieldName": "${entityFieldName}",
    "label": "${label}",
    "labelTranslationID": "${labelTranslationID}",
    "visible": true,
    "type": "combo",
    "icon": "view_list",
    "required": false,
    "targetFieldDomain": { "defaultDomain": ${JSON.stringify(memberDomain)}},
    "order": ${viewLayoutContent.createUCViewLayout.ucViewLayout.length + 1},
    "fieldGroup": {
      "groupId": 1,
      "groupOrder": 1
    }
  }`;
    let editUCViewLayoutEntry = `{
    "entityFieldName": "${entityFieldName}",
    "label": "${label}",
    "labelTranslationID": "${labelTranslationID}",
    "visible": true,
    "type": "combo",
    "icon": "view_list",
    "required": false,
    "targetFieldDomain": { "defaultDomain": ${JSON.stringify(memberDomain)}},
    "order": ${viewLayoutContent.editUCViewLayout.ucViewLayout.length + 1},
    "fieldGroup": {
      "groupId": 1,
      "groupOrder": 1
    }
  }`;
    if (!viewLayoutContent.createUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.createUCViewLayout.ucViewLayout.push(JSON.parse(createUCViewLayoutEntry));
    }
    if (!viewLayoutContent.editUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.editUCViewLayout.ucViewLayout.push(JSON.parse(editUCViewLayoutEntry));
    }
    if (!viewLayoutContent.viewUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.viewUCViewLayout.ucViewLayout.push(JSON.parse(viewUCViewLayoutEntry));
    }
    if (!viewLayoutContent.tableUCViewLayout.ucViewLayout.find(e => e.entityFieldName === entityFieldName)) {
        viewLayoutContent.tableUCViewLayout.ucViewLayout.push(JSON.parse(tableUCViewLayoutEntry));
    }
    return viewLayoutContent;
}
function labelize(str) {
    if (str) {
        return core_1.strings.dasherize(str).split('-').reduce((previous, current) => {
            return (previous !== '' ? previous.concat(' ').concat(core_1.strings.capitalize(current)) : previous.concat(core_1.strings.capitalize(current)));
        }, '');
    }
    return '';
}
function createDefaultTranslationKeys(options) {
    return async (host, context) => {
        let translationFilesLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/i18n/`));
        let dirEntry = host.getDir(translationFilesLocation);
        let translationFilesDirEntry = dirEntry.subfiles;
        translationFilesDirEntry.forEach(tFile => {
            let translationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), tFile));
            if (!host.exists(translationFile)) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.`);
            }
            let translationContent = host.read(translationFile);
            if (!translationContent) {
                throw new Error(`❌ No Translation properties found for this project! Please use ng g @wiforge/averos:add-language in order to activate averos translation support for your angular project.`);
            }
            let translationData = JSON.parse(translationContent.toString());
            translationData[`${options.ename.toLocaleLowerCase()}.${options.mname.toLocaleLowerCase()}`] = labelize(options.mname);
            if (!translationData[`${options.ename.toLocaleLowerCase()}.${options.mname.toLocaleLowerCase()}`]) {
            }
            options.listOfEnumValues.split(',').reduce((p, c) => {
                translationData[`${options.ename.toLocaleLowerCase()}.${options.mname.toLocaleLowerCase()}.${c.toUpperCase()}`] = labelize(c);
            }, null);
            host.overwrite(translationFile, JSON.stringify(translationData));
        });
        context.logger.info(`✅ A default translation entry value have been created for this simple enumeration field key!\nPlease note this translation entry is by default created for all existing configured languages (including the default one).\nIn order to update the translation entry value for this key use the command:\n{ ng g @wiforge/averos:add-translation-entry --lang=[LANGUAGE] --key=[KEY] --value=[valueInTargetLang] }`);
    };
}
//# sourceMappingURL=add-enumeration.js.map