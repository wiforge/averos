"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.REQUIRED_PACKAGES = void 0;
exports.getPackageCompliantVersion = getPackageCompliantVersion;
exports.getPackageVersion = getPackageVersion;
exports.addDependencyToPackageJson = addDependencyToPackageJson;
/**
 * file: util/package-util.ts
 */
const dependencies_1 = require("@schematics/angular/utility/dependencies");
const rxjs_1 = require("rxjs");
const schematics_1 = require("@angular-devkit/schematics");
const deplib_versions_json_1 = require("../deplib-versions.json");
/**
 * List of required Averos dependencies
 */
exports.REQUIRED_PACKAGES = [
    { packageName: '@wiforge/averos', type: dependencies_1.NodeDependencyType.Default },
    { packageName: '@angular/material', type: dependencies_1.NodeDependencyType.Default },
    { packageName: '@angular/animations', type: dependencies_1.NodeDependencyType.Default },
    { packageName: '@angular/cdk', type: dependencies_1.NodeDependencyType.Default },
    { packageName: '@angular/localize', type: dependencies_1.NodeDependencyType.Default },
    { packageName: 'file-saver', type: dependencies_1.NodeDependencyType.Default }
];
/**
 * Gets the compliant version for a package
 */
function getPackageCompliantVersion(packageMetaData) {
    return (0, rxjs_1.of)({
        packageVersion: getPackageVersion(packageMetaData.packageName),
        packageMetaData: packageMetaData
    });
}
/**
 * Retrieves package version from dependency library versions
 */
function getPackageVersion(packageName) {
    let version = deplib_versions_json_1.dependencies[packageName];
    if (!version) {
        // try from extLib
        version = deplib_versions_json_1.externalDependencies[packageName];
        if (!version) {
            throw new schematics_1.SchematicsException(`❌ Version not found for package: ${packageName}`);
        }
    }
    return version;
}
/**
 * Adds a single dependency to package.json
 */
function addDependencyToPackageJson(host, context, packageInfo) {
    const nodeDependency = {
        type: packageInfo.packageMetaData.type,
        name: packageInfo.packageMetaData.packageName,
        version: packageInfo.packageVersion,
        overwrite: false
    };
    const existingDep = (0, dependencies_1.getPackageJsonDependency)(host, nodeDependency.name);
    if (!existingDep) {
        (0, dependencies_1.addPackageJsonDependency)(host, nodeDependency);
        context.logger.info(`✅ Added ${nodeDependency.name}@${nodeDependency.version}`);
    }
    else {
        context.logger.info(`ℹ️ ${nodeDependency.name} already installed (${existingDep.version})`);
    }
}
//# sourceMappingURL=package-util.js.map