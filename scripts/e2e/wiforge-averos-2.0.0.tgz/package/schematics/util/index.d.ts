/**
 * @license
 * Copyright wiforge All Rights Reserved.
 *
 * Use of this source code, and only this prtion of source code, is governed by the MIT License
 *
 */
/**
 * file: util/index.ts
 */
import { Tree, SchematicContext } from '@angular-devkit/schematics';
import { Change, ReplaceChange } from '@schematics/angular/utility/change';
import { NgAddOption } from '../ng-add/schema';
import * as ts from 'typescript';
import { AverosAuthOption } from '../averos-auth/schema';
import { AverosAuthConfigOption } from '../averos-auth-config/schema';
export declare function getRouteInsertionPoint(routesListNode: ts.Node, routeStrings: string[]): {
    insertPos: number;
    toAdd: string;
};
export declare function extractRoutesListNode(source: ts.SourceFile, routerModulePath: string): ts.Node;
export declare function readIntoSourceFile(host: Tree, modulePath: string): ts.SourceFile;
/**
 * Add Import `import { symbolName } from fileName` if the import doesn't exit
 * already. Assumes fileToEdit can be resolved and accessed.
 * @param fileToEdit (file we want to add import to)
 * @param symbolName (item to import)
 * @param fileName (path to the file)
 * @param isDefault (if true, import follows style for importing default exports)
 * @return Change
 */
export declare function insertImport(source: ts.SourceFile, fileToEdit: string, symbolName: string, fileName: string, isDefault?: boolean): Change;
export declare function insertImportAsTextChange(source: ts.SourceFile, importName: string, importPath: string): ts.TextChange[];
export declare function findExistingImport(sourceFile: ts.SourceFile, className: string, importPath: string): boolean;
/**
* Computes the relative import path from a source file to a target TypeScript file.
* This function is used to determine the appropriate import path for a symbol (e.g., a class)
* from one file to another in a TypeScript/Angular project.
*
* @param tree - The Angular virtual file system tree, used to navigate project files.
* @param sourceFilePath - The file path of the source file (where the import will be added).
* @param classToAddFilePath - The file path of the target file (where the class is defined).
* @returns The relative import path as a string, formatted for TypeScript imports.
*          - Ensures path separators are normalized for cross-platform compatibility.
*          - Removes `.ts` extensions as they are not required in TypeScript imports.
*          - Prepends './' to relative paths that do not start with it.
*
* @example
* // Example usage:
* const importPath = getImportPath(tree, '/src/app/services/class-a.service.ts', '/src/app/models/class-b.ts');
* console.log(importPath); // Output: '../models/class-b'
*
* @throws An error if the file paths are invalid or if the relative path cannot be computed.
*/
export declare function getImportPath(tree: Tree, sourceFilePath: string, classToAddFilePath: string): string;
/**
 * Insert `toInsert` after the last occurence of `ts.SyntaxKind[nodes[i].kind]`
 * or after the last of occurence of `syntaxKind` if the last occurence is a sub child
 * of ts.SyntaxKind[nodes[i].kind] and save the changes in file.
 *
 * @param nodes insert after the last occurence of nodes
 * @param toInsert string to insert
 * @param file file to insert changes into
 * @param fallbackPos position to insert if toInsert happens to be the first occurence
 * @param syntaxKind the ts.SyntaxKind of the subchildren to insert after
 * @return Change instance
 * @throw Error if toInsert is first occurence but fall back is not set
 */
export declare function insertAfterLastOccurrence(nodes: ts.Node[], toInsert: string, file: string, fallbackPos: number, syntaxKind?: ts.SyntaxKind): Change;
export declare const isLanguageSupported: (languageCode: string) => boolean;
export declare function getDecoratorMetadata(source: ts.SourceFile, identifier: string, module: string): ts.Node[];
/**
 * Get all the nodes from a source.
 * @param sourceFile The source file object.
 * @returns {Array<ts.Node>} An array of all the nodes in the source.
 */
export declare function getSourceNodes(sourceFile: ts.SourceFile): ts.Node[];
export declare function getMetadataField(node: ts.ObjectLiteralExpression, metadataField: string): ts.ObjectLiteralElement[];
export declare function addApplicationInitializerProviderToModule(source: ts.SourceFile, modulePath: string, moduleName: string, moduleLocation: string): Change[];
export declare function addClassToApplicationMainModuleProviders(source: ts.SourceFile, modulePath: string, customClassName: string, customClassImportLocation: string): Change[];
export declare function addAverosCoreModuleToApplicationModuleImport(source: ts.SourceFile, modulePath: string, moduleName: string, moduleLocation: string, options: NgAddOption): Change[];
/**
 * Check if authProvidersConfig uses single provider structure
 */
export declare function isSingleProviderStructure(authProvidersNode: ts.ObjectLiteralExpression): boolean;
/**
 * Get the current provider name from single provider structure
 */
export declare function getSingleProviderName(authProvidersNode: ts.ObjectLiteralExpression): string;
export declare function addOrUpdateAverosAuthProvider(source: ts.SourceFile, // ts source file 
modulePath: string, // sourcePath ex. PROJECT_HOME/src
moduleName: string, // Class Name ex. AverosDummyAuthProvider
moduleLocation: string, // ex. @wiforge/averos
options: AverosAuthOption): Change[];
/**
 * Sets up either auth provider configuration parameters
 * Or the global HTTP Auth Configuration parameters
 */
export declare function configureAverosAuthProvider(source: ts.SourceFile, modulePath: string, options: AverosAuthConfigOption, context: SchematicContext): Change[];
export declare function labelize(str: string): string;
export declare function getAnyDecoratorMetadata(source: ts.SourceFile, identifier: string, module: string): ts.Node[];
export declare function getServiceName(source: ts.SourceFile): string;
export declare function findClassImplementationFilePath(tree: Tree, className: string): string | null;
export declare function findEntityViewLayoutFilePath(tree: Tree, entityClassName: string): string | null;
export declare function findAnnotatedClassImplementationFilePath(tree: Tree, className: string, annotation: string): string | null;
export declare function isNull(object: any): boolean;
/**
 * Creates a method in the specified class.
 *
 * @param source - The TypeScript source file.
 * @param classFilePath - Path to the file containing the class.
 * @param methodName - Name of the method to create.
 * @param methodReturns - The return type of the method.
 * @returns A Change object representing the addition of the method.
 */
export declare function createMethodInClass(source: ts.SourceFile, classFilePath: string, methodName: string, methodReturns: string): Change;
export declare function addServiceClassToAverosEntityDecorator(sourceFile: ts.SourceFile, filePath: string, className: string, classToAdd: string): ReplaceChange | undefined;
/**
 * Removes the '.ts' extension from a full path name, if it exists.
 *
 * @param path - The full path name, e.g., 'dir1/dir2/file.ts'.
 * @returns The path without the '.ts' extension.
 */
export declare function removeTsExtension(path: string): string;
/**
 * Converts a string into a valid TypeScript identifier for class or method.
 *
 * - If kind is 'class' and the value is a TypeScript primitive, it is returned unchanged.
 * - Replaces forbidden characters with underscores (_).
 * - Reserved TypeScript/JS keywords are prefixed with an underscore.
 * - Prevents identifiers from starting with a digit.
 * - Applies naming convention based on kind: 'method' (aka member) (camelCase) or 'class' (PascalCase).
 *
 * @param str - The input string to convert.
 * @param kind - The type of identifier: 'method' or 'class'. Default is 'method'.
 * @returns A valid TypeScript identifier name.
 */
export declare function toValidIdentifier(str: string, kind?: "method" | "class"): string | undefined;
/**
 * Classifies a string like strings.classify() but preserves
 * underscore-digit suffixes (e.g. _0, _1, _123).
 *
 * Examples:
 *   myEntity_0   → MyEntity_0
 *   myentity_0   → Myentity_0
 *   MyEntity_0   → MyEntity_0
 *   my_entity_0  → MyEntity_0
 *   myEntity     → MyEntity      (standard classify, no suffix)
 */
export declare function classifyPreserveTrailingIndex(value: string): string;
export interface ApplicationNavigationItem {
    loggedSpace?: boolean;
    disabled?: boolean;
    displayName?: string;
    translationID?: string;
    iconName?: string;
    route?: string;
    type?: 'link' | 'sub' | 'extLink' | 'extTabLink';
    label?: NavigationItemTag;
    badge?: NavigationItemTag;
    children?: ApplicationNavigationItem[];
}
export interface NavigationItemTag {
    color: string;
    value: string;
    translationID: string;
}
export interface ApplicationMenu {
    sideMenu: ApplicationNavigationItem[];
    topMenu: ApplicationNavigationItem[];
}
export declare const AVEROS_DEFAULT_AVATARS: any;
export interface EntityViewLayout {
    defaultUCViewLayout: UseCaseViewLayout;
    searchInputUCViewLayout: UseCaseViewLayout;
    tableUCViewLayout: UseCaseViewLayout;
    selectableInputTableUCViewLayout: UseCaseViewLayout;
    viewUCViewLayout: UseCaseViewLayout;
    createUCViewLayout: UseCaseViewLayout;
    editUCViewLayout: UseCaseViewLayout;
}
export interface UseCaseViewLayout {
    title: string;
    titleTranslationID: string;
    parentEntityLabel: string;
    parentEntityLabelTranslationId: string;
    orderedView: boolean;
    ucViewLayout: FieldViewLayout[];
    iconOrientation: string;
    entityType: any;
}
export interface FieldViewLayout {
    entityFieldName: string;
    label: string;
    labelTranslationID?: string;
    placeholder?: string;
    placeholderTranslationID?: string;
    visible: boolean;
    disabled: boolean;
    order?: number;
    format?: string;
    type?: string;
    typeName?: string;
    icon?: string;
    required?: boolean;
    targetFieldDomain?: any;
    validators?: FieldValidator;
    defaultValue?: any;
    fieldGroup: GroupedFieldViewLayout;
}
export interface FieldValidator {
    syncValidators?: ValidatorMetaData[];
    asyncValidators?: ValidatorMetaData[];
    updateOn?: string;
}
export interface ValidatorMetaData {
    validatorID: string;
    validatorKey: string;
    parameters?: any;
    type: string;
    nature: string;
    validationDefaultMessage?: string;
    validationMessageTranslationId?: string;
}
export interface GroupedFieldViewLayout {
    groupId: number;
    groupLabel?: string;
    groupLabelTranslationID?: string;
    groupOrder?: number;
    layout?: string;
}
export declare class EnvironmentConfiguration {
    configurationItems: EnvironmentConfigurationItem[];
}
export interface EnvironmentConfigurationItem {
    id: string;
    type: string;
}
export declare class ServiceConfigurationItem implements EnvironmentConfigurationItem {
    id: string;
    type: string;
    apiHost: string;
    apiPort: number;
    apiProtocol: string;
    apiEndPoint: string;
    apiProxy?: boolean;
    apiHTTPQueryBuilder: string;
    externalEntityId: string;
}
export declare class GatewayConfigurationItem implements EnvironmentConfigurationItem {
    id: string;
    type: string;
    gatewayHost: string;
    gatewayPort: number;
    gatewayProtocol: string;
    apiEndpoints: ApiEndpoint[];
}
export declare class ApiEndpoint {
    id: string;
    endpoint: string;
    queryBuilder: string;
    externalEntityId: string;
}
export declare class EntityConfiguration {
    configurationItems: EntityConfigurationItem[];
    globalAPICollectionResponseMappingLookup: GlobalAPICollectionResponseMappingLookup;
}
export declare class EntityConfigurationItem {
    configurationId: string;
    entityId: string;
    lifecycleId: string;
    externalKeysMapping: EntityKeysMapping[];
    constructor(configurationId?: string, entityId?: string, lifecycleId?: string, externalKeysMapping?: EntityKeysMapping[]);
    clone(): EntityConfigurationItem;
    static fromJSON(json: any): EntityConfigurationItem;
}
export declare class EntityKeysMapping {
    targetServices: string[];
    keysMapping: Record<string, string | number>;
    constructor(targetServices?: string[], keysMapping?: Record<string, string | number>);
    clone(): EntityKeysMapping;
    equals(other: EntityKeysMapping): boolean;
}
export declare class GlobalAPICollectionResponseMappingLookup {
    data: string;
    totalCount: string;
    currentPageIndex: string;
    pageSize: string;
    totalPages: string;
}
type ValidationAction = {
    actionId: string;
    validationKey: string;
    actionNature: string;
    hasParameters?: boolean; /** parameters value should be comma seperated. ex. value1, value2 => ex1. 50 ex2. 30, 40, "userid" */
};
export declare class PredefinedEntityValidators {
    private static standardValidators;
    private constructor();
    static isStandardValidator(validatorName: string): boolean;
    static getPredefinedValidationAction(validatorName: string, validationAction: string): ValidationAction;
}
export declare const AVEROS_VALIDATOR_WORKFLOW = "averos-validator";
export declare const PREDEFINED_VALIDATOR_WORKFLOW = "predefined-validator";
export declare const CUSTOM_VALIDATOR_WORKFLOW = "custom-validator";
export declare const PREDEFINED_ACTION_GLOBAL_CUSTOM_VALIDATOR_WORKFLOW = "predefined-action-global-custom-validator";
export declare const PREDEFINED_ACTION_VALIDATORS_WORKFLOW = "predefined-action-validators";
export declare const PREDEFINED_ACTION_PARAMETERS_WORKFLOW = "predefined-action-parameters";
export {};
