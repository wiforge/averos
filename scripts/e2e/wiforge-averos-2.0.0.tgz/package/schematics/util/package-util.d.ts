/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * file: util/package-util.ts
 */
import { NodeDependencyType } from "@schematics/angular/utility/dependencies";
import { Observable } from "rxjs";
import { SchematicContext, Tree } from '@angular-devkit/schematics';
/**
 * Package metadata for dependencies to be installed
 */
export interface PackageMetadata {
    packageName: string;
    type: NodeDependencyType;
}
export interface PackageInfo {
    packageVersion: string;
    packageMetaData: PackageMetadata;
}
/**
 * List of required Averos dependencies
 */
export declare const REQUIRED_PACKAGES: PackageMetadata[];
/**
 * Gets the compliant version for a package
 */
export declare function getPackageCompliantVersion(packageMetaData: PackageMetadata): Observable<PackageInfo>;
/**
 * Retrieves package version from dependency library versions
 */
export declare function getPackageVersion(packageName: string): string;
/**
 * Adds a single dependency to package.json
 */
export declare function addDependencyToPackageJson(host: Tree, context: SchematicContext, packageInfo: PackageInfo): void;
