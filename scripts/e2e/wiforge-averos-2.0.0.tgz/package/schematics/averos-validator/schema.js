"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AverosValidatorOption = void 0;
class AverosValidatorOption {
    // the action to follow: either choose a predefined validator or create/use an existing one
    type;
    // The Validator name
    name;
    // The target entity name
    entityName;
    // The entity field to be validated
    fieldName;
    // The nature of the validator: sync | async.
    nature;
    // The validator ID a.k.a the method name.
    validatorId;
    // The validation key
    validatorKey;
    // The validation parameters used with the validation method (comma-separated values).
    validationParameters;
    // The Validator Class Name
    classType;
    // The default validation message
    validationDefaultMessage;
    // The translation id of the validation message
    validationMessageTranslationId;
    previousSchematics;
    // The path to create the service.
    path;
    // The name of the project.
    project;
}
exports.AverosValidatorOption = AverosValidatorOption;
//# sourceMappingURL=schema.js.map