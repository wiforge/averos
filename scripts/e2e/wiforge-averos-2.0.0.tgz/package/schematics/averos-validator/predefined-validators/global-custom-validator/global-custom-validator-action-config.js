"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const util_1 = require("../../../util");
function default_1(options) {
    return async (host, context) => {
        let predefinedValidator = options.name;
        let predefinedValidationAction = options.validatorId;
        let validationAction = util_1.PredefinedEntityValidators.getPredefinedValidationAction(predefinedValidator, predefinedValidationAction);
        if ((0, util_1.isNull)(validationAction)) {
            throw new schematics_1.SchematicsException(`❌ The validation action ${validationAction.actionId} was not found in `);
        }
        options.validatorKey = validationAction.validationKey;
        options.nature = validationAction.actionNature;
        if (validationAction.hasParameters) {
            return (0, schematics_1.schematic)(util_1.PREDEFINED_ACTION_PARAMETERS_WORKFLOW, options);
        }
        else {
            options.previousSchematics = util_1.PREDEFINED_VALIDATOR_WORKFLOW;
            return (0, schematics_1.schematic)(util_1.AVEROS_VALIDATOR_WORKFLOW, options);
        }
    };
}
//# sourceMappingURL=global-custom-validator-action-config.js.map