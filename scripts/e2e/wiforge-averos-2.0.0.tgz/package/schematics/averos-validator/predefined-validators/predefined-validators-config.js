"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const util_1 = require("../../util");
function default_1(options) {
    return async (host, context) => {
        let predefinedValidator = options.name;
        options.previousSchematics = util_1.PREDEFINED_VALIDATOR_WORKFLOW;
        switch (predefinedValidator) {
            case 'Validators':
                return (0, schematics_1.schematic)(util_1.PREDEFINED_ACTION_VALIDATORS_WORKFLOW, options);
            case 'GlobalCustomValidationService':
                return (0, schematics_1.schematic)(util_1.PREDEFINED_ACTION_GLOBAL_CUSTOM_VALIDATOR_WORKFLOW, options);
            default:
                return (0, schematics_1.noop)();
        }
    };
}
//# sourceMappingURL=predefined-validators-config.js.map