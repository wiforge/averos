"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const workspace_1 = require("@schematics/angular/utility/workspace");
const util_1 = require("../util");
const ts = require("typescript");
const change_1 = require("@schematics/angular/utility/change");
const ast_utils_1 = require("@schematics/angular/utility/ast-utils");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:averos-validator"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        // transform the class name into a valid class identifier
        options.name = (0, util_1.toValidIdentifier)(options.name, 'class');
        let validatorAlreadyExist = false;
        let predefinedValidator = util_1.PredefinedEntityValidators.isStandardValidator(options.name);
        ;
        let customValidationMethodExist = false;
        options.type = predefinedValidator ? 'predefined' : 'custom';
        /// Check if the validator already exists
        context.logger.info(`🔍 Looking for a validator with name ${options.name}...`);
        const validatorFilePath = (0, util_1.findClassImplementationFilePath)(host, options.name);
        if (options.type === 'predefined' && options.previousSchematics !== util_1.PREDEFINED_VALIDATOR_WORKFLOW) {
            return (0, schematics_1.schematic)(util_1.PREDEFINED_VALIDATOR_WORKFLOW, options);
        }
        if (options.type === 'custom' && options.previousSchematics !== util_1.CUSTOM_VALIDATOR_WORKFLOW) {
            return (0, schematics_1.schematic)(util_1.CUSTOM_VALIDATOR_WORKFLOW, options);
        }
        /// Option Setup ////////////
        if (!options.name || options.name.trim() === '') {
            throw new schematics_1.SchematicsException(`Validator Name is mandatory! Please provide one`);
        }
        // set the validator type == class name
        options.classType = options.name;
        // Check Entity and entity field
        if (!checkEntityAndEntityField(options.entityName, options.fieldName, host)) {
            return;
        }
        if (validatorFilePath) {
            context.logger.info(`☑️ Found the Validator ${options.name} in the following location ${validatorFilePath}`);
            validatorAlreadyExist = true;
            if (predefinedValidator && options.previousSchematics !== util_1.PREDEFINED_VALIDATOR_WORKFLOW) {
                return (0, schematics_1.schematic)(util_1.PREDEFINED_VALIDATOR_WORKFLOW, options);
            }
            else if (!predefinedValidator && options.previousSchematics !== util_1.CUSTOM_VALIDATOR_WORKFLOW) {
                return (0, schematics_1.schematic)(util_1.CUSTOM_VALIDATOR_WORKFLOW, options);
            }
            else if (!predefinedValidator && options.previousSchematics !== util_1.CUSTOM_VALIDATOR_WORKFLOW) {
                // Check whether options.validatorId (method name) already implemented
                customValidationMethodExist = isMethodImplemented(host, validatorFilePath, options.validatorId);
            }
        }
        else {
            context.logger.info(`☑️ Validator with name ${options.name} will be added...`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
        }
        const templatesPath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'validators') + '/');
        const templateSource = (0, schematics_1.apply)((0, schematics_1.url)('./files'), [
            (0, schematics_1.applyTemplates)({
                ...core_1.strings,
                classifyPreserveTrailingIndex: util_1.classifyPreserveTrailingIndex,
                getRelatedEntityPath,
                toLowerCase,
                ...options
            }),
            (0, schematics_1.move)((0, core_1.getSystemPath)(templatesPath))
        ]);
        return (0, schematics_1.chain)([
            /**
             * 1- if validator Name already exists => Check wether one of the predefined validators
             * 1-a- if predefined validator: then add the required entries to the view layout
             * 1-b- if not predefined entry then:
             *    - create a new validator with an empty validation method
             *    - update the entity view layout field validator with the new entry
             */
            !validatorAlreadyExist && !predefinedValidator ? (0, schematics_1.mergeWith)(templateSource) : (0, schematics_1.noop)(),
            !predefinedValidator ? registerCustomValidator(options) : (0, schematics_1.noop)(),
            !customValidationMethodExist ? updateValidationMethodInCustomValidator(options) : (0, schematics_1.noop)(),
            assignValidatorToEntityFieldViewLayout(options)
        ]);
    };
}
function getRelatedEntityPath(path) {
    return (0, core_1.join)((0, core_1.normalize)('../'), 'model');
}
function toLowerCase(str) {
    return (str ? str.toLowerCase() : '');
}
function assignValidatorToEntityFieldViewLayout(options) {
    return (host, context) => {
        let entityVLFile = (0, util_1.findEntityViewLayoutFilePath)(host, options.entityName);
        ; //normalize(join(normalize(options.path as string), `src/assets/viewlayout/${options.entityName.toLocaleLowerCase()}VL.json`));
        if (!host.exists(entityVLFile)) {
            throw new Error(`❌ The requested entity view layout config related to the entity <<${options.entityName}>>does not exist!\n Is the entity provided an averos entity?`);
        }
        let vlContent = host.read(entityVLFile);
        if (!vlContent) {
            return;
        }
        let entityViewLayout = JSON.parse(vlContent.toString());
        updateEntityViewLayout(entityViewLayout, options);
        host.overwrite(entityVLFile, JSON.stringify(entityViewLayout));
        context.logger.info(`✅ Validator successfully added to the view layout!`);
    };
}
/**
 * Updates the validator class by adding the requested validation method blieprint if it does not already exists
 *
 * @param options
 * @returns
 */
function updateValidationMethodInCustomValidator(options) {
    return (host, context) => {
        const validatorFilePath = (0, util_1.findClassImplementationFilePath)(host, options.name);
        if (!validatorFilePath) {
            throw new Error(`❌ Unable to find the custom Validator: ${options.name}`);
        }
        let source = (0, util_1.readIntoSourceFile)(host, validatorFilePath);
        const updateModuleLanguage = createValidationMethodInClass(source, validatorFilePath, options);
        const changes = [updateModuleLanguage];
        applyChanges(host, validatorFilePath, changes);
        context.logger.info(`✅ The validator has been successfully registered in the main application module!`);
    };
}
function registerCustomValidator(options) {
    return (host, context) => {
        if (options.path === null || options.path === undefined) {
            throw new Error(`❌ Cannot retrieve the project source path.`);
        }
        let modulePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'app-module.ts'));
        if (!host.exists(modulePath)) {
            throw new Error(`❌ Unable to find the main application module in the following location: ${modulePath}`);
        }
        const validatorFilePath = (0, util_1.findClassImplementationFilePath)(host, options.name);
        if (!validatorFilePath) {
            throw new Error(`❌ Unable to find the custom Validator: ${options.name}`);
        }
        // get the file path (with .ts extension)
        let validatorImportPath_ = `./${(0, core_1.relative)(options.path, validatorFilePath)}`;
        let validatorImportPath = (0, util_1.removeTsExtension)(validatorImportPath_);
        let source = (0, util_1.readIntoSourceFile)(host, modulePath);
        const updateModuleLanguage = registerCustomValidatorInMainApplicationModule(source, modulePath, options, context, validatorImportPath);
        const changes = updateModuleLanguage;
        applyChanges(host, modulePath, changes);
        context.logger.info(`✅ The validator has been successfully registered in the main application module!`);
    };
}
// Utility to apply changes to a file
function applyChanges(tree, filePath, changes) {
    const recorder = tree.beginUpdate(filePath);
    for (const change of changes) {
        // if (change instanceof ReplaceChange) {
        (0, change_1.applyToUpdateRecorder)(recorder, [change]);
        // } else {
        //   recorder.insertLeft(change.pos, change.toAdd);
        // }
    }
    tree.commitUpdate(recorder);
}
/**
 * Check wether the entity class name and the entity field exist
 * @param entityName
 * @param fieldName
 * @param host
 * @returns true | SchematicException
 */
function checkEntityAndEntityField(entityName, fieldName, host) {
    if (entityName === null || entityName === undefined) {
        throw new schematics_1.SchematicsException(`Entity Name is mandatory! Please provide one`);
    }
    if (fieldName === null || fieldName === undefined) {
        throw new schematics_1.SchematicsException(`Entity Field Name is mandatory! Please provide one`);
    }
    // Check entity
    const entityFilePath = (0, util_1.findClassImplementationFilePath)(host, entityName);
    if (!entityFilePath) { // Entity does not exist
        throw new Error(`❌ Entity << ${entityName} >> does not exist!`);
    }
    // Check Member
    let source = (0, util_1.readIntoSourceFile)(host, entityFilePath);
    const propertiesDeclarationNodes__ = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.PropertyDeclaration);
    const memberDeclaration = propertiesDeclarationNodes__?.find((n) => n.name?.text === fieldName);
    if (!memberDeclaration) { // Member is not declared in the entity
        throw new Error(`❌ Member << ${fieldName} >> does not exist in the entity << ${entityName} >>!`);
    }
    return true;
}
/**
 * Checks whether a specified method is implemented in a class within a given file in the project tree.
 *
 * This function inspects the provided class file located in the project's virtual file tree
 * to determine if the specified method is implemented. It is commonly used in code generation,
 * schematics, or project analysis workflows.
 *
 * @param host - The `Tree` object representing the virtual file system of the project.
 *               This is typically used in Angular schematics or similar contexts.
 * @param classFilePath - The file path to the class file within the project tree.
 *                        The path should be relative to the root of the tree.
 * @param methodName - The name of the method to check for implementation within the class.
 * @returns `true` if the method is implemented in the specified class, `false` otherwise.
 *
 */
function isMethodImplemented(host, classFilePath, methodName) {
    if ((0, util_1.isNull)(host) || (0, util_1.isNull)(classFilePath) || (0, util_1.isNull)(methodName)) {
        return false;
    }
    let source = (0, util_1.readIntoSourceFile)(host, classFilePath);
    if ((0, util_1.isNull)(source)) {
        return false;
    }
    const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
    if (!classDeclarationNode) { // no entity class declaration found
        throw new Error(`❌ No Class Declaration Found!`);
    }
    const methodDeclarationNodes__ = (0, ast_utils_1.findNodes)(source, ts.SyntaxKind.MethodDeclaration);
    const methodDeclaration = methodDeclarationNodes__?.find((n) => n.name?.text === methodName);
    if (!methodDeclaration) { // no entity class declaration found
        return false;
    }
    else {
        return true;
    }
}
// #####################################################
function createValidationMethodInClass(source, classFilePath, options) {
    if (!source || !classFilePath) {
        return new change_1.NoopChange();
    }
    let methodName = (0, util_1.toValidIdentifier)(options.validatorId);
    // const classDeclarationNode = source.statements.find(n => n.kind == ts.SyntaxKind.ClassDeclaration);
    // if (!classDeclarationNode){ // no class declaration found
    //   throw new Error(
    //     `❌ No Class Declaration Found!`
    //   )
    // }
    // Find the class declaration
    const classDeclaration = source.statements.find((node) => ts.isClassDeclaration(node) && !!node.name);
    if (!classDeclaration) {
        throw new Error(`Class not found in file: ${classFilePath}`);
    }
    // const methodDeclarationNodes__ = (findNodes(source as any, ts.SyntaxKind.MethodDeclaration) as unknown) as ts.DeclarationStatement[];
    // const methodDeclaration = methodDeclarationNodes__?.find((n: ts.DeclarationStatement ) => n.name?.text === methodName);
    // Check if the method already exists
    const methodExists = classDeclaration.members.some((member) => ts.isMethodDeclaration(member) &&
        member.name.getText() === methodName);
    if (methodExists) {
        /**
         * method already declared => do nothing
         *
         * TODO: in case the validation method is (synchronous and  without parameters)
         *  1- introduce a validation simple logic in the validation json configuration
         *  2- retrieve the validation logic (example #value > 10 which means 'the field value is invalid if its value is > 10)
         *  3- update the validation logic in the method
         *
         */
        console.log(`Method '${methodName}' already exists in the class.`);
        return new change_1.NoopChange();
    }
    else { // no method declaration found in the class
        // add the new member declaration to the entity
        // Find the closing brace of the class
        const classEnd = classDeclaration.getEnd();
        // Create the method implementation
        const methodImplementation = getValidationMethodImplementation(options);
        const change = new change_1.InsertChange(classFilePath, classEnd - 1, methodImplementation);
        return change;
    }
}
function updateEntityViewLayout(viewLayoutContent, options) {
    updateValidatorsInViewLayoutEntry(viewLayoutContent, 'createUCViewLayout', options);
    updateValidatorsInViewLayoutEntry(viewLayoutContent, 'editUCViewLayout', options);
    updateValidatorsInViewLayoutEntry(viewLayoutContent, 'viewUCViewLayout', options);
    // updateValidatorsInViewLayoutEntry(viewLayoutContent, 'defaultUCViewLayout', options);
    return viewLayoutContent;
}
function updateValidatorsInViewLayoutEntry(viewLayoutContent, viewLayoutType, options) {
    let validatorEntry = {
        validatorID: `${(0, util_1.toValidIdentifier)(options.validatorId)}`, // Methods name are subject to conventions
        validatorKey: `${options.validatorKey}`,
        type: `${options.classType}`,
        nature: `${options.nature}`,
        validationDefaultMessage: `${options.validationDefaultMessage}`,
        validationMessageTranslationId: `${options.validationMessageTranslationId}`
    };
    if (options.validationParameters && options.validationParameters !== 'none') {
        validatorEntry.parameters = parseValidationParameters(options.validationParameters);
    }
    let fvl = viewLayoutContent[viewLayoutType].ucViewLayout.find(e => e.entityFieldName === options.fieldName);
    if (fvl) {
        if (!fvl.validators) {
            if (validatorEntry.nature === 'sync') {
                fvl['validators'] = {
                    syncValidators: [validatorEntry]
                };
            }
            if (validatorEntry.nature === 'async') {
                fvl['validators'] = {
                    syncValidators: [validatorEntry],
                    updateOn: "blur"
                };
            }
        }
        else {
            if (validatorEntry.nature === 'sync') {
                if (fvl.validators.syncValidators) {
                    if (fvl.validators.syncValidators.findIndex(e => e.validatorID === validatorEntry.validatorID) < 0) {
                        fvl.validators.syncValidators.push(validatorEntry);
                    }
                }
                else {
                    fvl.validators = {
                        syncValidators: [validatorEntry]
                    };
                }
            }
            if (validatorEntry.nature === 'async') {
                if (fvl.validators.asyncValidators) {
                    if (fvl.validators.asyncValidators.findIndex(e => e.validatorID === validatorEntry.validatorID) < 0) {
                        fvl.validators.asyncValidators.push(validatorEntry);
                    }
                    fvl.validators.updateOn = "blur";
                }
                else {
                    fvl.validators = {
                        asyncValidators: [validatorEntry]
                    };
                }
            }
        }
        // replace the old view layout with the new one
        let vlIndex = viewLayoutContent[viewLayoutType].ucViewLayout.findIndex(e => e.entityFieldName === options.fieldName);
        viewLayoutContent[viewLayoutType].ucViewLayout.splice(vlIndex, 1);
        viewLayoutContent[viewLayoutType].ucViewLayout.push(fvl);
    }
}
/**
 * Parses a comma-separated string into an array of strings.
 *
 * This method takes a string with values separated by commas and splits it
 * into an array of individual strings. Empty entries are ignored, and leading
 * or trailing whitespace in each value is trimmed.
 *
 * Examples:
 * - Input: `"value1,value2,value3"`
 *   Output: `["value1", "value2", "value3"]`
 * - Input: `"value,"`
 *   Output: `["value"]`
 * - Input: `""`
 *   Output: `[]`
 *
 * @param input - A comma-separated string to be parsed. It may contain
 *                empty values or whitespace around entries.
 * @returns An array of strings, where each element corresponds to a trimmed
 *          non-empty value from the input string.
 */
function parseValidationParameters(input) {
    return input
        .split(",") // Split the string by commas
        .map(value => value.trim()) // Trim leading and trailing whitespace
        .filter(value => value); // Remove empty strings
}
function registerCustomValidatorInMainApplicationModule(source, modulePath, options, context, validatorImportPath) {
    if (!source || !modulePath) {
        return [new change_1.NoopChange()];
    }
    const providerChanges = (0, util_1.addClassToApplicationMainModuleProviders)(source, modulePath, options.name, validatorImportPath);
    return providerChanges;
}
function getValidationMethodImplementation(options) {
    if (options.nature === 'sync') {
        return getSyncValidationImplementation(options);
    }
    else if (options.nature === 'async') {
        return getAsyncValidationImplementation(options);
    }
    else { // By default 'sync'
        return getSyncValidationImplementation(options);
    }
}
function getSyncValidationImplementation(options) {
    let methodName = (0, util_1.toValidIdentifier)(options.validatorId);
    let methodReturns = 'ValidatorFn';
    const methodImplementation = `\n  /**
  * The synchronous validator method  ${methodName} was generated by averos code generation workflow.
  * 
  * You may enhance this validation method bluprint with your own custom validation logic.
  *  
  * The following validation identifiers are used for this validator:
  *  - validatorID = ${methodName}
  *  - validatorKey = ${options.validatorKey}
  */
   ${methodName}(): ${methodReturns} {
     return (control: AbstractControl): ValidationErrors | null => {
       if (!control.value) {
         return null;
       }
       // implement your validation logic here 
       const valid = false; // not valid
       return valid ? null : { ${options.validatorKey}: true };
     };
   }`;
    return methodImplementation;
}
function getAsyncValidationImplementation(options) {
    let methodName = (0, util_1.toValidIdentifier)(options.validatorId);
    let methodReturns = 'AsyncValidatorFn';
    const methodImplementation = `\n  /**
  * The asynchronous validator method  ${methodName} was generated by averos code generation workflow.
  * 
  * You may enhance this validation method bluprint with your own custom validation logic.
  *  
  * The following validation identifiers are used for this validator:
  *  - validatorID = ${methodName}
  *  - validatorKey = ${options.validatorKey}
  */
   ${methodName}(): ${methodReturns} {
     return (control: AbstractControl): Observable<ValidationErrors | null> => {

      // This is the input value subject to your validation
      let valueSubjectToValidation = control.value;

      /**
       * 
       * Depending on your asynchronous logic, replace the of(valueSubjectToValidation) 
       *  with a method that returns Observable (an api call for example).
       * 
       * Then upon returnedObject implement your validation logic 
       * (Here if returnedObject exist then the field value is invalid)
       * 
       * 
       **/
      return of(valueSubjectToValidation)
      .pipe(map(returnedObject => !!returnedObject ? { asyncValidatorNotValid: true } : null)
      , catchError(err =>  of({asyncValidatorNotValid: true})));
    };
   }`;
    return methodImplementation;
}
/**
 *
 * @param options
 * Inter field validation code gen is not yet supported.
 * To be supported in later phases
 * @returns
 */
function getInterFieldValidationImplementation(options) {
    let methodName = (0, util_1.toValidIdentifier)(options.validatorId);
    let methodReturns = 'AsyncValidatorFn';
    const methodImplementation = `\n  /**
  * ${methodName} is an example of a synchronous validator with no parameters.
  * 
  * You may use this method template 
  *  to create your own synchronous validators along with your specific validatorID and validatorKey
  * 
  * The example below uses the following identifiers:
  *  - validatorID = syncValidationExample
  *  - validatorKey = syncValidationExampleNotValid
  */
   ${methodName}(): ${methodReturns} {
     return (control: AbstractControl): ValidationErrors | null => {
       if (!control.value) {
         return null;
       }
       // implement your validation logic here 
       const valid = false; // not valid
       return valid ? null : { syncValidationExampleNotValid: true };
     };
   }`;
    return methodImplementation;
}
//# sourceMappingURL=index.js.map