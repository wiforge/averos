/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
export declare class AverosValidatorOption {
    type?: string;
    name: string;
    entityName: string;
    fieldName: string;
    nature: string;
    validatorId?: string;
    validatorKey?: string;
    validationParameters?: string;
    classType: string;
    validationDefaultMessage: string;
    validationMessageTranslationId?: string;
    previousSchematics?: string;
    path?: string;
    project?: string;
}
