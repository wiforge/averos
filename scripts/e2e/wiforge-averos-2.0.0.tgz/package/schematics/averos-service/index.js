"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const workspace_1 = require("@schematics/angular/utility/workspace");
const util_1 = require("../util");
const ts = require("typescript");
const change_1 = require("@schematics/angular/utility/change");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:averos-service"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup ////////////
        if (!options.name || options.name.trim() === '') {
            throw new schematics_1.SchematicsException(`Service Name is mandatory! Please provide one`);
        }
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
        }
        if (!options.ename) {
            options.ename = 'any';
        }
        ///// End Options Setup
        // transform the class name into a valid class identifier
        options.ename = (0, util_1.toValidIdentifier)(options.ename, 'class');
        options.name = (0, util_1.toValidIdentifier)(options.name, 'class');
        /// Check if the service already exists
        let serviceAlreadyExist = false;
        const serviceFilePath = (0, util_1.findClassImplementationFilePath)(host, options.name);
        context.logger.info(`🔍Looking for Service with name ${options.name}...🔍`);
        if (serviceFilePath !== null && serviceFilePath !== undefined) {
            context.logger.info(`☑️ Found the Service ${options.name} in the following location ${serviceFilePath}`);
            serviceAlreadyExist = true;
        }
        else {
            context.logger.info(`☑️ Entity Service with name ${options.name} will be added...`);
        }
        const templatesPath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'service') + '/');
        const templateSource = (0, schematics_1.apply)((0, schematics_1.url)('./files'), [
            (0, schematics_1.applyTemplates)({
                ...core_1.strings,
                classifyPreserveTrailingIndex: util_1.classifyPreserveTrailingIndex,
                getRelatedEntityPath,
                toLowerCase,
                ...options
            }),
            (0, schematics_1.move)((0, core_1.getSystemPath)(templatesPath))
        ]);
        return (0, schematics_1.chain)([
            !serviceAlreadyExist ? (0, schematics_1.mergeWith)(templateSource) : (0, schematics_1.noop)(),
            options.assignToEntity ? assignServiceToEntity(options) : (0, schematics_1.noop)()
        ]);
    };
}
function getRelatedEntityPath(path) {
    return (0, core_1.join)((0, core_1.normalize)('../'), 'model');
}
function toLowerCase(str) {
    return (str ? str.toLowerCase() : '');
}
function assignServiceToEntity(options) {
    return (tree, _context) => {
        const entityFilePath = (0, util_1.findClassImplementationFilePath)(tree, options.ename);
        _context.logger.info(`☑️ Assigning the service ${options.name} to the entity ${options.ename}`);
        if (!entityFilePath) {
            throw new Error(`Class ${options.ename} not found in the project.`);
        }
        if (options.path === null || options.path === undefined) {
            throw new Error(`Cannot retrieve the project source path.`);
        }
        const sourceFile = ts.createSourceFile(entityFilePath, tree.read(entityFilePath).toString(), ts.ScriptTarget.Latest, true);
        let serviceFilePath = (0, util_1.findClassImplementationFilePath)(tree, options.name);
        if (serviceFilePath === null) {
            _context.logger.info(`Class '${options.name}' implementation file not found in the project.`);
            serviceFilePath = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.path), 'service') + '/');
            _context.logger.info(`Using the default service file path: '${serviceFilePath}'`);
        }
        let relativeServicePath = (0, util_1.getImportPath)(tree, entityFilePath, serviceFilePath);
        if (relativeServicePath === null || relativeServicePath === undefined) {
            throw new Error(`Cannot retrieve ${options.name} service source file path.`);
        }
        // Step 1: Add the service import for the managed entity
        const insertChange = (0, util_1.insertImportAsTextChange)(sourceFile, options.name, relativeServicePath);
        // Step 2: Add the service class to @AverosEntity() decorator
        const decoratorChange = (0, util_1.addServiceClassToAverosEntityDecorator)(sourceFile, entityFilePath, options.ename, options.name);
        let changes = [];
        changes.push(...insertChange);
        if (decoratorChange) {
            changes.push(decoratorChange);
        }
        applyChanges(tree, entityFilePath, changes);
        _context.logger.info(`☑️ Service ${options.name} assigned to the entity ${options.ename}`);
        return tree;
    };
}
// Utility to apply changes to a file
function applyChanges(tree, filePath, changes) {
    const recorder = tree.beginUpdate(filePath);
    for (const change of changes) {
        if (change instanceof change_1.ReplaceChange) {
            (0, change_1.applyToUpdateRecorder)(recorder, [change]);
        }
        else {
            recorder.insertLeft(change.span.start, change.newText);
        }
    }
    tree.commitUpdate(recorder);
}
//# sourceMappingURL=index.js.map