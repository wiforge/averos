"use strict";
/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = default_1;
exports.createTranslationKeys = createTranslationKeys;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const workspace_1 = require("@schematics/angular/utility/workspace");
function default_1(options) {
    return async (host, context) => {
        context.logger.info(`📦 Running "ng g @wiforge/averos:add-translation-entry"...`);
        context.logger.info(`🔧 Using options: ${JSON.stringify(options)}`);
        /// Option Setup //////////////
        const workspace = await (0, workspace_1.getWorkspace)(host);
        if (!options.project) {
            options.project = workspace.projects.keys().next().value;
            if (!options.project) {
                throw new schematics_1.SchematicsException(`❌ Cannot Retrieve the Project.`);
            }
        }
        context.logger.info(`🔍 Preparing to retrieve the project using: ${options.project}`);
        const project = workspace.projects.get(options.project);
        if (!project) {
            throw new schematics_1.SchematicsException(`❌ Invalid project name: ${options.project}`);
        }
        options.projectRootPath = `${project.root}/`;
        if (options.path === undefined) {
            options.path = (0, workspace_1.buildDefaultPath)(project);
            context.logger.info(`✅ Using the default path: ${options.path}`);
        }
        ///// END Option Setup////////////////////////
        context.logger.info(`🌱 Adding translation for [key,value]= [${options.key, options.value}] to the language ${options.lang}`);
        return (0, schematics_1.chain)([
            createTranslationKeys(options),
        ]);
    };
}
function createTranslationKeys(options) {
    return async (host, context) => {
        let translationFilesLocation = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(options.projectRootPath), `src/assets/i18n/`));
        let dirEntry = host.getDir(translationFilesLocation);
        let targetLangTranslationFile = dirEntry.subfiles.find(e => e === `${options.lang}.json`);
        if (!targetLangTranslationFile) {
            context.logger.error(`❌ No Translation configuration found for the language ${options.lang}!\n
          Please use {ng g @wiforge/averos:add-language} in order to activate averos translation support for your angular project.\n`);
            return (0, schematics_1.noop)();
        }
        let translationFile = (0, core_1.normalize)((0, core_1.join)((0, core_1.normalize)(dirEntry.path), targetLangTranslationFile));
        if (!host.exists(translationFile)) {
            context.logger.error(`❌ No Translation configuration found for the language ${options.lang}!\n
          Please use {ng g @wiforge/averos:add-language} in order to activate averos translation support for your angular project.\n`);
            return (0, schematics_1.noop)();
        }
        let translationContent = host.read(translationFile);
        if (!translationContent) {
            context.logger.error(`❌ No Translation configuration found for the language ${options.lang}!\n
          Please use {ng g @wiforge/averos:add-language} in order to activate averos translation support for your angular project.\n`);
            return (0, schematics_1.noop)();
        }
        let translationData = JSON.parse(translationContent.toString());
        // if (!translationData[`${options.key.toLocaleLowerCase()}`]){ 
        // add or update an existing entry
        translationData[`${options.key}`] = options.value;
        // }
        host.overwrite(translationFile, JSON.stringify(translationData));
        context.logger.info(`✅ The requested translation entry has been added/updated successfully!`);
    };
}
//# sourceMappingURL=index.js.map