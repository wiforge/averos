import * as i0 from '@angular/core';
import { Type, Signal, OnDestroy, OnInit, OnChanges, ElementRef, Renderer2, SimpleChanges, AfterContentChecked, PipeTransform, EventEmitter, Injector, ChangeDetectorRef, ModuleWithProviders, EnvironmentProviders, InjectionToken } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable, Subject, BehaviorSubject, Subscription } from 'rxjs';
import { HttpClient, HttpInterceptorFn } from '@angular/common/http';
import { OverlayContainer } from '@angular/cdk/overlay';
import * as i1$1 from '@angular/router';
import { Router, ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, PreloadingStrategy, Route } from '@angular/router';
import * as i2$1 from '@angular/common';
import * as i3$1 from '@angular/forms';
import { FormGroup, ValidatorFn, AbstractControl, ControlValueAccessor, NgControl, FormBuilder, AsyncValidatorFn } from '@angular/forms';
import * as i1 from '@angular/cdk/layout';
import { BreakpointObserver } from '@angular/cdk/layout';
import * as i2 from '@angular/cdk/a11y';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import * as i3 from '@angular/cdk/clipboard';
import * as i4 from '@angular/cdk/stepper';
import * as i5 from '@angular/cdk/table';
import * as i6 from '@angular/cdk/tree';
import * as i7 from '@angular/cdk/menu';
import * as i8 from '@angular/cdk/drag-drop';
import { CdkDragDrop, CdkDragStart } from '@angular/cdk/drag-drop';
import * as i9 from '@angular/material/autocomplete';
import * as i10 from '@angular/material/badge';
import * as i11 from '@angular/material/bottom-sheet';
import { MatBottomSheet, MatBottomSheetRef } from '@angular/material/bottom-sheet';
import * as i12 from '@angular/material/button';
import * as i13 from '@angular/material/button-toggle';
import * as i14 from '@angular/material/card';
import * as i15 from '@angular/material/checkbox';
import { MatCheckboxChange } from '@angular/material/checkbox';
import * as i16 from '@angular/material/chips';
import { MatChipGrid, MatChipInputEvent } from '@angular/material/chips';
import * as i17 from '@angular/material/stepper';
import * as i18 from '@angular/material/datepicker';
import * as i19 from '@angular/material/dialog';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import * as i20 from '@angular/material/divider';
import * as i21 from '@angular/material/expansion';
import { MatExpansionPanel } from '@angular/material/expansion';
import * as i22 from '@angular/material/grid-list';
import * as i23 from '@angular/material/icon';
import { MatIconRegistry, MatIcon } from '@angular/material/icon';
import * as i24 from '@angular/material/input';
import { MatInput } from '@angular/material/input';
import * as i25 from '@angular/material/list';
import * as i26 from '@angular/material/menu';
import * as i27 from '@angular/material/core';
import { ThemePalette } from '@angular/material/core';
import * as i28 from '@angular/material/paginator';
import { PageEvent, MatPaginator } from '@angular/material/paginator';
import * as i29 from '@angular/material/progress-bar';
import { ProgressBarMode } from '@angular/material/progress-bar';
import * as i30 from '@angular/material/progress-spinner';
import * as i31 from '@angular/material/radio';
import * as i32 from '@angular/material/select';
import { MatSelect, MatSelectChange } from '@angular/material/select';
import * as i33 from '@angular/material/sidenav';
import { MatSidenav } from '@angular/material/sidenav';
import * as i34 from '@angular/material/slider';
import * as i35 from '@angular/material/slide-toggle';
import * as i36 from '@angular/material/snack-bar';
import * as i37 from '@angular/material/sort';
import { MatSort } from '@angular/material/sort';
import * as i38 from '@angular/material/table';
import { MatTableDataSource } from '@angular/material/table';
import * as i39 from '@angular/material/tabs';
import * as i40 from '@angular/material/toolbar';
import * as i41 from '@angular/material/tooltip';
import * as i42 from '@angular/material/tree';
import * as i43 from '@angular/cdk/portal';
import * as i44 from '@angular/cdk/scrolling';
import * as i45 from '@angular/material/form-field';
import { MatFormFieldAppearance } from '@angular/material/form-field';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import * as _wiforge_averos from '@wiforge/averos';
import { SelectionModel } from '@angular/cdk/collections';

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * Minimal canonical representation of an authenticated user.
 * This is the contract between @wiforge/averos and any auth provider.
 * @file auth-user.interface.ts
 */
interface AuthUser<TMetadata = Record<string, any>> {
    /** Unique identifier for the user (maps to 'sub' in JWT/OIDC, UUID, Firebase UID, etc.) */
    id: string | number;
    /** Username or email/login name (maps to 'preferred_username' in OIDC) */
    username: string;
    /** User's email address */
    email?: string;
    /** User's display name or full name (maps to 'name' in OIDC, full name or nickname) */
    displayName?: string;
    /** Given/first name */
    givenName?: string;
    /** Family/last name */
    familyName?: string;
    /** URL to user's profile photo/avatar/Profile picture */
    picture?: string;
    /** User's preferred locale/language (e.g., 'en-US', 'fr-FR') */
    locale?: string;
    /**
     * User's assigned roles for role-based access control (RBAC)
     * @example ['admin', 'editor', 'user']
     */
    roles?: string[] | any[];
    /**
     * User's granted permissions for fine-grained access control
     * @example ['posts:write', 'users:read', 'settings:*']
     */
    permissions?: string[];
    /**
     * Whether the user's email has been verified
     */
    emailVerified?: boolean;
    /**
     * ISO 8601 timestamp when the authentication token expires
     * Used for proactive token refresh
     * @example "2024-01-15T14:30:00.000Z"
     */
    expiresAt?: string;
    /**
     * ISO 8601 timestamp when the token was issued
     * @example "2024-01-15T12:00:00.000Z"
     */
    issuedAt?: string;
    /** When the user last updated their profile */
    updatedAt?: string;
    /** Any additional claims/attributes from the auth provider */
    metadata?: TMetadata;
    provider?: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file auth-provider.abstract.ts
 * @description Contract that any authentication provider must implement.
 * This abstraction allows the library to work with any auth system
 * (JWT, OAuth, OIDC, Keycloak, social auth, etc.)
 */

/**
 * Structured error types for authentication failures
 */
declare enum AuthErrorType {
    INVALID_CREDENTIALS = "INVALID_CREDENTIALS",
    SESSION_EXPIRED = "SESSION_EXPIRED",
    NETWORK_ERROR = "NETWORK_ERROR",
    UNAUTHORIZED = "UNAUTHORIZED",
    FORBIDDEN = "FORBIDDEN",
    PROVIDER_ERROR = "PROVIDER_ERROR",
    UNKNOWN = "UNKNOWN"
}
interface AuthError {
    type: AuthErrorType;
    message: string;
    originalError?: any;
    statusCode?: number;
}
/**
 * Configuration options that can be passed during initialization
 */
interface AuthProviderConfig {
    autoRefresh?: boolean;
    tokenStorageKey?: string;
    redirectUrl?: string;
    /**
     * Whether this provider manages its own persistence
     * (e.g., Firebase SDK handles tokens internally)
     * @default false
     */
    selfManaged?: boolean;
    [key: string]: any;
}
/**
 * Abstract class defining the authentication provider contract.
 * All auth providers (JWT, Keycloak, Auth0, etc.) must implement this.
 */
declare abstract class AverosAuthProvider {
    /**
     * Returns the current provider class name.
     * Mandatory Metadata field for averos framework
     * Used to get the currentProvider,
     * Every provider MUST override this static field with its own class name!
     *
     */
    static readonly typeName: string;
    readonly className: string;
    /**
     * Initialize the auth provider.
     * Called once during app bootstrap (APP_INITIALIZER).
     * Should check for existing sessions, validate tokens, etc.
     *
     * @returns Promise that resolves with current user or null
     */
    abstract initialize(config?: AuthProviderConfig): Promise<AuthUser | null>;
    /**
     * Initiate login flow.
     * Implementation varies by provider:
     * - JWT: POST credentials to endpoint
     * - OAuth/OIDC: Redirect to authorization server
     * - Social: Open popup/redirect to provider
     *
     * @param credentials Provider-specific credentials (username/password, token, etc.)
     * @returns Promise resolving to authenticated user or null if cancelled
     * @throws AuthError on failure
     */
    abstract login(credentials?: any): Promise<AuthUser | null>;
    /**
     * Initiate logout flow.
     * Should clear tokens, revoke sessions, notify auth server if needed.
     *
     * @returns Promise that resolves when logout is complete
     */
    abstract logout(): Promise<void>;
    /**
     * Get the current access token.
     * Used by HTTP interceptor to attach to requests.
     *
     * @returns Current token or null if not authenticated
     */
    abstract getToken(): string | null;
    /**
     * Refresh the authentication token/session.
     * Called automatically by interceptor on token expiration (401).
     *
     * @returns Promise resolving to updated user with fresh token
     * @throws AuthError if refresh fails
     */
    abstract refreshToken(): Promise<AuthUser | null>;
    /**
     * Check if current session is valid.
     * Should verify token expiration, validate with server if needed.
     *
     * @returns Promise resolving to true if session is valid
     */
    abstract isSessionValid(): Promise<boolean>;
    /**
     * Validates token according to provider-specific rules
     * (e.g., JWT signature verification, OAuth token introspection)
     */
    isTokenValid?(user: AuthUser): boolean;
    /**
     * Get token expiration time.
     * Used for proactive token refresh and UI feedback.
     *
     * @returns ISO 8601 timestamp or null if no active session
     */
    abstract getTokenExpiration(): string | null;
    /**
     * Get the token issuance time (iat claim).
     * Used internally by the AverosAuthService to calculate client-side
     * expiry using a default lifetime, ONLY if getTokenExpiration() is null
     * and AuthUser.expiresAt is missing.
     * * @returns ISO 8601 timestamp or null if not available
     */
    abstract getTokenIssuedAt(): string | null;
    /**
   * Clear any data related to a persisted session
   */
    clearSession?(): void;
    /**
     * Check if user has specific role(s).
     * Supports both single role and array of roles.
     *
     * @param role Single role or array of roles to check
     * @param requireAll If true, user must have ALL roles; if false, ANY role
     * @returns true if user has required role(s)
     */
    abstract hasRole(role: string | string[], requireAll?: boolean): boolean;
    /**
     * Check if user has specific permission(s).
     * For fine-grained access control beyond roles.
     *
     * @param permission Single permission or array of permissions
     * @param requireAll If true, user must have ALL permissions; if false, ANY
     * @returns true if user has required permission(s)
     */
    abstract hasPermission(permission: string | string[], requireAll?: boolean): boolean;
    /**
     * Check if user can specific permission(s).
     * For fine-grained access control beyond roles.
     *
     * Ex. special permissions : `resource:action` (e.g., "posts:write")
     * @param resource the requested resource
     * @param action the requested action
     * @returns true if user can access the ressource for the given action
     */
    abstract canAccess(resource: string, action?: string): boolean;
    /**
     * Get current user's roles.
     * Convenience method for role-based UI rendering.
     *
     * @returns Array of role strings (empty if not authenticated)
     */
    abstract getRoles(): string[];
    /**
     * Get current user's permissions.
     * Convenience method for permission-based UI rendering.
     *
     * @returns Array of permission strings (empty if not authenticated)
     */
    abstract getPermissions(): string[];
    /**
     * Observable stream of authentication state changes.
     * Emits whenever user logs in, logs out, or token refreshes.
     *
     * Used by guards, interceptors, and components that need
     * to react to auth state changes.
     */
    abstract readonly authState$: Observable<AuthUser | null>;
    /**
     * Observable stream of authentication errors.
     * Emits when login fails, token expires, etc.
     *
     * Useful for global error handling and user notifications.
     */
    abstract readonly authError$: Observable<AuthError>;
    /**
     * Navigate to login page/flow.
     * Implementation varies by provider:
     * - JWT: Navigate to /login route
     * - OAuth: Redirect to authorization URL
     * - Social: Open provider popup
     *
     * Optional - library can handle routing itself if not implemented.
     */
    navigateToLogin?(): void;
    /**
     * Handle post-login redirect.
     * Navigate to intended destination after successful authentication.
     *
     * @param returnUrl URL to redirect to (defaults to home)
     */
    navigateAfterLogin?(returnUrl?: string): void;
    /**
     * Handle post-logout redirect.
     * Navigate to public page after logout.
     */
    navigateAfterLogout?(): void;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file averos-auth-providers.registry.ts
 * @description Centralized registry for authentication provider types and metadata
 */
/**
 * Supported authentication providers
 */
declare enum AverosAuthProviderType {
    FIREBASE = "firebase",
    GOOGLE = "google",
    GITHUB = "github",
    KEYCLOAK = "keycloak",
    DUMMY = "dummy",
    CUSTOM = "custom"
}
/**
 * Authentication flow types supported by Averos
 */
type AverosAuthFlow = 'delegated' | 'credentials';
/**
 * String literal type for better autocomplete and validation
 */
declare const AVEROS_AUTH_FLOWS: {
    readonly DELEGATED: "delegated";
    readonly CREDENTIALS: "credentials";
};
/**
 * Provider display metadata
 */
interface AverosAuthProviderMetadata {
    /** Provider identifier */
    name: string;
    /** Display name for UI */
    displayName: string;
    /** Icon identifier (for mat-icon with safeIcon directive) */
    icon?: string;
    /** Authentication flow type */
    authFlow: AverosAuthFlow;
    /** Tooltip text for login button */
    tooltip: string;
    /** Whether this provider is enabled */
    enabled?: boolean;
}
/**
 * Default provider metadata registry
 */
declare const AVEROS_AUTH_PROVIDER_METADATA: Record<string, AverosAuthProviderMetadata>;
/**
 * Helper to get provider metadata
 */
declare function getProviderMetadata(providerName: string): AverosAuthProviderMetadata | undefined;
/**
 * Helper to check if provider uses credentials flow
 */
declare function isCredentialsProvider(providerName: string): boolean;
/**
 * Helper to check if provider uses delegated flow
 */
declare function isDelegatedProvider(providerName: string): boolean;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

/**
 * @file averos-auth-config.interface.ts
 * @description Enhanced authentication configuration with flow types
 */
/**
 * Global Configuration for the auth service itself
 */
interface AverosAuthConfig {
    /**
     * Persist auth state to localStorage (default: true)
     * When false, user must re-authenticate on every app reload
     */
    persistState?: boolean;
    /** Storage key for persisted state (default: 'averos_auth_user') */
    storageKey?: string;
    /** Default token lifetime in minutes if expiresAt is not provided by provider (default: 1440 mins / 24 hours) */
    defaultTokenLifetimeMinutes?: number;
    /**
     * Defines how authentication is performed for this provider.
     *
     * - 'credentials': The application collects and submits the user's
     *                  username and password directly to the provider.
     *
     * - 'delegated': Authentication is delegated to an external identity provider.
     *                The application does not handle credentials and instead
     *                redirects the user to the provider’s login flow and relies
     *                on the returned tokens or assertions.
     */
    authFlow?: AverosAuthFlow;
    /**
     * Persist the active provider name separately from user state
     * This allows restoration of the correct provider even when persistState is false
     * Useful when providers manage their own session (e.g., Firebase)
     * @default true
     */
    persistActiveProvider?: boolean;
}
/**
 * Registration for a single auth provider
 */
interface AuthProviderRegistration<T = Record<string, any>> {
    /** Unique name to identify this provider */
    name: string;
    /**
     * The auth provider implementation to use.
     */
    provider: Type<AverosAuthProvider>;
    /** Provider-specific configuration */
    config?: AverosAuthConfig & T;
}
/**
 * Configuration for single provider mode
 */
interface SingleProviderConfig<T = Record<string, any>> {
    /** Unique name to identify this provider */
    name: string;
    /**
     * The auth provider implementation to use.
     */
    provider: Type<AverosAuthProvider>;
    /**
     * Configuration combining core auth config and provider-specific config
     */
    config?: AverosAuthConfig & T;
}
/**
 * Configuration for multiple providers mode
 */
interface MultiProviderConfig<T = Record<string, any>> {
    /**
     * Default/primary provider to use initially
     */
    defaultProvider: string;
    /**
     * List of all available auth providers
     */
    providers: AuthProviderRegistration[];
    /**
     * General auth service configuration (applies to all providers)
     */
    config?: AverosAuthConfig & T;
}
/**
 * Union type for provider configuration
 */
type AverosAuthProviderConfig<T = Record<string, any>> = SingleProviderConfig<T> | MultiProviderConfig<T>;
/**
 * Type guard to check if config is multi-provider
 */
declare function isMultiProviderConfig(config: AverosAuthProviderConfig): config is MultiProviderConfig;
/**
 * Type guard to check if config is single-provider
 */
declare function isSingleProviderConfig(config: AverosAuthProviderConfig): config is SingleProviderConfig;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file http-auth-config.ts
 * @description Configuration class for HTTP authentication interceptor behavior.
 * Controls how authentication tokens are attached to requests, which routes require auth,
 * and how authentication failures are handled.
 *
 * @example
 * ```typescript
 * const config: HttpAuthConfig = {
 *   tokenHeader: 'X-Auth-Token',
 *   tokenPrefix: 'Token',
 *   publicRoutes: ['/public/*', '/health'],
 *   unauthorizedRedirect: '/auth/login',
 *   withCredentials: true,
 *   maxRefreshRetries: 2
 * };
 * ```
 */
/**
 * Configuration interface for HTTP authentication interceptor.
 *
 * This configuration controls how the Averos authentication interceptor
 * handles token injection, public routes, and authentication failures.
 * All properties are optional with sensible defaults.
 */
interface HttpAuthConfig {
    /**
     * HTTP header name used to send the authentication token.
     *
     * @default 'Authorization'
     *
     * @remarks
     * - Most REST APIs use the standard 'Authorization' header
     * - Some legacy systems may require custom headers like 'X-Auth-Token'
     * - The header name is case-insensitive per HTTP specification
     *
     * @example
     * ```typescript
     * // Standard OAuth 2.0 / JWT setup
     * tokenHeader: 'Authorization'
     *
     * // Custom header for legacy API
     * tokenHeader: 'X-Auth-Token'
     *
     * // Custom header with vendor prefix
     * tokenHeader: 'X-Company-Authorization'
     * ```
     */
    tokenHeader?: string;
    /**
     * Prefix/scheme prepended to the token value in the header.
     *
     * @default 'Bearer'
     *
     * @remarks
     * - 'Bearer' is the standard for OAuth 2.0 and JWT (RFC 6750)
     * - Some APIs use 'Token', 'JWT', or custom schemes
     * - Set to empty string ('') if no prefix is needed
     * - The prefix is automatically followed by a space before the token
     *
     * @example
     * ```typescript
     * // Standard Bearer token (most common)
     * tokenPrefix: 'Bearer'
     * // Result: Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
     *
     * // Token scheme (used by some APIs)
     * tokenPrefix: 'Token'
     * // Result: X-Auth-Token: Token abc123def456...
     *
     * // No prefix (token only)
     * tokenPrefix: ''
     * // Result: Authorization: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
     *
     * // Custom scheme
     * tokenPrefix: 'JWT'
     * // Result: Authorization: JWT eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
     * ```
     */
    tokenPrefix?: string;
    /**
     * Array of URL patterns that should bypass authentication entirely.
     *
     * @default []
     *
     * @remarks
     * - Routes matching these patterns will not have auth headers attached
     * - Useful for public endpoints, health checks, and anonymous access
     * - Supports wildcard matching with '/*' suffix
     * - Pattern matching is performed using string inclusion
     * - Evaluated before attempting to attach authentication tokens
     *
     * @example
     * ```typescript
     * publicRoutes: [
     *   '/public/*',        // All routes under /public
     *   '/api/health',      // Health check endpoint
     *   '/api/version',     // Version info endpoint
     *   '/assets/*',        // Static assets
     *   '/docs/*',          // Public documentation
     *   '/auth/register',   // Registration endpoint
     *   '/auth/forgot-password'  // Password reset
     * ]
     * ```
     *
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Authorization}
     */
    publicRoutes?: string[];
    /**
     * Route path to navigate to when authentication fails and cannot be recovered.
     *
     * @default '/login'
     *
     * @remarks
     * - Triggered when token refresh fails or max retry attempts are exceeded
     * - Should point to your application's login page or authentication flow entry
     * - User will be automatically logged out before navigation
     * - The interceptor will navigate to this route after clearing auth state
     *
     * @example
     * ```typescript
     * // Standard login page
     * unauthorizedRedirect: '/login'
     *
     * // Custom auth flow
     * unauthorizedRedirect: '/auth/signin'
     *
     * // Dedicated session expired page
     * unauthorizedRedirect: '/session-expired'
     *
     * // Public landing page
     * unauthorizedRedirect: '/'
     * ```
     */
    unauthorizedRedirect?: string;
    /**
     * Whether to include credentials (cookies, authorization headers, TLS client certificates)
     * in cross-origin requests.
     *
     * @default true
     *
     * @remarks
     * - When true, sets XMLHttpRequest.withCredentials = true
     * - Required for sending cookies in CORS requests
     * - Server must respond with 'Access-Control-Allow-Credentials: true'
     * - Cannot be used with 'Access-Control-Allow-Origin: *' (must specify exact origin)
     * - Essential for session-based authentication in cross-origin scenarios
     *
     * @example
     * ```typescript
     * // Enable credentials for cookie-based auth
     * withCredentials: true
     *
     * // Disable for purely token-based auth without cookies
     * withCredentials: false
     * ```
     *
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest/withCredentials}
     */
    withCredentials?: boolean;
    /**
     * Maximum number of automatic token refresh attempts before forcing logout.
     *
     * @default 1
     *
     * @remarks
     * - Prevents infinite retry loops on persistent auth failures
     * - Counter resets to 0 after successful token refresh
     * - After max attempts, user is logged out and redirected
     * - Set to 0 to disable automatic refresh entirely (not recommended)
     * - Higher values provide more resilience against transient network issues
     * - Lower values fail faster but may logout prematurely on network hiccups
     *
     * @example
     * ```typescript
     * // Single retry (fail fast)
     * maxRefreshRetries: 1
     *
     * // Multiple retries (resilient to transient failures)
     * maxRefreshRetries: 3
     *
     * // No automatic refresh (manual re-authentication only)
     * maxRefreshRetries: 0  // Not recommended
     * ```
     */
    maxRefreshRetries?: number;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum LogLevel {
    DEBUG = 1,// log weight 1
    INFO = 2,// log weight 2
    WARN = 3,// log weight 3
    ERROR = 4
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

interface FrameworkConfiguration {
    supportedLanguages?: string[];
    enableAuthentication?: boolean;
    enableExternalEntityMapping?: boolean;
    debug?: boolean;
    logLevel?: string | LogLevel;
    /**
     * Averos authentication provider(s) configuration
     */
    authProvidersConfig?: AverosAuthProviderConfig;
    /**
     * HTTP authentication interceptor configuration
     */
    httpAuthConfig?: HttpAuthConfig;
}

/**
 * Available alert types for the notification system
 */
type AlertType = 'Loading' | 'InlineLoading' | 'Success' | 'Error' | 'Warning' | 'AlertMessage';
/**
 * Structure of an alert message
 */
interface AlertMessage {
    readonly type: AlertType;
    readonly text?: string;
}
/**
 * AlertService
 *
 * Centralized service for managing application-wide notifications, alerts, and loading states.
 * Uses Angular signals for reactive state management.
 *
 * Features:
 * - Success, Error, and Warning notifications
 * - Full-screen and inline loading indicators
 * - Dialog response tracking
 * - Automatic cleanup on route navigation
 * - Optional persistence across route changes
 *
 * @example
 * ```typescript
 * constructor(private alertService: AlertService) {}
 *
 * // Show success message
 * this.alertService.success('Data saved successfully!');
 *
 * // Show loading indicator
 * this.alertService.enableLoading();
 *
 * // Clear all notifications
 * this.alertService.clearAll();
 * ```
 */
declare class AlertService {
    private readonly router;
    private readonly injector;
    static readonly LOADING: AlertType;
    static readonly INLINELOADING: AlertType;
    static readonly SUCCESS: AlertType;
    static readonly ERROR: AlertType;
    static readonly WARNING: AlertType;
    private readonly alertSignal;
    private readonly dialogResponseSignal;
    private readonly keepAfterRouteChangeSignal;
    /**
     * Current alert message (read-only)
     */
    readonly alert: i0.Signal<AlertMessage>;
    /**
     * Current dialog response (read-only)
     */
    readonly dialogResponse: i0.Signal<boolean>;
    /**
     * Returns true if any loading indicator is active
     */
    readonly isLoading: i0.Signal<boolean>;
    /**
     * Returns true if full-screen loading is active
     */
    readonly isFullScreenLoading: i0.Signal<boolean>;
    /**
     * Returns true if inline loading is active
     */
    readonly isInlineLoading: i0.Signal<boolean>;
    /**
     * Returns true if an alert message exists
     */
    readonly hasAlert: i0.Signal<boolean>;
    /**
     * Returns true if a dialog response exists
     */
    readonly hasDialogResponse: i0.Signal<boolean>;
    /**
     * Returns the current alert type, or null if no alert
     */
    readonly currentAlertType: i0.Signal<AlertType>;
    /**
     * Returns true if current alert is a user message (success/error/warning)
     */
    readonly isUserMessage: i0.Signal<boolean>;
    constructor();
    /**
     * Initialize automatic cleanup on route navigation
     */
    private initializeRouteChangeHandler;
    /**
     * Display a success notification
     * @param message - The success message to display
     * @param keepAfterRouteChange - If true, keeps the message after navigation
     */
    success(message: string, keepAfterRouteChange?: boolean): void;
    /**
     * Display an error notification
     * @param message - The error message to display
     * @param keepAfterRouteChange - If true, keeps the message after navigation
     */
    error(message: string, keepAfterRouteChange?: boolean): void;
    /**
     * Display a warning notification
     * @param message - The warning message to display
     * @param keepAfterRouteChange - If true, keeps the message after navigation
     */
    warn(message: string, keepAfterRouteChange?: boolean): void;
    /**
     * Enable a loading indicator
     * @param isInlineLoading - If true, shows inline loading; otherwise shows full-screen loading
     */
    enableLoading(isInlineLoading?: boolean): void;
    /**
   * Disable any active loading indicators (Full-screen or Inline).
   * * @update This method checks if the current alert is a user message (error, success, etc.).
   * If it is, it leaves the message intact, only clearing the loading state.
   * If it is *only* a loading state, it clears the alert signal entirely.
   */
    disableLoading(): void;
    /**
     * Clear all active notifications
     */
    clearNotifications(): void;
    /**
     * Clear the dialog response
     */
    clearDialogResponse(): void;
    /**
   * Clear the main alert signal. This should only be used by methods
   * that are immediately replacing the state (e.g., showAlert) or when
   * route navigation is clearing everything.
   */
    private clearAlertState;
    /**
     * Clear everything (notifications and dialog responses)
     */
    clearAll(): void;
    /**
     * Set a dialog response value
     * @param response - The boolean response from a dialog
     */
    setDialogResponse(response: boolean): void;
    /**
     * Get dialog response as an Observable for backward compatibility
     * Useful for route guards and other Observable-based patterns
     *
     * @returns Observable that emits the next dialog response
     *
     */
    getDialogResponse(): Observable<boolean>;
    /**
     * Internal method to show an alert with specified type and message
     */
    private showAlert;
    /**
     * Retrieve the Alert Dialog user response.
     * AlertService.WARNING: 2 responses: either YES/OK/PROCEED (true) or NO/CANCEL/ABORT (false)
     * AlertService.SUCCESS | AlertService.ERROR: 1 response OK/PROCEED (true)
     * @returns Observable<boolean>
     */
    getAlertDialogResponse(): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AlertService>;
}

declare class LocalStorageService {
    constructor();
    get(key: string): any;
    set(key: string, value: any): boolean;
    remove(key: string): void;
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LocalStorageService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class AverosTicker {
    tickerID: string;
    tickerMessage: string;
    disposable: boolean;
    tickerMessageTranslationID?: string;
    tickerIcon?: boolean;
    constructor(tickerID: string, tickerMessage: string, disposable?: boolean);
}

declare class ApplicationSharedService {
    private localStorageService;
    private httpClient;
    private readonly averosConfig;
    private iconThemeSubject;
    iconsTheme$: Observable<string>;
    onThemeSwitch: Subject<boolean>;
    onIconsThemeSwitch: Subject<string>;
    onGoFullScreen: Subject<boolean>;
    onChangeLanguage: Subject<string>;
    onOpenDesigner: Subject<boolean>;
    systemTickers: BehaviorSubject<Array<AverosTicker>>;
    userTickers: BehaviorSubject<Array<AverosTicker>>;
    currentUser: AuthUser;
    currentIpAddress: string;
    systemTickers_: AverosTicker[];
    userTickers_: AverosTicker[];
    private authenticationEnabled_;
    private enableExternalEntityMapping_;
    private userStorageSettings;
    private unsubscribe$;
    private iPInitialized;
    onThemeChangeSubscription: Subscription;
    onIconsThemeChangeSubscription: Subscription;
    onGoFullScreenSubscription: Subscription;
    onChangeLanguageSubscription: Subscription;
    darkThemeActivated: boolean;
    darnetDarkTheme: string;
    DEFAULT_NETWORK_DELAY: number;
    constructor(localStorageService: LocalStorageService, httpClient: HttpClient);
    setLocalUserSettings(userSettings: any): void;
    get authenticationEnabled(): boolean;
    get externalEntityMappingEnabled(): boolean;
    get user(): AuthUser<Record<string, any>>;
    addAverosCoreTicker(tickler: AverosTicker): void;
    removeAverosCoreTicker(ticklerID: string): void;
    updateAverosCoreTicker(ticklerID: string, tickler: AverosTicker): void;
    addUserTicker(tickler: AverosTicker): void;
    removeUserTicker(ticklerID: string): void;
    updateUserTicker(ticklerID: string, tickler: AverosTicker): void;
    getLocalUserSettings(): any;
    addOrUpdateKeyValueToLocalUserSettings(key: string, value: any): void;
    clearUserSettings(): void;
    clearLocalStorage(): void;
    isDarkThemeActive(): boolean;
    getProfileIconsTheme(): string;
    getIconsTheme(): string;
    setIconsTheme(theme: string): void;
    getIPAddress(): Observable<any>;
    initializeIPAddress(): void;
    initializeIPaddress(): Promise<any>;
    initializeCustomThemeActions(overlayContainer: OverlayContainer, document: Document): void;
    handleCustomIconsTheme(): void;
    handleCustomTheme(overlayContainer: OverlayContainer, document_: Document): void;
    switchToFullscreen(elementt: any): void;
    closeFullscreen(documentt: any): void;
    isOnFullscreen(documentt: any): boolean;
    switchApplicationLanguage(): void;
    destroySubscriptions(): void;
    /**
       * Simulate network delay for testing purposes
       * @param delay The number of milliseconds to wait before calling the
       * `callback
       */
    delay(ms?: number): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationSharedService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApplicationSharedService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class ApplicationNavigationItem {
    loggedSpace?: boolean;
    disabled?: boolean;
    displayName?: string;
    translationID?: string;
    iconName?: string;
    route?: string;
    type?: 'link' | 'sub' | 'extLink' | 'extTabLink';
    label?: NavigationItemTag;
    badge?: NavigationItemTag;
    children?: ApplicationNavigationItem[];
}
declare class NavigationItemTag {
    color: string;
    value: string;
    translationID: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum DataRetrievalMethod {
    EAGER = "eager",
    LAZY = "lazy"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class AverosLocalServiceCall {
    service: any;
    method: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class DataRetrievalStrategy {
    /**
     * Data retrieval method is either EAGER or LAZY.
     * When retrieval method is EAGER the data is retrieved along with the parent query
     * When retrieval mehtod is LAZY data is retrieved on demand using a dedicated query.
     * In this case two keys are mandatory for the search:
     *  - the parent entity search key: should be unique (entity._entityLogicalName by defaut or using a call to TypeScriptTypeMetaDatatHandler.instance.getBusinessIdName(entityType))
     *  - the child entity search key: should also be inique (entity.fileName for example)
     */
    retrievalMethod?: DataRetrievalMethod;
    /**
     * Defines where data is located. This key could be :
     *  - either the entity key that is reponsible for retrieving the data (if data is static)
     *  - or a function that returns the requested data (a dedicated search query for example when retrievalMethod = LAZY)
     */
    dataRetrievalAccessLocation?: string | ((...args: any) => Observable<any>) | AverosLocalServiceCall;
    /**
     * A label that depicts the data.
     * Defines the fileName for type file
     */
    dataLabel?: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum FieldType {
    string = "string",
    number = "number",
    boolean = "boolean",
    date = "date",
    image = "image",
    textarea = "textarea",
    password = "password",
    combo = "combo",
    phone = "phone",
    composite = "composite",
    collection = "collection",
    numberslider = "numberslider",
    file = "file"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class FieldValidator {
    syncValidators?: ValidatorMetaData[];
    asyncValidators?: ValidatorMetaData[];
    updateOn?: string;
}
declare class ValidatorMetaData {
    /**
     * validator implementation examples:
     *  validatorID = patternValidator
     * validatorKey = invalidPassword
     *
     * validatorID = birthDateValidator
     * validatorKey = invalidBirthDate_under18
     *
     * validatorID = userNameValidator
     * validatorKey = userNameNotAvailable
     *
     * validatorID = emailAlreadyexistsValidator
     * validatorKey = emailNotAvailable
     */
    validatorID: string;
    validatorKey: string;
    parameters?: any;
    type: string;
    nature: string;
    validationDefaultMessage?: string;
    validationMessageTranslationID?: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class GroupedFieldViewLayout {
    groupId: number;
    groupLabel?: string;
    groupLabelTranslationID?: string;
    groupOrder?: number;
    /**
     * layout: Describes the target field placeholder container into which the field will be displayed.
     *          the group layout is only relevent and mandatory for composite relations (either composite simple relation aka 1 <--> 1 relations
     *              or 1 <--> n relations).
     *          On the other hand, Simple type members (string, boolean, number...) are displayed within the same parent container group.
     *
     *
     *      -   = 'tab' : display the filed into a tab group. Appliable for 1<-->1 as well as 1<-->n relations
     *      -   = 'inline': display the field into the parent container group. Apliable only for composite 1<-->1 relations
     */
    layout?: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class DomainEntry {
    key: string;
    value: string;
    translationID?: string;
    constructor(key: string, value: string, translationID?: string);
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class ValueDomainController {
    domainControllerType: string;
    domainControllerMethod: string;
    parameters?: any;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class TargetDomainField {
    defaultDomain?: DomainEntry[];
    domainServiceRepository?: ValueDomainController;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class FieldViewLayout {
    entityFieldName: string;
    label: string;
    labelTranslationID?: string;
    placeholder?: string;
    placeholderTranslationID?: string;
    visible: boolean;
    disabled?: boolean;
    order?: number;
    format?: string;
    /**
     * The field 'type' could be: 'composite' | 'date' | 'collection' | 'image' | 'password' | 'combo' | 'phone'...
     * The view layout placeholder depends on this type. default to 'string' => text field
     * This field could be :
     *  -   a simple field (type = string, number, date, password, boolean... )
     *  -   a relationship with an other entity ( [type = 'composite'] and [typeName = the target relation type] in this case)
     *  -   a collection of composite or simple types ( [type = 'collection'] and [typeName = the collection item type] in this case)
     */
    type?: FieldType;
    typeName?: string;
    /**
     * The display depends on the field type as well as the current use case:
     *  * field type = collection: ==> displayContainerType == grid (a table of values)
     */
    icon?: string;
    required?: boolean;
    targetFieldDomain?: TargetDomainField;
    validators?: FieldValidator;
    defaultValue?: any;
    fieldGroup?: GroupedFieldViewLayout;
    dataRetrievalStrategy?: DataRetrievalStrategy;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

/**
 * A placeholder for a Page layout
 */
declare class UseCaseViewLayout<T> {
    static readonly STANDARD_GROUP_MAX_LINE_ITEMS: number;
    /**
     * The maximum number of dislayed items in a given group within a line:
     *  -   standardGroupMaxLineItems: desktop web app display config
     *
     */
    standardGroupMaxLineItems: number;
    /**
     * The page title
     */
    title: string;
    titleTranslationID: string;
    /**
     * The parent entity name or the relation owner.
     *
     */
    parentEntityLabel: string;
    parentEntityLabelTranslationId: string;
    /**
     * Wether the components are ordered within the view or not
     */
    orderedView: boolean;
    /**
     * Fields view Layout:
     *  string: entity field name
     *  FieldViewLayout: Entity Field View Layout
     */
    ucViewLayout: FieldViewLayout[];
    /**
     * default icon orientation is RIGHT (SUFFIX) for edit usecase
     * and LEFT (PREFIX) for View usecase
     */
    iconOrientation: string;
    /**
     * the entity class type entity view layout is propagated here
     */
    entityType: T;
    constructor(orderedView: boolean);
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class EntityViewLayout<T> {
    defaultUCViewLayout?: UseCaseViewLayout<T>;
    searchInputUCViewLayout?: UseCaseViewLayout<T>;
    tableUCViewLayout?: UseCaseViewLayout<T>;
    selectableInputTableUCViewLayout?: UseCaseViewLayout<T>;
    viewUCViewLayout?: UseCaseViewLayout<T>;
    createUCViewLayout?: UseCaseViewLayout<T>;
    editUCViewLayout?: UseCaseViewLayout<T>;
    entityClass?: T;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

/**
 *
 * This is a configuration placeholder for the dialog use cases
 *
 */
declare class UseCaseDialogData<T> {
    private entityObject;
    private viewLayout;
    private width;
    constructor(entityObject: T, viewLayout: Observable<EntityViewLayout<T>>, width: string);
    getEntityObject(): T;
    getViewLayout(): Observable<EntityViewLayout<T>>;
    getWidth(): string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class AverosSearchOperator {
    static readonly OPER_EQ: AverosSearchOperator;
    static readonly OPER_NOT_EQU: AverosSearchOperator;
    static readonly OPER_GREATER_THAN: AverosSearchOperator;
    static readonly OPER_GREATER_THAN_OR_EQUAL: AverosSearchOperator;
    static readonly OPER_LESS_THAN: AverosSearchOperator;
    static readonly OPER_LESS_THAN_OR_EQUAL: AverosSearchOperator;
    static readonly OPER_LIKE: AverosSearchOperator;
    static readonly OPER_NOT_LIKE: AverosSearchOperator;
    static readonly OPER_IN_ELEMENTS: AverosSearchOperator;
    static readonly OPER_NOT_IN_ELEMENTS: AverosSearchOperator;
    static readonly AVEROS_DEFAULT_SEARCH_OPERATIONS: AverosSearchOperator[];
    static readonly AVEROS_DATE_SEARCH_OPERATIONS: AverosSearchOperator[];
    static readonly averosSearchOperatorsMap: Map<string, AverosSearchOperator>;
    static readonly mongoDBdbOperationsSymbols: Map<string, string>;
    static readonly jsonServerOperationsSymbols: Map<string, string>;
    symbol: string;
    name: string;
    description: string;
    translationID?: string;
    constructor(symbol: string, name: string, description: string, translationID?: string);
    getOperationSymbol(dialect: string): string;
    private getMongoDBOperationSymbol;
    private getJSONServerOperationSymbol;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosCriteria {
    entityAccessor: string;
    entityValue: any;
    operator: AverosSearchOperator;
    dmCriteria?: any;
    constructor(entityAccessor?: string, entityValue?: any, operator?: AverosSearchOperator, dmCriteria?: any);
    initialize(): void;
    /**
     * this method is used in order to render the entity value name
     * in a view component while bound to a formController
     */
    toString(): string;
    /**
     * example of a query output :
     *
     * filter={"userName":{"$eq":"Houcem"}, "role":{"$regex":"Admin"}}
     * filter={"userName":{"$nin":["Houcem","houlaw"]}}
     *
     */
    buildAverosSingleHttpQuery(): string;
    /**
     * example of elements output: "value0","value1","value2"
     *
     */
    private extractMultipleValues;
    /**
     * example of a query output :
     *
     * userName=Houcem
     * userName_like=(Houcem|Djo|Lucy)
     *
     *
     *
     */
    buildSingleHttpQuery(dialect: string): string;
    /**
     * example of elements output: value0|value1|value2 (with separator = '|')
     *
     */
    private extractMultipleValuesBySeparator;
    /**
    * example of elements output: suffixvalue0prefix|suffixvalue1prefix|suffixvalue2prefix (with separator = '|')
    *
    */
    private extractMultipleValuesBySeparatorAndSuffixPrefix;
    /**
    * example of elements output: value0|value1|value2 (with separator = '|')
    *
    */
    private extractMultipleValuesForNotEqualMany;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

type HttpParameter = {
    paramKey: string;
    paramValue: string;
};
declare class SearchInputCriteria {
    private searchInputCriteriaMap;
    private requestedFields;
    constructor(formParameters?: any, requestedFields?: Array<string>);
    getCriteriaMap(): Map<string, AverosCriteria | HttpParameter>;
    setCriteriaMap(formParameters: any): void;
    add(criteria: SearchInputCriteria): SearchInputCriteria;
    mergeCriteriaMaps(currentSearchInputCriteriaMap: Map<string, AverosCriteria | HttpParameter>, additionalSearchInputCriteriaMap: Map<string, AverosCriteria | HttpParameter>): Map<string, AverosCriteria | HttpParameter>;
    addHttpCriteriaRecord(key: string, httpParameter: HttpParameter): void;
    addHttpCriteriaRecords(criteriaRecords: {
        key: string;
        httpParameter: HttpParameter;
    }[]): void;
    addHttpQueryParameters(queryParams: {
        key: string;
        value: any;
    }[]): void;
    addHttpQueryParameter(parameterKey: string, parameterValue: any): void;
    toHttpQuery(dialect?: string): string;
    /**
     * example of a query output :
     *
     * filter={"userName":{"$eq":"Houcem"}, "role":{"$regex":"Admin"}}
     *
     */
    private buildAverosHttpQuery;
    /**
     * example of a query output :
     *
     * filter={"userName":{"$eq":"Houcem"}, "role":{"$regex":"Admin"}}
     *
     */
    private buildHttpQuery;
    private getHTTPQueryFromSearchInputCriteria;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare abstract class SearchUseCase<T> {
    abstract trackBy(t: T): any;
    abstract edit(t: T): any;
    abstract delete(t: T): any;
    abstract deleteMany(t: T[]): any;
    abstract reloadData(t: T): any;
    abstract search(event: SearchInputCriteria): any;
    abstract add(t: T): any;
    abstract view(t: T): any;
    abstract viewCompositeObject(compositeObject: {
        value: unknown;
        type: string;
        compositeType?: string;
    }): any;
    getEntityIdentifier(entity: any, entityType: string): {
        idKey: string;
        idValue: any;
    };
    collectionRelationEntitiesCallBack(childEntityClass: any): Function;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum UseCase {
    CREATE = "create",
    UPDATE = "update",
    EDIT = "edit",
    VIEW = "view",
    DELETE = "delete",
    DELETERELATION = "deleteRelation",
    CREATERELATION = "createRelation",
    SEARCH_RESULT_TABLE = "searchResultTable",
    SELECTABLE_SEARCH_RESULT_TABLE = "selectableSearchResultTable",
    SEARCH_INPUT = "searchInput",
    EVENT_ACTION = "eventAction",/// a free use case defined by a set of eventss that trigger related actions
    DISPLAY_SIMPLE_TEXT = "displaySimpleText",/// used with AverosDynamicDialog in order to display a text area field
    DEFAULT = "default"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class UseCaseConfig<T> {
    /**
     *  whether the edit mode is activated by default or not
     *      * true : for Edit & Create use case
     *      * false: for View use case
     */
    /**
     * input field appearance :
     *        * 'outline'  = the field is outlined
     *        * 'standard' = the field is in standard shape
     */
    componentAppearance?: string | 'outline';
    /**
     *  the Input field icon layout :
     *          * 'label' : the icon is stuck to the label
     *          * 'component' the icon is inline with the component input space; either in SUFFIX or in PREFIX
     */
    iconLayout?: string | 'component';
    /**
     * The use case entity holder : could be new instance of the latter in case of Create usecase
     * or it could be an existing entity in case of Edit Use case
     *
     */
    entity?: T;
    /**
     * The underlying entity Class
     *
     */
    entityType?: Type<T> | any;
    /**
     * isRelationView :
     *  true for use cases showing a relation view (either one to one or one to many entity relation ships)
     *  MANDATORY for entity relationship use cases (children)
     */
    isRelationView?: boolean;
    /**
     * asyncRetrieval :
     *  true if the entity value to be displayed is retrieved asynchronously (usually via api).
     * In this case (true) the retrieval method onLoadCallback should be set.
     */
    asyncRetrieval?: boolean;
    /**
     * onSubmitCallback :
     *  asynchronous function to be called in order to submit (update/create) composite entity relation data
     *  MANDATORY for entity relationship use cases (children)
     */
    onSubmitCallback?: Function;
    /**
     * onLoadCallback :
     *  asynchronous function to be called in order to load composite entity relation data
     *  MANDATORY for entity relationship use cases (children)
     */
    onLoadCallback?: Function;
    /**
     * UseCase Type
     *
    */
    useCase?: UseCase;
    /**
     *  Error message related to form validation : This method will return
     *    a customized error message, to be implemented seperately in each use case implementation,
     *    when a form validation is violated.
     */
    getValidationMessage?: (...inputs: any[]) => string;
    /**
     * custom data for custom usecases (like DISPLAY_SIMPLE_TEXT)
     */
    customUseCaseMetaData?: any;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum UseCaseAction {
    ADD = "add",
    DELETE = "delete",
    VIEW = "view",
    EDIT = "edit"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

/**
   * EntityAlteredRelationEventData: is an event emitted when any relation data is updated (deleted/added) within
   * the underlying parent entity while on EDIT/UPDATE/CREATE use cases.
   * The event is composed of the following parameters:
   *  - action: =
   *      * 'DELETE' : in case of delete from relation collection use case
   *      * 'ADD'    : in case of add to relation collection use case
   *  - actionEventData: the data subject to the action event
   *      * itemToBeDeleted: the object to be deleted (itemToBeDeleted._entityId will be used to splice the collection)
   *      * relationName: parent => collection relation name (ex. "roles" as User=>Roles relation): will be used to update the parent entity with the resulting collection
   *  - remainingIdsCollection: a collections of remaining entities Ids after entity Item deletion
   *
   *    {
   *        action: string,
   *        actionEventData: {itemToBeDeleted: any, relationName: string},
   *        remainingIdsCollection: string[]
   *    }
   */
declare class EntityAlteredRelationEventData {
    /**
     * - action: =
     *           'DELETE' : in case of delete from relation collection use case
     *           'ADD'    : in case of add to relation collection use case
     */
    action: UseCaseAction;
    /**
     *  - actionEventData: the data subject to the action event
     *      * itemSubjectToAction: the object to be deleted (itemSubjectToAction._entityId will be used to splice the collection)
     *      * relationName: parent => collection relation name (ex. "roles" as User=>Roles relation):
     *              will be used to update the parent entity with the resulting collection
     *      * formattedIdsSubjectToAction: formatted ids of the entities subject to the action (action in [DELETE, ADD])
     *                                     member of the form: {_entityId: string}[] ex. [{_entityId: "id1"}, {_entityId: "id2"}...]
     */
    actionEventData: {
        itemSubjectToAction: any;
        relationName: string;
        formattedIdsSubjectToAction: any[];
    };
    /**
     * A collections of ids or a simple object id of remaining entity(ies) Id(s) after entity Item modification
     * Mandatory in DELETE/ADD use cases
     */
    resultingItemIdsCollection: any[] | any;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare abstract class CreateViewEditUseCase<T> {
    /**
     * should be implemented in order to handle entity update submission
     * @param t
     */
    abstract onSubmit(t: T): any;
    /**
     * updateRelationCollection shoud be implemented in order to handle all operations (add or delete)
     * related to composite relation of type collection/array
     * @param entityAlteredRelationEventData
     */
    abstract updateRelationCollection(entityAlteredRelationEventData: EntityAlteredRelationEventData): any;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosViewConfig {
    eClass: any;
    useCaseViewLayout: Observable<UseCaseViewLayout<any>>;
    useCaseConfig: UseCaseConfig<any>;
    reactiveForm: FormGroup;
    editMode?: boolean;
    canActivateEditMode: boolean;
    value?: any;
    entityAlteredRelationEventData?: EntityAlteredRelationEventData;
    onSubmitCallback?: Function;
    onLoadCallback?: Function;
    onLoadWithCriteria?: {
        callBackCriteria: SearchInputCriteria;
        callBack: Function;
    };
    additionalProperties?: {};
    formStructureChanged$?: Observable<FormGroup>;
    viewLayoutChanged$?: Observable<UseCaseViewLayout<any>>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class EntityMetaData {
    /**
     * the value of the entity
     */
    value: any;
    /**
     * the type of the entity as defined in fieldViewLayout.typeName
     *
     */
    type: string;
    /**
     * Depicts the first level navigation key from the parent entity as defined in fieldViewLayout.entityFieldName
     * The key represents the composite relation between a parent and a child entities
     */
    compositeEntityNavigationKey?: string;
    /**
     * -    null for simple and simple composite fields
     * -    not null for collections and defines the type of the collection as defined fieldViewLayout.type
     */
    compositeType?: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosDialogViewConfig {
    objectClass: any;
    compositeObject: EntityMetaData;
    onSubmitCallback?: Function;
    onLoadCallback?: Function;
    onLoadWithCriteriaCallback?: Function;
    callBackCriteria?: SearchInputCriteria;
    viewLayout: {
        useCase: UseCase | undefined;
        editMode?: boolean;
        canActivateEditMode?: boolean;
        componentAppearance?: string;
        iconLayout?: string;
    };
}

declare class LoggerService {
    private readonly averosConfig;
    private logLevel;
    private debug;
    constructor();
    /**
     * Generates a formatted timestamp string (e.g., '2025-12-09 16:44:29.875').
     */
    private getTimestamp;
    /**
       * Shared Method to log messages if debug is true.
       * @param source The name of the class or module originating the log (e.g., 'AverosAuth').
       * @param level The log level (LogLevel enum) for this specific message.
       * @param args The data/messages to log.
       *
       * USAGE: this.logger.log('AuthComponent', LogLevel.INFO, 'Login attempt started for user.');
       */
    log(source: string, level: LogLevel, ...args: any[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoggerService>;
}

declare class ViewEventHandlerService {
    private appSharedService;
    constructor(appSharedService: ApplicationSharedService);
    handleEvent(eventAction: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewEventHandlerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewEventHandlerService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * Averos Authentication & Authorization now follows
 * the Industry Standard: The "Bring Your Own Auth" (BYOA) Pattern
 */
/**
 * @file averos-auth.service.ts
 * @description Core authentication service for Averos library.
 * Acts as facade between library components and auth provider implementation.
 * Manages auth state using Angular Signals for optimal reactivity, decoupling consumers from the provider.
 */

/**
 * Provider information for UI rendering
 */
interface ProviderInfo {
    /** Provider name/identifier */
    name: string;
    /** Display metadata */
    metadata: AverosAuthProviderMetadata;
    /** Whether this is the default provider */
    isDefault: boolean;
    /** Provider-specific configuration */
    config?: any;
}
declare class AverosAuthService {
    private router;
    private logger;
    private alertService;
    private viewEventHandlerService;
    /**
     * default local storage key where the acive provider id is stored
     */
    private readonly PROVIDER_STORAGE_KEY;
    private _initPromise;
    private readonly registry;
    private readonly injector;
    private readonly applicationSharedService;
    private readonly averosConfig;
    private readonly singleRegToken;
    private readonly multiRegToken;
    private _activeProvider;
    private providerSubscription;
    private readonly configArgs;
    private config;
    /**
       * Indicates if the current provider fully manages its own token validation
       * (e.g., maintains refresh logic, validates against remote server...)
       */
    private isSelfManaged;
    /** Internal mutable user state */
    private readonly _user;
    /** Internal loading state */
    private readonly _isLoading;
    /** Internal initialization state */
    private readonly _isInitialized;
    /** Internal error state */
    private readonly _lastError;
    /** Current authenticated user (null if not authenticated) */
    readonly user: Signal<AuthUser | null>;
    isAuthenticated(): boolean;
    readonly userPicture: Signal<string>;
    readonly userDisplayName: Signal<string>;
    /** Whether auth operations are in progress */
    readonly isLoading: Signal<boolean>;
    /** Whether the auth service has been initialized */
    readonly isInitialized: Signal<boolean>;
    /** User's roles (empty array if not authenticated) */
    readonly userRoles: Signal<any[]>;
    /** User's permissions (empty array if not authenticated) */
    readonly userPermissions: Signal<string[]>;
    /** Last authentication error */
    readonly lastError: Signal<AuthError | null>;
    /** Observable stream of user state changes */
    readonly user$: Observable<AuthUser<Record<string, any>>>;
    /** Subject for authentication errors */
    private readonly _authError$;
    /** Observable stream of authentication errors */
    readonly authError$: Observable<AuthError>;
    constructor(router: Router, logger: LoggerService, alertService: AlertService, viewEventHandlerService: ViewEventHandlerService);
    /**
      * Initialize the authentication service.
      * Should be called during app bootstrap (APP_INITIALIZER).
      * Checks for existing sessions, validates tokens, etc.
      * @param config Optional configuration
      * @returns Promise resolving when initialization is complete
      */
    initialize(runtimeConfig?: AuthProviderConfig & AverosAuthConfig): Promise<void>;
    private doInitialize;
    /**
    * Central function to retrieve the complete configuration for the active provider.
    */
    private getProviderConfiguration;
    getProviderRegisteredName(provider: AverosAuthProvider): string | null;
    /**
     * Switch to a different auth provider at runtime
     * @param providerName Name of the registered provider
     */
    switchProvider(providerName?: string): Promise<void>;
    private loadProviderInstance;
    /**
     * Persist ONLY the active provider name (lightweight)
     * This is separate from user state persistence
     */
    private persistActiveProvider;
    /**
     * Restore the active provider name from storage
     * This works independently of user state persistence
     */
    private restoreActiveProvider;
    /**
     * Clear persisted provider name
     */
    private clearActiveProvider;
    /**
    * Initiate login flow.
    * @param credentials Provider-specific credentials
    * @returns Promise resolving to authenticated user
    * @throws AuthError on failure
    */
    login(credentials?: any): Promise<AuthUser | null>;
    /**
    * Initiate logout flow.
    * * @returns Promise resolving when logout is complete
    */
    logout(): Promise<void>;
    /**
    * Refresh authentication token.
    * Called automatically by HTTP interceptor on 401 responses.
    * * @returns Promise resolving to updated user
    * @throws AuthError if refresh fails
    */
    refreshToken(): Promise<AuthUser | null>;
    /**
      * Get current access token.
      * Used by HTTP interceptor to attach to requests.
      * * @returns Current token or null
      */
    getToken(): string | null;
    /**
      * Check if current session is valid.
      * * @returns Promise resolving to true if session is valid
      */
    isSessionValid(): Promise<boolean>;
    /**
      * Get token expiration time.
      * * @returns ISO 8601 timestamp or null
      */
    getTokenExpiration(): string | null;
    /**
      * Check if user's token is still valid (not expired).
      * Client-side check based on expiresAt.
      */
    private isTokenValid;
    private checkExplicitExpiration;
    private checkLifetimeExpiration;
    /**
      * Check if user has specific role(s).
      * @param role Single role or array of roles
      * @param requireAll If true, must have ALL roles; if false, must have ANY
      * @returns true if user has required role(s)
      */
    hasRole(role: string | string[], requireAll?: boolean): boolean;
    /**
      * Convenience method: Check if user has ANY of the specified roles.
      */
    hasAnyRole(roles: string[]): boolean;
    /**
      * Convenience method: Check if user has ALL of the specified roles.
      */
    hasAllRoles(roles: string[]): boolean;
    /**
      * Check if user has specific permission(s).
      * @param permission Single permission or array of permissions
      * @param requireAll If true, must have ALL permissions; if false, must have ANY
      * @returns true if user has required permission(s)
      */
    hasPermission(permission: string | string[], requireAll?: boolean): boolean;
    /**
      * Convenience method: Check if user has ANY of the specified permissions.
      */
    hasAnyPermission(permissions: string[]): boolean;
    hasAllPermissions(permissions: string[]): boolean;
    /**
   * Check if user can access a specific resource with an optional action.
   * Delegates to the active auth provider for custom access control logic.
   *
   * This is useful for fine-grained authorization beyond simple role/permission checks:
   * - Resource ownership (e.g., can only edit own posts)
   * - Contextual permissions (e.g., can approve if user is manager in same department)
   * - Dynamic policy evaluation (e.g., ABAC - Attribute-Based Access Control)
   *
   * @param resource The resource identifier (e.g., 'posts', 'users', 'documents')
   * @param action Optional action (e.g., 'read', 'write', 'delete', 'approve')
   * @returns true if user can access the resource for the given action
   *
   * @example
   * // Check if user can write to posts
   * if (authService.canAccess('posts', 'write')) {
   *   // Show edit button
   * }
   *
   * @example
   * // Check if user can access admin panel (no specific action)
   * if (authService.canAccess('admin')) {
   *   // Show admin menu
   * }
   */
    canAccess(resource: string, action?: string): boolean;
    private validateProviderAvailability;
    private setupPersistenceEffect;
    private setupProviderListeners;
    /**
      * Update internal auth state.
      * Called when user logs in, logs out, or token refreshes.
      */
    private updateState;
    /**
      * Handle authentication errors.
      */
    private handleError;
    /**
      * Normalize any error into AuthError format.
      */
    private normalizeError;
    /**
      * Type guard for AuthError.
      */
    private isAuthError;
    /**
     * Persist user state to localStorage (ONLY if persistState is enabled)
     */
    private persistState;
    /**
     * Restore user state from localStorage (ONLY if persistState is enabled)
     */
    private restorePersistedState;
    /**
      * Clear persisted state from localStorage.
      */
    private clearPersistedState;
    private get currentProvider();
    /**
     * Update a specific field in the current user's auth token.
     * Updates both the in-memory state and persisted storage.
     *
     * @param key The field to update (e.g., 'picture', 'displayName')
     * @param value The new value for the field
     */
    updateUserField(key: string, value: any): void;
    /**
     * Check if the current user's email is verified.
     * Used by guards and components to enforce email verification.
     */
    isEmailVerified(): boolean;
    /**
     * Get the current user's roles as an Observable.
     * Provided for backward compatibility with old guards.
     */
    getLoggedUsersRoles(): Observable<string[]>;
    /**
     * Get currently active provider name from providers registry
     */
    getActiveProviderFromRegistry(): string | null;
    /**
     * Get currently active provider name
     * check storage ==> currenProvider ==> registry
     */
    getActiveProvider(): string | null;
    /**
   * Standardizes an array of strings (e.g., roles or permissions)
   * by trimming whitespace and converting to lowercase.
   */
    private normalizeAuthItems;
    /**
     * Get all available provider names from configuration
     * @returns Array of provider names
     */
    getAvailableProviders(): string[];
    /**
     * Get detailed information about all available providers
     * @returns Array of provider information with metadata
     */
    getAvailableProvidersInfo(): ProviderInfo[];
    /**
     * Get providers that use credentials flow (username/password)
     * @returns Array of credentials-based provider names
     */
    getCredentialsProviders(): string[];
    /**
     * Get providers that use delegated flow (OAuth/SSO)
     * @returns Array of delegated authentication provider names
     */
    getDelegatedProviders(): string[];
    /**
     * Get detailed info for delegated providers (for rendering social buttons)
     * @returns Array of provider information for delegated auth
     */
    getDelegatedProvidersInfo(): ProviderInfo[];
    /**
     * Check if any provider uses credentials flow
     * @returns True if at least one provider supports username/password
     */
    hasCredentialsProvider(): boolean;
    /**
     * Check if any provider uses delegated flow
     * @returns True if at least one provider supports OAuth/SSO
     */
    hasDelegatedProvider(): boolean;
    /**
     * Get the default provider name
     * @returns The name of the default provider
     */
    getDefaultAuthProvider(): string;
    /**
     * Check if a specific provider is available
     * @param providerName Name of the provider to check
     * @returns True if provider is configured
     */
    isProviderAvailable(providerName: string): boolean;
    /**
     * Get metadata for a specific provider
     * @param providerName Name of the provider
     * @returns Provider metadata or undefined
     */
    getProviderMetadata(providerName: string): AverosAuthProviderMetadata | undefined;
    /**
     * Extract provider name from provider instance
     */
    /**
     * Get default metadata for unknown providers
     */
    private getDefaultMetadata;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AverosAuthService>;
}

declare class ApplicationMenuService {
    private http;
    private averosAuth;
    private logger;
    private sideMenu$;
    private topMenu$;
    constructor(http: HttpClient, averosAuth: AverosAuthService, logger: LoggerService);
    getSideMenu(): Observable<ApplicationNavigationItem[]>;
    getTopMenu(): Observable<ApplicationNavigationItem[]>;
    setSideMenu(menu: ApplicationNavigationItem[]): Observable<ApplicationNavigationItem[]>;
    setTopMenu(menu: ApplicationNavigationItem[]): Observable<ApplicationNavigationItem[]>;
    addSideMenu(menu: ApplicationNavigationItem): void;
    addTopMenu(menu: ApplicationNavigationItem): void;
    resetAllMenus(): void;
    resetSideMenu(): void;
    resetTopMenu(): void;
    /** Menu for translation */
    recursMenuForTranslation(menu: ApplicationNavigationItem[] | ApplicationNavigationItem[], namespace: string): void;
    loadMenu(): Promise<any>;
    loadDefaultMenu(): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ApplicationMenuService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ApplicationMenuService>;
}

declare class ResourceLoaderService {
    private iconRegistry;
    private sanitizer;
    private http;
    private applicationSharedService;
    private rawSvgs;
    private iconThemes;
    private resourceLoaded;
    private themeReady;
    private defaultTheme;
    private iconMetadata;
    private readonly logger;
    constructor(iconRegistry: MatIconRegistry, sanitizer: DomSanitizer, http: HttpClient, applicationSharedService: ApplicationSharedService);
    /**
     * Initializes icon theme from a central icons.json file.
     * Loads and registers theme-based icons from URL and caches inline SVG content.
     * Supports fallback and theme-specific overrides.
     *
     * JSON structure (under basePath/icons.json):
     * {
     *   "themes": ["theme1", "theme2"],
     *   "icons": ["nav/up", "user/add"],
     *   "customIcons": {
     *     "theme1": ["user1/favorite", "custom/profile"]
     *   }
     * }
     */
    initializeIcons(basePath?: string): Promise<void>;
    private initializeIconsTheme;
    /**
     * Fetches and parses the icons.json metadata file
     */
    private loadIconsMetadata;
    getAllIconThemes(): string[];
    private registerIconFromUrls;
    /**
     * Loads raw SVG content into memory for [innerHTML] use
     */
    private loadInlineSvgContent;
    /**
     * Returns raw SVG content by fully qualified name (e.g., theme:nav/up)
     */
    getInlineSvg(fullName: string): string | undefined;
    /**
     * Checks if an icon is registered in a specific theme
     */
    iconExists(theme: string, name: string): boolean;
    /**
     * Returns the name of the default fallback theme
     */
    getDefaultTheme(): string;
    /**
   * Removes a specific icon from the registry for a given theme.
   * This does not unregister it from MatIconRegistry but will exclude it from future checks or inline access.
   *
   * @param theme - The theme from which to remove the icon (e.g., 'outlined')
   * @param name - The name of the icon (e.g., 'nav/up')
   */
    removeIconFromRegistry(theme: string, name: string): void;
    getICONRegistry(): MatIconRegistry;
    isThemeReady(theme: string): Observable<boolean>;
    private markThemeReady;
    static ɵfac: i0.ɵɵFactoryDeclaration<ResourceLoaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ResourceLoaderService>;
}

declare class DataExporterService<T> {
    fileType: string;
    fileExtension: string;
    constructor();
    /**
     *
     * @description exports data object(s) | or current DOM document to the target format
     */
    exportData(data: T[] | Document, format: string, fileName: string): void;
    exportDataToPDF(data: T[] | Document, fileName: string): void;
    exportDataToText(data: T[] | Document, fileName: string): void;
    exportDataToCSV(data: T[] | Document, fileName: string): void;
    exportDataToExcel(data: T[] | Document, fileName: string): void;
    /**
     * @description Save the exported file to the external disk
     */
    private saveFile;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataExporterService<any>, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DataExporterService<any>>;
}

declare class GlobalCustomValidationService {
    static validators: {
        name: string;
    }[];
    constructor();
    /**
     * password pattern validator
     * validatorID = patternValidator
     * validatorKey = invalidPassword
     */
    patternValidator(): ValidatorFn;
    /**
   * Regular Expression based pattern validator
   * validatorID = regExpPatternValidator
   * validatorKey = invalidPattern
   */
    regExpPatternValidator(regExpression: string): ValidatorFn;
    /**
     * birth date validator : < 18
     * validatorID = birthDateValidator
     * validatorKey = invalidBirthDate_under18
     */
    birthDateValidator(): ValidatorFn;
    under18Year(birthdate: any): boolean;
    /**
     * Intra-Validator : check wether two components has the same password value or not
     * validatorID = matchPassword
     * validatorKey = passwordMismatch
     */
    matchPassword(password: string, confirmPassword: string): (formGroup: FormGroup) => AbstractControl;
    findInvalidControls(form: FormGroup): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<GlobalCustomValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GlobalCustomValidationService>;
}

declare class FormControlService {
    private globalCustomValidationService;
    constructor(globalCustomValidationService: GlobalCustomValidationService);
    buildUseCaseForm(useCaseViewLayout: UseCaseViewLayout<any>): FormGroup;
    buildUseCaseFormFromEntityType(type: any, useCase: UseCase, entityValue?: any): FormGroup;
    getValidationMessage(form: FormGroup, fieldKey: string, fieldValidator?: FieldValidator): string;
    private buildFormGroup;
    private buildValidators;
    private isnull;
    private composeSyncValidators;
    private composeAsyncValidators;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormControlService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class ExternalKeysMapping {
    targetServices: string[];
    keysMapping: Record<string, string>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class PaginatedData<T> {
    /**
     * The total number of element that responds to the query
     */
    totalCount: number;
    /**
     * The index of the current retrieved page
     */
    currentPageIndex: number;
    /**
     * The current retrieved page size (number of elements per page)
     */
    pageSize: number;
    /**
     * The total number of pages
     */
    totalPages?: number;
    /**
     * The actual retrieved data in the current page. Data size should be <= pageSize
     */
    data: T[];
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

type EntityClassLookupMetadata = {
    className: string;
    classImplementation: any;
};
declare class EntityConfigurationManagerService {
    private http;
    private applicationCommonService;
    private logger;
    entityClassLookup: Array<EntityClassLookupMetadata>;
    constructor(http: HttpClient, applicationCommonService: ApplicationSharedService, logger: LoggerService);
    registerEntityClassLookup<T>(type: T): void;
    getEntityClassImplementation(className: string): any;
    loadEntityConfiguration(): Promise<any>;
    /**
   * Retrieves all key mappings for a specified entity across all services.
   *
   * This method aggregates the key mappings associated with the provided
   * `entityName` from all available services, returning them as an array
   * of `EntityKeyMapping` objects. Each mapping contains details about
   * how the entity's keys are represented or mapped within different
   * contexts or systems.
   *
   * @param entityName - The name of the entity for which key mappings are to be retrieved.
   * @returns An array of `EntityKeyMapping` objects representing the key mappings
   *          for the specified entity across all services.
   */
    getEntityExternalKeysMappings(entityName: string): ExternalKeysMapping[];
    getEntityExternalKeysMapping(entityName: string, serviceName: string): ExternalKeysMapping;
    mapToExternalEntity<T>(internalEntity: T, entityName: string, serviceName: string, keepKeys?: boolean): T;
    mapToInternalEntity<T>(externalEntity: T, entityName: string, serviceName: string, keepKeys?: boolean): T;
    mapToExternalEntityCollection<T>(internalEntityCollection: T[], entityName: string, serviceName: string, keepKeys?: boolean): T[];
    mapToInternalEntityCollection<T>(resultedData: T[] | PaginatedData<T>, entityName: string, serviceName: string, keepKeys?: boolean): T[] | PaginatedData<T>;
    getAPICollectionFieldMapping(paginatedDataKey: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EntityConfigurationManagerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EntityConfigurationManagerService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class ViewLayoutService {
    private http;
    private formControlService;
    private entityConfigurationManagerService;
    private logger;
    private registeredEntities;
    constructor(http: HttpClient, formControlService: FormControlService, entityConfigurationManagerService: EntityConfigurationManagerService, logger: LoggerService);
    registerEntity(type: any): void;
    initializeEntitiesViewLayouts(): Promise<any>;
    registerEntitiesViewLayouts(entities: Array<any>): Promise<any>;
    getEntityViewLayout(type: any): Observable<EntityViewLayout<typeof type>>;
    getUseCaseViewLayout(type: any, useCase: UseCase): Observable<UseCaseViewLayout<typeof type>>;
    /**
     * Build a single Entity ViewLayout
     */
    buildEntityViewLayout(type: any): Promise<any>;
    /**
 * returns an Observable UseCaseViewLayout
 */
    getEntityUseCaseViewLayout(type: any, useCase: UseCase): Observable<UseCaseViewLayout<typeof type>>;
    buildAverosDialogViewConfig(entityMetaDataViewConfig: AverosDialogViewConfig): AverosViewConfig;
    loadViewLayout(type: any, viewLayoutFile: string): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewLayoutService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ViewLayoutService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum EnvironmentConfigurationType {
    SERVICE = "service",
    GATEWAY = "gateway",
    HTTP_CONFIG = "http_config",
    RESOURCE = "resource",
    RUNTIME = "runtime"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare abstract class EnvironmentConfigurationItem {
    id: string;
    type: EnvironmentConfigurationType;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class EnvironmentConfiguration {
    configurationItems: EnvironmentConfigurationItem[];
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class EnvironmentConfigurator {
    static readonly envConfig: EnvironmentConfigurator;
    private environmentConfiguration;
    private constructor();
    protected static getInstance(): EnvironmentConfigurator;
    setEnvironmentConfiguration(environmentConfiguration: EnvironmentConfiguration): void;
    getEnvironmentConfiguration(): EnvironmentConfiguration;
    resetEnvironmentConfiguration(): void;
    addConfigurationItem(environmentConfigurationItem: EnvironmentConfigurationItem, configType?: string): void;
    getConfigurationItem(id: string, configType?: EnvironmentConfigurationType): EnvironmentConfigurationItem;
    private getConfigItem;
    replaceConfigurationItem(environmentConfigurationItem: EnvironmentConfigurationItem): void;
    removeConfigurationItem(key: string | EnvironmentConfigurationItem): void;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class ServiceConfigurationItem extends EnvironmentConfigurationItem {
    type: EnvironmentConfigurationType;
    apiHost: string;
    apiPort: number;
    apiProtocol: string;
    apiEndPoint: string;
    /**
     * If apiHTTPQueryBuilder is defined then the http query will be built following the target structure as defined in the parameter value
     * ex: regular / json-server / mongodb / custom
     *
     * If no service related apiHTTPQueryBuilder is defined then the default HTTP Query Buider (MONGODB) is applied
    **/
    apiHTTPQueryBuilder?: string;
    /**
     * `externalEntityId` is the entity identifier that external managing service/api (ex. api, database...)
     * uses to identify and manage the entity
     */
    externalEntityId?: string;
    /**
     * If apiProxy===true then a service mesh or load balancer are targeted instead:
     * - only the target api host and port are used to construct the related apiURL (http(s)://host:port)
     * - the apiEndPoint will be used to route the api call
     *
    **/
    apiProxy?: boolean;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosConfig implements FrameworkConfiguration {
    /**
     * Defines the supported languages
     *
     */
    supportedLanguages?: string[];
    /**
     * Enables authentication feature
     * @default false
     */
    enableAuthentication?: boolean;
    /**
     * Enables external entity mapping
     * @default false
     */
    enableExternalEntityMapping?: boolean;
    /**
     * Enable debug logging.
     * Logs all authentication operations to console.
     * @default false
     */
    debug?: boolean;
    /**
     * Selects Logging Level when debug is true.
     *
     * @default INFO
     */
    logLevel?: string | LogLevel;
    authProvidersConfig?: AverosAuthProviderConfig;
    /**
     * HTTP authentication interceptor configuration
     */
    httpAuthConfig?: HttpAuthConfig;
    constructor(avConfig?: FrameworkConfiguration);
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare type ApiRecordMetaData = {
    apiServer: string;
    apiURI: string;
    apiQueryBuilder: string;
    externalEntityId: string;
};
declare class EnvironmentConfiguratorService {
    private http;
    private readonly averosConfig;
    private logger;
    private apiRegistry;
    constructor(http: HttpClient);
    loadEnvironmentConfiguration(): Promise<any>;
    debugAverosConfig(averosConfig: AverosConfig): void;
    getEnvironmentConfigurator(): EnvironmentConfigurator;
    getApiHTTPQueryBuilder(serviceConfigurationItem: ServiceConfigurationItem | string): string;
    getExternalApiIdentifier(serviceConfigurationItem: ServiceConfigurationItem | string): string;
    getExternalApiIdentifierForCompositeChildEntity<T>(parentEntity: T, compositeMemberRelationPath: string): string;
    getApiRoute(serviceConfigurationItem: ServiceConfigurationItem | string, actionUri?: string): string;
    registerApiMetaData(apiKey: string, apiServer: string, apiURI: string, apiQueryBuilder: string, externalEntityId: string): ApiRecordMetaData;
    retrieveApiMetaData(apiKey: string): ApiRecordMetaData;
    getApiGatewayRoute(apiID: string, actionUri?: string): string;
    getGatewayApiHTTPQueryBuilder(apiID: string): string;
    getGatewayExternalApiID(apiID: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EnvironmentConfiguratorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EnvironmentConfiguratorService>;
}

declare class FileService {
    private alertService;
    constructor(alertService: AlertService);
    exportTextToFile(dataToExport: string, fileName: string, extension: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
interface ProfileLanguage {
    code: string;
    icon: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosApplicationComponent implements OnDestroy, OnInit {
    private authenticationService;
    private appSharedService;
    private overlayContainer;
    private document;
    private router;
    private readonly averosConfig;
    activateAverosSettingsWidget: boolean;
    activateGlobalSearchWidget: boolean;
    activateDefaultGitWidget: boolean;
    activateAverosDesigner: boolean;
    protected enableAuthentication: boolean;
    currentUserProfile: AuthUser;
    supportedLanguages: Observable<ProfileLanguage[]>;
    authSubscription: Subscription;
    onOpenDesignerSubscription: Subscription;
    routerSubscription: Subscription;
    openDesigner: boolean;
    get darkThemeActivated(): boolean;
    constructor(authenticationService: AverosAuthService, appSharedService: ApplicationSharedService, overlayContainer: OverlayContainer, document: any, router: Router);
    initializeAverosApplication(averosConfig: AverosConfig): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    get authService(): AverosAuthService;
    designerEventHandler(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosApplicationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosApplicationComponent, "averos-application", never, { "activateAverosSettingsWidget": { "alias": "activateAverosSettingsWidget"; "required": false; }; "activateGlobalSearchWidget": { "alias": "activateGlobalSearchWidget"; "required": false; }; "activateDefaultGitWidget": { "alias": "activateDefaultGitWidget"; "required": false; }; "activateAverosDesigner": { "alias": "activateAverosDesigner"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MaterialModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MaterialModule, never, [typeof i1.LayoutModule, typeof i2.A11yModule, typeof i3.ClipboardModule, typeof i4.CdkStepperModule, typeof i5.CdkTableModule, typeof i6.CdkTreeModule, typeof i7.CdkMenuModule, typeof i8.DragDropModule, typeof i9.MatAutocompleteModule, typeof i10.MatBadgeModule, typeof i11.MatBottomSheetModule, typeof i12.MatButtonModule, typeof i13.MatButtonToggleModule, typeof i14.MatCardModule, typeof i15.MatCheckboxModule, typeof i16.MatChipsModule, typeof i17.MatStepperModule, typeof i18.MatDatepickerModule, typeof i19.MatDialogModule, typeof i20.MatDividerModule, typeof i21.MatExpansionModule, typeof i22.MatGridListModule, typeof i23.MatIconModule, typeof i24.MatInputModule, typeof i25.MatListModule, typeof i26.MatMenuModule, typeof i27.MatNativeDateModule, typeof i28.MatPaginatorModule, typeof i29.MatProgressBarModule, typeof i30.MatProgressSpinnerModule, typeof i31.MatRadioModule, typeof i27.MatRippleModule, typeof i32.MatSelectModule, typeof i33.MatSidenavModule, typeof i34.MatSliderModule, typeof i35.MatSlideToggleModule, typeof i36.MatSnackBarModule, typeof i37.MatSortModule, typeof i38.MatTableModule, typeof i39.MatTabsModule, typeof i40.MatToolbarModule, typeof i41.MatTooltipModule, typeof i42.MatTreeModule, typeof i43.PortalModule, typeof i44.ScrollingModule, typeof i45.MatFormFieldModule], [typeof i1.LayoutModule, typeof i2.A11yModule, typeof i3.ClipboardModule, typeof i4.CdkStepperModule, typeof i5.CdkTableModule, typeof i6.CdkTreeModule, typeof i7.CdkMenuModule, typeof i8.DragDropModule, typeof i9.MatAutocompleteModule, typeof i10.MatBadgeModule, typeof i11.MatBottomSheetModule, typeof i12.MatButtonModule, typeof i13.MatButtonToggleModule, typeof i14.MatCardModule, typeof i15.MatCheckboxModule, typeof i16.MatChipsModule, typeof i17.MatStepperModule, typeof i18.MatDatepickerModule, typeof i19.MatDialogModule, typeof i20.MatDividerModule, typeof i21.MatExpansionModule, typeof i22.MatGridListModule, typeof i23.MatIconModule, typeof i24.MatInputModule, typeof i25.MatListModule, typeof i26.MatMenuModule, typeof i27.MatNativeDateModule, typeof i28.MatPaginatorModule, typeof i29.MatProgressBarModule, typeof i30.MatProgressSpinnerModule, typeof i31.MatRadioModule, typeof i27.MatRippleModule, typeof i32.MatSelectModule, typeof i33.MatSidenavModule, typeof i34.MatSliderModule, typeof i35.MatSlideToggleModule, typeof i36.MatSnackBarModule, typeof i37.MatSortModule, typeof i38.MatTableModule, typeof i39.MatTabsModule, typeof i40.MatToolbarModule, typeof i41.MatTooltipModule, typeof i42.MatTreeModule, typeof i43.PortalModule, typeof i44.ScrollingModule, typeof i45.MatFormFieldModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MaterialModule>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class MaterialElevationDirective implements OnChanges {
    private element;
    private renderer;
    defaultElevation: number;
    raisedElevation: number;
    constructor(element: ElementRef, renderer: Renderer2);
    onPointerEnter(): void;
    onPointerLeave(): void;
    ngOnChanges(changes: SimpleChanges): void;
    setElevation(oldClazz: number, newClazz: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MaterialElevationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MaterialElevationDirective, "[averosMaterialElevation]", never, { "defaultElevation": { "alias": "defaultElevation"; "required": false; }; "raisedElevation": { "alias": "raisedElevation"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AccordionLinkDirective implements OnInit, OnDestroy {
    group: any;
    protected oPEN: boolean;
    protected nav: AccordionDirective;
    get open(): boolean;
    set open(value: boolean);
    constructor(nav: AccordionDirective);
    ngOnInit(): any;
    ngOnDestroy(): any;
    toggle(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionLinkDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AccordionLinkDirective, "[averosAccordionLink]", never, { "group": { "alias": "group"; "required": false; }; "open": { "alias": "open"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AccordionDirective implements AfterContentChecked {
    private router;
    protected navlinks: Array<AccordionLinkDirective>;
    constructor(router: Router);
    ngAfterContentChecked(): void;
    addLink(link: AccordionLinkDirective): void;
    closeOtherLinks(openLink: AccordionLinkDirective): void;
    removeGroup(link: AccordionLinkDirective): void;
    checkOpenLinks(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AccordionDirective, "[averosAccordion]", never, {}, {}, never, never, false, never>;
}

declare class AccordionAnchorDirective {
    protected navlink: AccordionLinkDirective;
    constructor(navlink: AccordionLinkDirective);
    onClick(e: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccordionAnchorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AccordionAnchorDirective, "[averosAccordionAnchor]", never, {}, {}, never, never, false, never>;
}

declare class DataExportDirective {
    private dataExporterService;
    data: any[];
    fileName: string;
    format: string;
    constructor(dataExporterService: DataExporterService<any>);
    onClick($event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataExportDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DataExportDirective, "[averosDataExport]", never, { "data": { "alias": "averosDataExport"; "required": false; }; "fileName": { "alias": "fileName"; "required": false; }; "format": { "alias": "format"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * Directive: SafeIconDirective
 *
 * This directive ensures safe and reliable loading of SVG icons using Angular Material's MatIcon component.
 * It handles dynamic icon registration based on the currently selected theme, and gracefully falls back to a
 * default icon theme if an icon is missing from the active one. This guarantees that icons are always displayed
 * (if available) and avoids broken icons in the UI.
 *
 * Core Responsibilities:
 * - Dynamically assign themed SVG icons using [svgIcon] binding.
 * - Check if the icon exists in the current theme or fallback theme.
 * - Apply visibility rules: hide the element if no icon is found, or show it once the icon is resolved.
 * - Subscribe to icon theme changes and update the rendered icon reactively.
 *
 * Usage:
 * ```html
 * <mat-icon [safeIcon]="'edit'"></mat-icon>
 * ```
 *
 * Dependencies:
 * - ResourceLoaderService: Provides icon metadata and readiness state per theme.
 * - ApplicationSharedService: Provides the current icon theme via an observable.
 * - MatIcon: Angular Material's icon component for SVG rendering.
 *
 * Notes:
 * - The directive waits for both the current and fallback themes to be fully loaded before rendering.
 * - DOM visibility is fully controlled within the subscription logic to prevent UI flickering.
 * - Designed to work seamlessly with OnPush change detection strategy.
 *
 * @example
 * <mat-icon [safeIcon]="'delete'"></mat-icon>
 *
 * @author
 * Houssem LAOUITI
 */

declare class SafeIconDirective implements OnInit, OnDestroy {
    private matIcon;
    private icons;
    private appShared;
    private elRef;
    private logger;
    private _iconName;
    set iconName(value: string);
    get iconName(): string;
    private sub?;
    private fallbackDefaultTheme;
    constructor(matIcon: MatIcon, icons: ResourceLoaderService, appShared: ApplicationSharedService, elRef: ElementRef<HTMLElement>, logger: LoggerService);
    ngOnInit(): void;
    updateIcon(theme?: string): void;
    private trySetSvgIcon;
    private shouldFallbackToNotFound;
    private renderNotFoundIcon;
    private resetVisibility;
    private clearFallbackStyling;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SafeIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SafeIconDirective, "[safeIcon]", never, { "iconName": { "alias": "safeIcon"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class SortCollectionByPipe implements PipeTransform {
    /**
     * Sorts an array based on the value orders of a field:
     *  # order : 'asc', 'desc'
     *  # field : a collection entity member
     */
    transform(collection: any[], order?: string, field?: string): any[] | any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SortCollectionByPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SortCollectionByPipe, "sortCollectionBy", false>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class ToObservablePipe implements PipeTransform {
    transform(value: unknown, ...args: unknown[]): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToObservablePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ToObservablePipe, "toObservable", false>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

type SimpleGroupedViewLayout = {
    group: GroupedFieldViewLayout;
    groupedFieldsLayout: FieldViewLayout[];
    isCompositeField?: boolean;
    /**
     * the layout to be applied to the composite field:
     *  * inline : the field and sub fields are displayed in a dedicated group within the same parent view
     *  * tabbed: fits mainly to relations. The target relation entity is displayed in a tab
     *  * newpage: fits mainly to 'composite' and 'iterable'field type.
     *              The field/relation/entities are displayed in a seperate page / component.
     *              (ex. a new component with a grid container for iterable field)
     *
     */
    compositeFieldLayout?: string;
    compositeFieldType?: string;
};
type TransformedSimpleViewLayoutGroup = SimpleGroupedViewLayout[];
declare class ToViewLayoutPipe implements PipeTransform {
    transform(viewLayout: Observable<FieldViewLayout[]>, ...args: unknown[]): Observable<TransformedSimpleViewLayoutGroup>;
    /**
     *
     * @param fieldViewLayoutItem
     * @returns either an aggregation/composition relation (0|1)->(0|1) OneToOne or not
     */
    isCompositeField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    /**
    * Either a collection relation (0|1)->n or an aggregation/composition (0|1)->(0|1)
    */
    isCompositeRelationField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    inlineViewCompositeField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    /**
     * Either a collection relation (0|1) -> n or not
     */
    isIterableField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    /**
     * Either a relationship navigation key is composite or not :
     * - composite navigationKey = compositeEntity.field1 / f1.f2.f3
     * - simple navigationKey = "field1"
     */
    isCompositeNavigationKey: (entityFieldName: string) => boolean;
    groupByGroupID: (transformedViewLayout: TransformedSimpleViewLayoutGroup, fieldViewLayoutItem: FieldViewLayout) => TransformedSimpleViewLayoutGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToViewLayoutPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ToViewLayoutPipe, "toViewLayout", false>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

type TabbedViewLayout = {
    transformedViewLayout: TransformedSimpleViewLayoutGroup;
    tabIndex: number;
};
type TransformedTabbedViewLayout = TabbedViewLayout[];
declare class ToTabbedViewLayoutPipe implements PipeTransform {
    transform(viewLayout: Observable<FieldViewLayout[]>, ...args: unknown[]): Observable<TransformedSimpleViewLayoutGroup>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToTabbedViewLayoutPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ToTabbedViewLayoutPipe, "toTabbedViewLayout", false>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

type CompositeViewLayoutGroup = {
    transformedViewLayoutGroup: TransformedSimpleViewLayoutGroup;
    order: number;
    isParent?: boolean;
    /**
     * componentPlaceholder is relevent for composite 1<-->1 relations:
     *  - 'inline' : the relation is displayed as a button in the parent view. An entity view use case is triggered on click
     *  - 'tab' : the relation is displayed as a seperate tab
     *  componentPlaceholder = ParentFieldViewLayout.fieldGroup.layout
     */
    relationType?: string;
};
type TransformedCompositeViewLayout = {
    transformedCompositeViewLayoutGroups: CompositeViewLayoutGroup[];
    /**
     *   containerType?: string; // COMPOSITE, SIMPLE
     *
     * - COMPOSITE: if the entity {has at least one composite relation} (a relation with an other entity)
     *             if at least one field satisfying the following criteria exists:
     *                 {{viewLayout.type == "collection"}
     *               or
     *                 {viewLayout.type="composite"}
     *
     *
     * - SIMPLE: if the entity does not have any composite relations with other entities
     */
    containerType?: string;
    /**
     * viewLayout?: string;
     *
     *   - "tab": if at least: { {one field is composite} and {viewLayout.layout == "tab"} }
     *   - "inline": {if at least one field is composite} and {all viewLayout.layout != "tab"}
     *
     */
    viewLayout?: string;
};
declare class ToCompositeViewLayoutPipe implements PipeTransform {
    transform(viewLayout: Observable<FieldViewLayout[]>, ...args: unknown[]): Observable<TransformedCompositeViewLayout>;
    generateTransformedCompositeViewLayout: (transformedCompositeViewLayout: TransformedCompositeViewLayout, fieldViewLayoutItem: FieldViewLayout, index: number, viewLayout: FieldViewLayout[]) => TransformedCompositeViewLayout;
    isCompositeField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    inlineViewCompositeField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    isIterableField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    isCompositeRelationField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
    groupByGroupID: (transformedViewLayout: TransformedSimpleViewLayoutGroup, fieldViewLayoutItem: FieldViewLayout) => TransformedSimpleViewLayoutGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToCompositeViewLayoutPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ToCompositeViewLayoutPipe, "toCompositeViewLayout", false>;
}

declare class ViewLayoutMappingRecord {
    mappingKey: string;
    mappingValue: string | ((...args: any) => Observable<any>) | AverosLocalServiceCall;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class TransformViewLayoutPipe implements PipeTransform {
    transform(entityViewLayout: Observable<EntityViewLayout<any>>, mappingRecords?: ViewLayoutMappingRecord[]): Observable<EntityViewLayout<any>>;
    transformEntityViewLayout(entityViewLayout: EntityViewLayout<any>, mappingRecords: ViewLayoutMappingRecord[]): EntityViewLayout<any>;
    getTransformedEntityViewLayout(entityViewLayout: EntityViewLayout<any>, mappingRecords: ViewLayoutMappingRecord[]): EntityViewLayout<any>;
    transformWithSingleMappingEntry(currentObject: any, vLayoutMappingRecord: ViewLayoutMappingRecord, secondDepthKey: string): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TransformViewLayoutPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TransformViewLayoutPipe, "transformViewLayout", false>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class ToBooleanPipe implements PipeTransform {
    transform(value: unknown): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToBooleanPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ToBooleanPipe, "toBoolean", false>;
}

declare class TranslationService {
    constructor();
    initialize(): Promise<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslationService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class TranslatePipe implements PipeTransform {
    transform(keyTobeTranslated: string, translationID?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TranslatePipe, "translate", false>;
}

declare function translationInitializer(translationService: TranslationService): () => Promise<any>;
declare class AverosTranslationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosTranslationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AverosTranslationModule, [typeof TranslatePipe], [typeof i2$1.CommonModule], [typeof TranslatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AverosTranslationModule>;
}

declare class AverosSharedModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSharedModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AverosSharedModule, [typeof MaterialElevationDirective, typeof AccordionDirective, typeof AccordionAnchorDirective, typeof AccordionLinkDirective, typeof DataExportDirective, typeof SafeIconDirective, typeof SortCollectionByPipe, typeof ToObservablePipe, typeof ToViewLayoutPipe, typeof ToTabbedViewLayoutPipe, typeof ToCompositeViewLayoutPipe, typeof TransformViewLayoutPipe, typeof ToBooleanPipe], [typeof i2$1.CommonModule, typeof AverosTranslationModule], [typeof MaterialElevationDirective, typeof AccordionDirective, typeof AccordionAnchorDirective, typeof AccordionLinkDirective, typeof DataExportDirective, typeof SafeIconDirective, typeof SortCollectionByPipe, typeof ToObservablePipe, typeof ToViewLayoutPipe, typeof ToTabbedViewLayoutPipe, typeof ToCompositeViewLayoutPipe, typeof TransformViewLayoutPipe, typeof ToBooleanPipe, typeof AverosTranslationModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AverosSharedModule>;
}

declare class AverosCoreRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosCoreRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AverosCoreRoutingModule, never, [typeof i1$1.RouterModule], [typeof i1$1.RouterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AverosCoreRoutingModule>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class HomeComponent implements OnInit {
    private sanitizer;
    videoUrl: string;
    safeURL: SafeResourceUrl;
    constructor(sanitizer: DomSanitizer);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HomeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HomeComponent, "averos-home", never, {}, {}, never, never, false, never>;
}

declare class PublicSpaceRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PublicSpaceRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PublicSpaceRoutingModule, never, [typeof i1$1.RouterModule], [typeof i1$1.RouterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PublicSpaceRoutingModule>;
}

declare class PublicSpaceModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PublicSpaceModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PublicSpaceModule, [typeof HomeComponent], [typeof i2$1.CommonModule, typeof PublicSpaceRoutingModule], [typeof HomeComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PublicSpaceModule>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

interface AppSettings$1 {
    navPos?: 'side' | 'top';
    dir?: 'ltr' | 'rtl';
    theme?: 'light' | 'dark';
    showHeader?: boolean;
    headerPos?: 'fixed' | 'static' | 'above';
    showUserPanel?: boolean;
    sidenavOpened?: boolean;
    sidenavCollapsed?: boolean;
    language?: string;
}
declare const defaultOptions: AppSettings$1;
declare class AverosMenuComponent implements OnInit {
    private breakpointObserver;
    private appSharedService;
    private viewEventHandlerService;
    private applicationMenuService;
    private alertService;
    openDesigner: boolean;
    logged: any;
    currentLoggedUserProfile: any;
    languageProfileSet$: Observable<ProfileLanguage[]>;
    activateAverosSettingsWidget: boolean;
    activateGlobalSearchWidget: boolean;
    activateDefaultGitWidget: boolean;
    activateAverosDesigner: boolean;
    enableAuthentication: boolean;
    rightSideNavOpened: boolean;
    isHandset$: Observable<boolean>;
    options: AppSettings$1;
    toolBarNavigationItems$: Observable<ApplicationNavigationItem[]>;
    sideNavNavigationItems$: Observable<ApplicationNavigationItem[]>;
    constructor(breakpointObserver: BreakpointObserver, appSharedService: ApplicationSharedService, viewEventHandlerService: ViewEventHandlerService, applicationMenuService: ApplicationMenuService, alertService: AlertService);
    ngOnInit(): void;
    get alertservice(): typeof AlertService;
    handleEvent(eventAction: any): void;
    get appSharedSrv(): ApplicationSharedService;
    buildNavigationItems(): void;
    get notificationService(): AlertService;
    openRightSideNav(event: boolean): void;
    showSettingsWidget(): boolean;
    showMenuFooter(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosMenuComponent, "averos-menu", never, { "openDesigner": { "alias": "openDesigner"; "required": false; }; "logged": { "alias": "logged"; "required": false; }; "currentLoggedUserProfile": { "alias": "currentLoggedUserProfile"; "required": false; }; "languageProfileSet$": { "alias": "languageProfileSet$"; "required": false; }; "activateAverosSettingsWidget": { "alias": "activateAverosSettingsWidget"; "required": false; }; "activateGlobalSearchWidget": { "alias": "activateGlobalSearchWidget"; "required": false; }; "activateDefaultGitWidget": { "alias": "activateDefaultGitWidget"; "required": false; }; "activateAverosDesigner": { "alias": "activateAverosDesigner"; "required": false; }; "enableAuthentication": { "alias": "enableAuthentication"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class AuthenticationService {
    private httpClient;
    private router;
    private localStorageService;
    private applicationMenuService;
    private applicationSharedService;
    private viewEventHandlerService;
    private environmentConfiguratorService;
    private readonly averosConfig;
    currentUser: Observable<any>;
    private authenticationEnabled;
    get registerURL(): string;
    get loginURL(): string;
    get logoutURL(): string;
    get refreshAPI(): string;
    get verifyAccountAPI(): string;
    get resetPasswordAPI(): string;
    get requestResetPasswordAPI(): string;
    get loggedUserRolesAPI(): string;
    private currentUserSubject;
    getIdentityAPIUrl(actionUri: string): string;
    constructor(httpClient: HttpClient, router: Router, localStorageService: LocalStorageService, applicationMenuService: ApplicationMenuService, applicationSharedService: ApplicationSharedService, viewEventHandlerService: ViewEventHandlerService, environmentConfiguratorService: EnvironmentConfiguratorService);
    get currentUserValue(): AuthUser;
    registerUser(user: any): Observable<any>;
    isUserProfileLangExist(): boolean;
    loginUser(user: any): Observable<any>;
    logout(): Observable<any>;
    logoutUser(): void;
    getLoggedUsersRoles(): Observable<string[]>;
    refreshToken(): Observable<any>;
    verifyAccount(token: string): Observable<any>;
    resetPasswordUsingToken(password: string, token: string): Observable<any>;
    requestPasswordReset(email: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthenticationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthenticationService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosMenuHeaderComponent implements OnInit {
    private authenticationService;
    private alertService;
    isHandset: any;
    logged: any;
    currentLoggedUserProfile: AuthUser;
    isDarkThemeActive: any;
    navItems: ApplicationNavigationItem[];
    languageProfileSet$: Observable<ProfileLanguage[]>;
    activateGlobalSearchWidget: boolean;
    activateDefaultGitWidget: boolean;
    activateAverosDesigner: boolean;
    enableAuthentication: boolean;
    eventHandler: EventEmitter<any>;
    currentDate: string;
    constructor(authenticationService: AuthenticationService, alertService: AlertService);
    get authService(): AuthenticationService;
    get alertservice(): typeof AlertService;
    get notificationService(): AlertService;
    isLoggedSpace(logged: any): boolean;
    ngOnInit(): void;
    handleEvent(actionEvent: any): void;
    /**
     * At least one child is in public space or root has no childs
     * @param navItem
     * @returns
     */
    atLeastOneChildIsInPublicSpace(navItem: ApplicationNavigationItem): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosMenuHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosMenuHeaderComponent, "averos-menu-header", never, { "isHandset": { "alias": "isHandset"; "required": false; }; "logged": { "alias": "logged"; "required": false; }; "currentLoggedUserProfile": { "alias": "currentLoggedUserProfile"; "required": false; }; "isDarkThemeActive": { "alias": "isDarkThemeActive"; "required": false; }; "navItems": { "alias": "navItems"; "required": false; }; "languageProfileSet$": { "alias": "languageProfileSet$"; "required": false; }; "activateGlobalSearchWidget": { "alias": "activateGlobalSearchWidget"; "required": false; }; "activateDefaultGitWidget": { "alias": "activateDefaultGitWidget"; "required": false; }; "activateAverosDesigner": { "alias": "activateAverosDesigner"; "required": false; }; "enableAuthentication": { "alias": "enableAuthentication"; "required": false; }; }, { "eventHandler": "eventHandler"; }, never, never, false, never>;
}

declare class AverosMenuBodyComponent implements OnInit {
    private aplicationSharedService;
    isHandset: any;
    logged: any;
    currentLoggedUserProfile: AuthUser;
    sideNavItems$: Observable<ApplicationNavigationItem[]>;
    enableAuthentication: boolean;
    rightSideNav: MatSidenav;
    set rightSideNavOpened(state: boolean);
    sidenavOpened: boolean;
    sidenavCollapsed: boolean;
    setNavState: string;
    navPos: string;
    private contentWidthFix;
    get isContentWidthFix(): boolean;
    private collapsedWidthFix;
    get isCollapsedWidthFix(): any;
    constructor(aplicationSharedService: ApplicationSharedService);
    ngOnInit(): void;
    get systemTickers(): rxjs.BehaviorSubject<AverosTicker[]>;
    get userTickers(): rxjs.BehaviorSubject<AverosTicker[]>;
    onRemoveUserTicker(tickerID: string): void;
    onRemoveSystemTicker(tickerID: string): void;
    sidenavOpenedChange(isOpened: boolean): void;
    sidenavCloseStart(): void;
    toggleCollapsed(): void;
    resetCollapsedState(): void;
    OpenLeftSideNav(event: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosMenuBodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosMenuBodyComponent, "averos-menu-body", never, { "isHandset": { "alias": "isHandset"; "required": false; }; "logged": { "alias": "logged"; "required": false; }; "currentLoggedUserProfile": { "alias": "currentLoggedUserProfile"; "required": false; }; "sideNavItems$": { "alias": "sideNavItems$"; "required": false; }; "enableAuthentication": { "alias": "enableAuthentication"; "required": false; }; "rightSideNavOpened": { "alias": "rightSideNavOpened"; "required": false; }; }, {}, never, ["*"], false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosMenuFooterComponent implements OnInit {
    isHandset: any;
    logged: any;
    get appVersion(): string;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosMenuFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosMenuFooterComponent, "averos-menu-footer", never, { "isHandset": { "alias": "isHandset"; "required": false; }; "logged": { "alias": "logged"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AnimatedIconComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnimatedIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AnimatedIconComponent, "app-animated-icon", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosMenuItemComponent implements OnInit {
    router: Router;
    items: ApplicationNavigationItem[];
    logged: any;
    childMenu: any;
    constructor(router: Router);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosMenuItemComponent, "averos-menu-item", never, { "items": { "alias": "items"; "required": false; }; "logged": { "alias": "logged"; "required": false; }; }, {}, never, never, false, never>;
}

type NotificationRole = 'GlobalLoading' | 'GlobalAlerts' | 'LocalInline';
/**
 * AverosAppNotificationComponent
 *
 * Unified notification component that displays various types of alerts and loading indicators:
 * - Full-screen loading (progress bar or spinner based on device)
 * - Inline loading (spinner or progress bar for embedded components)
 * - Alert messages (success, error, warning) shown in dialogs
 *
 * This component automatically subscribes to the AlertService and displays
 * the appropriate UI based on the current alert state.
 *
 * @example
 * ```html
 * <averos-app-notification></averos-app-notification>
 * ```
 */
declare class AverosAppNotificationComponent {
    private readonly dialog;
    private readonly alertService;
    private readonly breakpointObserver;
    private readonly appSharedService;
    /**
     * Indicates if the device is a handset (mobile)
     * Used to determine responsive UI behavior
     */
    protected readonly isHandset: i0.Signal<boolean>;
    /**
    * Defines the specific responsibility of this component instance.
    * - 'GlobalLoading': Handles only full-screen progress (e.g., in the header).
    * - 'GlobalAlerts': Handles only dialog messages (e.g., in the body).
    * - 'LocalInline': Handles only local inline loading (e.g., tables/fields).
    * @default 'GlobalLoading'
    */
    role: NotificationRole;
    /**
     * If true, this component is used for local inline loading (Field Spinner or Grid Progress).
     * If false, this component is used for global Full-Screen Loading or Alert Dialogs.
     */
    isLocal: boolean;
    private _isInlineLoadingOverride;
    /**
       * Used exclusively when role is 'LocalInline' to provide the loading state.
       * @default false
       */
    set isInlineLoadingOverride(value: boolean);
    /**
     * Material theme color for progress indicators
     * @default 'primary'
     */
    color: ThemePalette;
    /**
     * Progress bar/spinner mode
     * @default 'indeterminate'
     */
    mode: ProgressBarMode;
    /**
     * Diameter of the spinner (in pixels)
     * @default 24
     */
    diameter: number;
    /**
     * Indicates if the inline loader is shown within a grid/table
     * When true, uses progress bar instead of spinner for inline loading
     * @default false
     */
    grid: boolean;
    /**
     * Current alert message from the service
     */
    protected readonly message: i0.Signal<_wiforge_averos.AlertMessage>;
    /**
     * Computed: Is the current message an event message (success/error/warning)?
     */
    protected readonly isEventMessage: i0.Signal<boolean>;
    /**
     * Computed: Is full-screen loading active?
     */
    protected readonly isFullScreenLoading: i0.Signal<boolean>;
    /**
     * Computed: Is inline loading active?
     */
    protected readonly isInlineLoading: i0.Signal<boolean>;
    /**
     * Static reference to AlertService for template usage
     */
    protected readonly AlertService: typeof AlertService;
    private currentDialogRef;
    private lastProcessedMessage;
    constructor();
    get darkThemeActivated(): boolean;
    /**
     * Initialize effect to automatically open dialogs for alert messages
     */
    private initializeAlertMessageEffect;
    /**
     * Opens a dialog to display the notification message
     * @param message - The alert message to display
     */
    private raiseNotificationMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosAppNotificationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosAppNotificationComponent, "averos-app-notification", never, { "role": { "alias": "role"; "required": true; }; "isLocal": { "alias": "isLocal"; "required": false; }; "isInlineLoadingOverride": { "alias": "isInlineLoadingOverride"; "required": false; }; "color": { "alias": "color"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "diameter": { "alias": "diameter"; "required": false; }; "grid": { "alias": "grid"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosMessageDialogComponent implements OnInit {
    dialogRef: MatDialogRef<AverosMessageDialogComponent>;
    data: any;
    private readonly alertService;
    protected readonly AlertService: typeof AlertService;
    constructor(dialogRef: MatDialogRef<AverosMessageDialogComponent>, data: any);
    onCancelClick(): void;
    onContinueClick(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosMessageDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosMessageDialogComponent, "averos-message-dialog", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

interface SearchChip {
    name: string;
}
declare class AverosSearchInputTextFieldComponent implements OnInit, ControlValueAccessor {
    private injector;
    visible: boolean;
    selectable: boolean;
    removable: boolean;
    addOnBlur: boolean;
    readonly separatorKeysCodes: number[];
    searchChip: SearchChip[];
    appearance: MatFormFieldAppearance;
    label: string;
    labelTranslationID: string;
    placeholder: string;
    placeholderTranslationID: string;
    disabled: boolean;
    maxLength: number;
    required: boolean;
    formControlName: NgControl;
    entityAccessorKey: string;
    value: any;
    operationSelect: MatSelect;
    matInputComponent: MatInput;
    matChipList: MatChipGrid;
    selectedOperator: AverosSearchOperator;
    outputCriteria: AverosCriteria;
    onChange: (_: any) => void;
    onTouched: () => void;
    operations: AverosSearchOperator[];
    constructor(injector: Injector);
    writeValue(value: any): void;
    changeInputValue(parentHostInputValue: string): void;
    operationChange(event: MatSelectChange): void;
    onValueChange(averosCriteria: AverosCriteria): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    ngOnInit(): void;
    convertArrayToCommaSepValues(searchChip: SearchChip[]): string;
    add(event: MatChipInputEvent): void;
    remove(searchChip: SearchChip): void;
    drop(event: CdkDragDrop<SearchChip[]>): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSearchInputTextFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSearchInputTextFieldComponent, "averos-search-input-text-field", never, { "appearance": { "alias": "appearance"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelTranslationID": { "alias": "labelTranslationID"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "placeholderTranslationID": { "alias": "placeholderTranslationID"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "required": { "alias": "required"; "required": false; }; "entityAccessorKey": { "alias": "entityAccessorKey"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSearchInputDateFieldComponent implements OnInit, ControlValueAccessor {
    private injector;
    private breakpointObserver;
    appearance: string;
    label: string;
    labelTranslationID: string;
    placeholder: string;
    placeholderTranslationID: string;
    dateInputDisabled: boolean;
    required: boolean;
    entityAccessorKey: string;
    value: string;
    operationSelect: MatSelect;
    matInputComponent: MatInput;
    selectedOperator: AverosSearchOperator;
    outputCriteria: AverosCriteria;
    isHandset$: Observable<boolean>;
    pickerDisabled: boolean;
    formControlName: NgControl;
    onChange: (_: any) => void;
    onTouched: () => void;
    operations: AverosSearchOperator[];
    constructor(injector: Injector, breakpointObserver: BreakpointObserver);
    writeValue(value: string): void;
    changeInputValue(parentHostInputValue: string): void;
    operationChange(event: MatSelectChange): void;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSearchInputDateFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSearchInputDateFieldComponent, "averos-search-input-date-field", never, { "appearance": { "alias": "appearance"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelTranslationID": { "alias": "labelTranslationID"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "placeholderTranslationID": { "alias": "placeholderTranslationID"; "required": false; }; "dateInputDisabled": { "alias": "dateInputDisabled"; "required": false; }; "required": { "alias": "required"; "required": false; }; "entityAccessorKey": { "alias": "entityAccessorKey"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class RowActionMetaData {
    /**
    * the row Action
    *
    */
    rowActionID: string;
    /**
     * the row data
     */
    rowData: any;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class RowAction {
    /**
    * the action identifier (action name)
    *
    */
    actionID: string;
    /**
     *
     */
    actionTranslationID: string;
    /**
     * the activation criteria in the form of a function
     */
    isActive?: Function;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosDynamicTableComponent<T> implements OnInit, OnDestroy {
    private filterGroup;
    dialog: MatDialog;
    private bottomSheetExportFormat;
    private dataExporterService;
    private alertService;
    private breakpointObserver;
    private fileService;
    private cdr;
    showRowActions: boolean;
    showCustomRowActions: boolean;
    customRowActions: RowAction[];
    shrinkedLayout: boolean;
    selectable: boolean;
    multipleSelection: boolean;
    forInput: boolean;
    showFilterComponent: boolean;
    trackByField: () => void;
    filterComponentLabel: string;
    filterComponentLabelTranslationID: string;
    filterKey: string;
    set useCaseConfig(useCaseConfig: UseCaseConfig<T>);
    get useCaseConfig(): UseCaseConfig<T>;
    viewObject: EventEmitter<T>;
    viewCompositeObject: EventEmitter<any>;
    executeCustomRowAction: EventEmitter<any>;
    editObject: EventEmitter<T>;
    deleteObject: EventEmitter<T>;
    addObject: EventEmitter<T>;
    reloadTable: EventEmitter<T>;
    search: EventEmitter<SearchInputCriteria>;
    resetReloadData: EventEmitter<boolean>;
    selectOne: EventEmitter<T>;
    selectMany: EventEmitter<T[]>;
    deleteMany: EventEmitter<T[]>;
    pageChange: EventEmitter<PageEvent>;
    set matPaginator(paginator: MatPaginator);
    set matSort(sort: MatSort);
    dynamicTable: ElementRef;
    filterComponent: ElementRef<HTMLInputElement>;
    isHandset$: Observable<boolean>;
    filtertableFormGoup: FormGroup;
    private internalUseCaseConfig;
    private matTableDataSource;
    private unsubscribe$;
    private tableDataSubscription;
    private bottomSheetSubscription;
    private dataRetrievalSubscription;
    private matPaginatorState;
    FieldType: typeof FieldType;
    private cachedData;
    protected isGridLoading: boolean;
    ucVLayout: UseCaseViewLayout<T>;
    get dataSource(): MatTableDataSource<T>;
    private tableColumns;
    private genericDialog;
    private internalDataSubject;
    private _externalDataSubscription;
    set dataSource$(obs: Observable<T[] | PaginatedData<T>>);
    set data(data: T[] | PaginatedData<T>);
    set reloadData(reloadData: boolean);
    get alertservice(): typeof AlertService;
    private componentViewLayout;
    set viewLayout(viewLayout: EntityViewLayout<T>);
    get viewLayout(): EntityViewLayout<T>;
    get columns(): string[];
    selection: SelectionModel<T>;
    constructor(filterGroup: FormBuilder, dialog: MatDialog, bottomSheetExportFormat: MatBottomSheet, dataExporterService: DataExporterService<T>, alertService: AlertService, breakpointObserver: BreakpointObserver, fileService: FileService, cdr: ChangeDetectorRef);
    ngOnDestroy(): void;
    get notificationService(): AlertService;
    get usecase(): typeof UseCase;
    ngOnInit(): void;
    drop(event: CdkDragDrop<string[]>): void;
    resetData(): void;
    loadData(): void;
    initializePaginatorState(pageSize: number): void;
    /**
     * Initialize filter component
     */
    initializeFilterComponent(): void;
    /**
   * Apply filter to the data source
   * Separated into its own method for better testability and reusability
   */
    private applyFilter;
    evaluateExpression(element: T, key: string, defaultValue?: any): any;
    evaluateCompositeRelationValue(element: T, key: string): any;
    getCompositeRelationEntityBusinessIdName(compositeRelationNavigationKey: any): string;
    _onPreviewImage(image: string): void;
    displayTextArea(text: string, title: string, titleTranslationID: string): void;
    viewCompositeEntity(entityMetaData: EntityMetaData): void;
    executeCustomAction(actionMetaData: RowActionMetaData): void;
    onAddObject(event: any): void;
    onReload(event: any): void;
    onExportData(format: string): void;
    openBottomSheetExportTypes(): void;
    onViewObject(selectedObject: T): void;
    onEditObject(selectedObject: T): void;
    onDeleteObject(selectedObject: T): void;
    openSearch(): void;
    onSearch(criteria: SearchInputCriteria): void;
    onSelectOne(selectedObject: T): void;
    onSelectMany(): void;
    onDeleteMany(): void;
    /** Whether the number of selected elements matches the total number of rows. */
    isAllSelected(): boolean;
    /** Selects all rows if they are not all selected; otherwise clear selection. */
    masterToggle(): void;
    /** The label for the checkbox on the passed row */
    checkboxLabel(row?: T): string;
    getFile(currentElement: T, fieldViewLayout: FieldViewLayout, type: string): void;
    onPageChange(pageEvent: PageEvent): void;
    updatePageData(): void;
    updateCachedData(paginatedData: PaginatedData<T>): void;
    getTotalItemsCount(): number;
    getPageSize(): number;
    getPageIndex(): number;
    updateTableData(data: T[] | PaginatedData<T>): void;
    changeCheckBox(matCheckBowChangeEvent: MatCheckboxChange, row: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosDynamicTableComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosDynamicTableComponent<any>, "averos-dynamic-table", never, { "showRowActions": { "alias": "showRowActions"; "required": false; }; "showCustomRowActions": { "alias": "showCustomRowActions"; "required": false; }; "customRowActions": { "alias": "customRowActions"; "required": false; }; "shrinkedLayout": { "alias": "shrinkedLayout"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "multipleSelection": { "alias": "multipleSelection"; "required": false; }; "forInput": { "alias": "forInput"; "required": false; }; "showFilterComponent": { "alias": "showFilterComponent"; "required": false; }; "trackByField": { "alias": "trackByField"; "required": false; }; "filterComponentLabel": { "alias": "filterComponentLabel"; "required": false; }; "filterComponentLabelTranslationID": { "alias": "filterComponentLabelTranslationID"; "required": false; }; "filterKey": { "alias": "filterKey"; "required": false; }; "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "dataSource$": { "alias": "dataSource$"; "required": false; }; "data": { "alias": "data"; "required": false; }; "reloadData": { "alias": "reloadData"; "required": false; }; "viewLayout": { "alias": "viewLayout"; "required": false; }; }, { "viewObject": "viewObject"; "viewCompositeObject": "viewCompositeObject"; "executeCustomRowAction": "executeCustomRowAction"; "editObject": "editObject"; "deleteObject": "deleteObject"; "addObject": "addObject"; "reloadTable": "reloadTable"; "search": "search"; "resetReloadData": "resetReloadData"; "selectOne": "selectOne"; "selectMany": "selectMany"; "deleteMany": "deleteMany"; "pageChange": "pageChange"; }, never, never, false, never>;
}

declare class BottomSheetDataExportFormatComponent {
    private bottomSheetRef;
    constructor(bottomSheetRef: MatBottomSheetRef<BottomSheetDataExportFormatComponent>);
    onSelectExportFormat(format: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BottomSheetDataExportFormatComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BottomSheetDataExportFormatComponent, "averos-bottom-sheet-data-export-format", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosViewEntityComponent<T> implements OnInit, OnDestroy {
    private alertService;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    displayActions: boolean;
    submitForm: EventEmitter<T>;
    cloneEvent: EventEmitter<boolean>;
    updateEditMode: EventEmitter<boolean>;
    componentReactiveForm: FormGroup;
    isFormModified: boolean;
    submitted: boolean;
    constructor(alertService: AlertService);
    formModified(event: boolean): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    clone(): void;
    cancelUpdate(): boolean;
    disableSave(): boolean;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosViewEntityComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosViewEntityComponent<any>, "averos-view-entity", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; "displayActions": { "alias": "displayActions"; "required": false; }; }, { "submitForm": "submitForm"; "cloneEvent": "cloneEvent"; "updateEditMode": "updateEditMode"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosViewEntityDialogComponent<T> implements OnInit {
    data: any;
    dialogRef: MatDialogRef<T>;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    submitForm: EventEmitter<any>;
    editEvent: EventEmitter<boolean>;
    updateEditMode: EventEmitter<boolean>;
    averosViewEntityComponent: AverosViewEntityComponent<T>;
    goFullScreen: boolean;
    constructor(data: any, dialogRef: MatDialogRef<T>);
    ngOnInit(): void;
    updateEditModeInParent(event: boolean): void;
    onCancel(data?: any): void;
    edit(): void;
    onSubmit(): void;
    submitToParentForm(entity: any): void;
    disableSave(): boolean;
    expandDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosViewEntityDialogComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosViewEntityDialogComponent<any>, "averos-view-entity-dialog", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; }, { "submitForm": "submitForm"; "editEvent": "editEvent"; "updateEditMode": "updateEditMode"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosCreateEntityComponent<T> implements OnInit, OnDestroy {
    private alertService;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    displayActions: boolean;
    submitForm: EventEmitter<T>;
    cloneEvent: EventEmitter<boolean>;
    updateEditMode: EventEmitter<boolean>;
    componentReactiveForm: FormGroup;
    isFormModified: boolean;
    submitted: boolean;
    constructor(alertService: AlertService);
    formModified(event: boolean): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    clone(): void;
    cancelUpdate(): boolean;
    disableSave(): boolean;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosCreateEntityComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosCreateEntityComponent<any>, "averos-create-entity", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; "displayActions": { "alias": "displayActions"; "required": false; }; }, { "submitForm": "submitForm"; "cloneEvent": "cloneEvent"; "updateEditMode": "updateEditMode"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosCreateEntityDialogComponent<T> implements OnInit {
    data: any;
    dialogRef: MatDialogRef<T>;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    submitForm: EventEmitter<any>;
    cloneEvent: EventEmitter<boolean>;
    updateEditMode: EventEmitter<boolean>;
    averosCreateEntityComponent: AverosCreateEntityComponent<T>;
    goFullScreen: boolean;
    constructor(data: any, dialogRef: MatDialogRef<T>);
    ngOnInit(): void;
    updateEditModeInParent(event: boolean): void;
    onCancel(data?: any): void;
    clone(): void;
    resetForm(): void;
    onSubmit(): void;
    submitToParentForm(entity: any): void;
    disableSave(): boolean;
    expandDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosCreateEntityDialogComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosCreateEntityDialogComponent<any>, "averos-create-entity-dialog", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; }, { "submitForm": "submitForm"; "cloneEvent": "cloneEvent"; "updateEditMode": "updateEditMode"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosEditEntityComponent<T> implements OnInit, OnDestroy {
    private alertService;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    displayActions: boolean;
    submitForm: EventEmitter<T>;
    cloneEvent: EventEmitter<boolean>;
    updateEditMode: EventEmitter<boolean>;
    componentReactiveForm: FormGroup;
    isFormModified: boolean;
    submitted: boolean;
    constructor(alertService: AlertService);
    formModified(event: boolean): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    clone(): void;
    cancelUpdate(): boolean;
    disableSave(): boolean;
    onSubmit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosEditEntityComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosEditEntityComponent<any>, "averos-edit-entity", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; "displayActions": { "alias": "displayActions"; "required": false; }; }, { "submitForm": "submitForm"; "cloneEvent": "cloneEvent"; "updateEditMode": "updateEditMode"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosEditEntityDialogComponent<T> implements OnInit {
    data: any;
    dialogRef: MatDialogRef<T>;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    submitForm: EventEmitter<any>;
    editEvent: EventEmitter<boolean>;
    updateEditMode: EventEmitter<boolean>;
    averosEditEntityComponent: AverosEditEntityComponent<T>;
    goFullScreen: boolean;
    constructor(data: any, dialogRef: MatDialogRef<T>);
    ngOnInit(): void;
    updateEditModeInParent(event: boolean): void;
    onCancel(data?: any): void;
    edit(): void;
    onSubmit(): void;
    submitToParentForm(entity: any): void;
    disableSave(): boolean;
    expandDialog(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosEditEntityDialogComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosEditEntityDialogComponent<any>, "averos-edit-entity-dialog", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; }, { "submitForm": "submitForm"; "editEvent": "editEvent"; "updateEditMode": "updateEditMode"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

interface AppSettings {
    navPos?: 'side' | 'top';
    dir?: 'ltr' | 'rtl';
    theme?: 'light' | 'dark';
    showHeader?: boolean;
    headerPos?: 'fixed' | 'static' | 'above';
    showUserPanel?: boolean;
    sidenavOpened?: boolean;
    sidenavCollapsed?: boolean;
}
declare class AverosSettingsComponent implements OnInit {
    options: AppSettings;
    opened: boolean;
    dragging: boolean;
    isHandset: boolean;
    openRightSideNavEvent: EventEmitter<boolean>;
    constructor();
    ngOnInit(): void;
    handleDragStart(event: CdkDragStart): void;
    openPanel(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSettingsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSettingsComponent, "averos-settings", never, { "isHandset": { "alias": "isHandset"; "required": false; }; }, { "openRightSideNavEvent": "openRightSideNavEvent"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class BrandComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrandComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BrandComponent, "app-brand", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class GithubComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GithubComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GithubComponent, "app-github", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class NotifierComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotifierComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotifierComponent, "app-notifier", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class TranslatorComponent implements OnInit {
    changeLanguage: EventEmitter<any>;
    languageProfileSet$: Observable<ProfileLanguage[]>;
    mselect: MatSelect;
    constructor();
    ngOnInit(): void;
    onChangeLanguage(event: any): void;
    getCurrentProfileSVGIcon(): Observable<string>;
    openLanguageSelection(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TranslatorComponent, "averos-translator", never, { "languageProfileSet$": { "alias": "languageProfileSet$"; "required": false; }; }, { "changeLanguage": "changeLanguage"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSearchComponent implements OnInit {
    searchInputBox: ElementRef<HTMLInputElement>;
    constructor();
    ngOnInit(): void;
    openSearch(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSearchComponent, "averos-search", never, {}, {}, never, never, false, never>;
}

declare class UserComponent implements OnInit, OnDestroy {
    private authenticationService;
    private averosAuth;
    currentLoggedUserProfile: AuthUser;
    private logOutSubscription;
    readonly userPicture: i0.Signal<string>;
    constructor(authenticationService: AuthenticationService, averosAuth: AverosAuthService);
    ngOnDestroy(): void;
    ngOnInit(): void;
    logout(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserComponent, "app-user", never, { "currentLoggedUserProfile": { "alias": "currentLoggedUserProfile"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSidemenuComponent implements OnInit {
    isHandset: boolean;
    logged: boolean;
    currentLoggedUserProfile: AuthUser;
    sideNavItems$: Observable<ApplicationNavigationItem[]>;
    enableAuthentication: boolean;
    toggleChecked: boolean;
    toggleCollapsed: EventEmitter<void>;
    drawer: MatSidenav;
    constructor();
    ngOnInit(): void;
    menuItemClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSidemenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSidemenuComponent, "averos-sidemenu", never, { "isHandset": { "alias": "isHandset"; "required": false; }; "logged": { "alias": "logged"; "required": false; }; "currentLoggedUserProfile": { "alias": "currentLoggedUserProfile"; "required": false; }; "sideNavItems$": { "alias": "sideNavItems$"; "required": false; }; "enableAuthentication": { "alias": "enableAuthentication"; "required": false; }; "toggleChecked": { "alias": "toggleChecked"; "required": false; }; "drawer": { "alias": "drawer"; "required": false; }; }, { "toggleCollapsed": "toggleCollapsed"; }, never, never, false, never>;
}

declare class AverosSidemenuUserpanelComponent implements OnInit {
    private authenticationService;
    private averosAuth;
    readonly userPicture: i0.Signal<string>;
    currentLoggedUserProfile: AuthUser;
    constructor(authenticationService: AuthenticationService, averosAuth: AverosAuthService);
    get authService(): AuthenticationService;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSidemenuUserpanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSidemenuUserpanelComponent, "averos-sidemenu-userpanel", never, { "currentLoggedUserProfile": { "alias": "currentLoggedUserProfile"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSidemenuMenuComponent implements OnInit {
    logged: boolean;
    sideNavItems$: Observable<ApplicationNavigationItem[]>;
    menuItemClicked: EventEmitter<void>;
    constructor();
    ngOnInit(): void;
    buildRoute(routes: string[]): string;
    isDisabled(disabled: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSidemenuMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSidemenuMenuComponent, "averos-sidemenu-menu", never, { "logged": { "alias": "logged"; "required": false; }; "sideNavItems$": { "alias": "sideNavItems$"; "required": false; }; }, { "menuItemClicked": "menuItemClicked"; }, never, never, false, never>;
}

declare class AverosViewEditInputFieldComponent implements OnInit, ControlValueAccessor {
    private injector;
    private breakpointObserver;
    private alertService;
    readonly compositeEntity: i0.WritableSignal<string>;
    readonly announcer: LiveAnnouncer;
    FieldType: typeof FieldType;
    matInputComponent: MatInput;
    appNotif: AverosAppNotificationComponent;
    editModeActivated: boolean;
    controlErrorDescription: string;
    /**
     * This field holds the composite value to be displayed in case
     * The displayed value is the evaluation of compositeEntity.targetKeyForCompositeEntity.
     *
     **/
    targetKeyForCompositeEntity: string;
    targetFieldDomain$: Observable<any[]>;
    targetFieldDomain: TargetDomainField;
    iconLayout: string;
    appearance: string;
    label: string;
    labelTranslationID: string;
    placeholder: string;
    placeholderTranslationID: string;
    required: boolean;
    type: FieldType;
    icon: any;
    /**
     * default icon orientation is RIGHT (SUFFIX) for edit usecase
     * and LEFT (PREFIX) for View usecase
     */
    iconOrientation: string;
    compositeEntityAccessorKey: string | undefined;
    entityAccessorKey: string;
    private value_;
    set value(value: any);
    get value(): any;
    componentValueChanged: EventEmitter<any>;
    onCompositeRelationActionEvent: EventEmitter<any>;
    isHandset$: Observable<boolean>;
    currentElementFocused: boolean;
    startDate: Date;
    formControlName: NgControl;
    onChange: (_: any) => void;
    onTouched: () => void;
    constructor(injector: Injector, breakpointObserver: BreakpointObserver, alertService: AlertService);
    ngOnInit(): void;
    triggerOpened(): void;
    get alertservice(): typeof AlertService;
    get notificationService(): AlertService;
    displayValue(maxLength?: number): any;
    get isDate(): boolean;
    writeValue(value: any): void;
    changeInputValue(parentHostInputValue: string): void;
    onCheckBoxChange(value: any): void;
    onValueChange(value: any): void;
    getIndeterminate(value: any): boolean;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    setDisabledState?(isDisabled: boolean): void;
    getFieldDomain(targetFieldDomain: TargetDomainField): Observable<DomainEntry[]>;
    onCompositeRelationViewClicked(value: any): void;
    onCompositeRelationAddClicked(value: any): void;
    onCompositeRelationDeleteClicked(value: any): void;
    protected updateCompositeRelation(value: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosViewEditInputFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosViewEditInputFieldComponent, "averos-view-edit-input-field", never, { "editModeActivated": { "alias": "editModeActivated"; "required": false; }; "controlErrorDescription": { "alias": "controlErrorDescription"; "required": false; }; "targetKeyForCompositeEntity": { "alias": "targetKeyForCompositeEntity"; "required": false; }; "targetFieldDomain": { "alias": "targetFieldDomain"; "required": false; }; "iconLayout": { "alias": "iconLayout"; "required": false; }; "appearance": { "alias": "appearance"; "required": false; }; "label": { "alias": "label"; "required": false; }; "labelTranslationID": { "alias": "labelTranslationID"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "placeholderTranslationID": { "alias": "placeholderTranslationID"; "required": false; }; "required": { "alias": "required"; "required": false; }; "type": { "alias": "type"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconOrientation": { "alias": "iconOrientation"; "required": false; }; "compositeEntityAccessorKey": { "alias": "compositeEntityAccessorKey"; "required": false; }; "entityAccessorKey": { "alias": "entityAccessorKey"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "componentValueChanged": "componentValueChanged"; "onCompositeRelationActionEvent": "onCompositeRelationActionEvent"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosDynamicSimpleViewComponent<T> implements OnInit {
    private formControlService;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    editModeActivated: any;
    isFormModified: EventEmitter<boolean>;
    onCompositeRelationActionEvent: EventEmitter<any>;
    set reactiveForm(reactiveForm: FormGroup);
    get reactiveForm(): FormGroup;
    internalReactiveForm: FormGroup;
    formModified: boolean;
    private formInitialValue;
    constructor(formControlService: FormControlService);
    ngOnInit(): void;
    initializeFormValues(): void;
    getValidationMessage(form: FormGroup, fieldKey?: string, fieldValidator?: FieldValidator): string;
    evaluateExpression(element: T, key: any): any;
    isCompositeNavigationKey(entityFieldName: string): boolean;
    getCompositeEntityAccessorKey(fieldViewLayout: FieldViewLayout): string | undefined;
    getFieldValue(entityFieldName: string): any;
    getCompositeFieldGroupName(compositeKey: string): string;
    getCompositeFormControlName(fieldName: string): string;
    getCompositeFieldsArrayKeysLenght(compositeFieldName: string): number;
    onValueChange(emittedValue: any): void;
    deepEqual(object1: any, object2: any): boolean;
    onCompositeRelationAction(emittedValue: any, fieldName: string): void;
    private onDeleteCompositeRelation;
    private onAddCompositeRelation;
    private onViewCompositeRelation;
    isObject(object: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosDynamicSimpleViewComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosDynamicSimpleViewComponent<any>, "averos-dynamic-simple-view", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; }, { "isFormModified": "isFormModified"; "onCompositeRelationActionEvent": "onCompositeRelationActionEvent"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosDynamicCompositeViewComponent<T> implements OnInit, OnDestroy {
    private formControlService;
    dialog: MatDialog;
    private viewLayoutService;
    private useCaseConfigP;
    set useCaseConfig(useCaseConfig: UseCaseConfig<T>);
    get useCaseConfig(): UseCaseConfig<T>;
    editModeActivated: any;
    reactiveForm: FormGroup;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    isFormModified: EventEmitter<boolean>;
    isCompositeRelationModified: EventEmitter<boolean>;
    onCompositeRelationActionEvent: EventEmitter<any>;
    idName: any;
    /**
     * The events will update the relation collection while in an EDIT/UPDATE/CREATE view
     * the related event could be either DELETE or ADD
     */
    updateRelationCollection: EventEmitter<EntityAlteredRelationEventData>;
    reloadData: boolean;
    privateParentEntityType: T;
    dialogSubscription: Subscription;
    private genericDialog;
    constructor(formControlService: FormControlService, dialog: MatDialog, viewLayoutService: ViewLayoutService);
    ngOnDestroy(): void;
    ngOnInit(): void;
    formModified(event: any): void;
    get useCase(): typeof UseCase;
    evaluateExpression(parentInstance: T, key: string): any;
    getCollectionCount(parentInstance: T, key: string): any;
    /**
     *
     * @param parentType
     * @param relationFieldName
     * @returns Returns the target composite member "FormGroup" according to
     *              the type of the target member that is subject to
     *              a one to one composite relationship with the parent entity.
     */
    getCompositeRelationEntityReactiveForm(parentType: T, relationFieldName: string): FormGroup;
    /**
     *
     * @param parentType
     * @param relationFieldName
     * @returns Returns the target composite member "EntityViewLayout" according to
     *              the type of the target member that is subject to
     *              a one to one composite relationship with the parent entity.
     */
    getEntityViewLayout(parentType: T, relationFieldName: string): Observable<EntityViewLayout<unknown>>;
    /**
     *
     * @param parentType
     * @param relationFieldName
     * @returns Returns the target composite member "EntityUseCaseViewLayout" according to
     *              the type of the target member that is subject to
     *              a one to one composite relationship with the parent entity.
     */
    getCompositeRelationUseCaseViewLayout(parentType: T, relationFieldName: string): Observable<UseCaseViewLayout<unknown>>;
    getCompositeRelationEntityUseCaseConfig(parentType: T, relationFieldName: string): UseCaseConfig<T>;
    getCollectionRelationEntityUseCaseConfig(parentType: T, relationFieldName: string): UseCaseConfig<any>;
    resetTableReloadData(resetReloadData: boolean): void;
    onDeleteRelationCollectionItem(deleteRelationCollectionEventData: {
        itemSubjectToAction: any;
        relationName: string;
    }, emit?: boolean): void;
    onDeleteManyRelationCollectionItem(deleteManyRelationCollectionEventData: {
        itemsSubjectToAction: any[];
        relationName: string;
    }): void;
    onAddRelationCollectionItem(/*AddRelationCollectionItemEventData: {itemSubjectToAction: any, relationName: string}*/ relationFieldName: string): void;
    transformToTargetIds(resultingIds: string[], idName: string): unknown[];
    private getCallBackIdsCriteria;
    /**
     * extracts the ids under the form of ['id1', 'id2', 'id3'...]
     *
     * @param memberType
     *
     * @param ids
     * @returns
     */
    private getIdsCollection;
    private getCompositeRelationId;
    onCompositeRelationAction(entityAlteredRelationEventData: EntityAlteredRelationEventData): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosDynamicCompositeViewComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosDynamicCompositeViewComponent<any>, "averos-dynamic-composite-view", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; }, { "isFormModified": "isFormModified"; "isCompositeRelationModified": "isCompositeRelationModified"; "onCompositeRelationActionEvent": "onCompositeRelationActionEvent"; "updateRelationCollection": "updateRelationCollection"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosDynamicStepperComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosDynamicStepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosDynamicStepperComponent, "averos-dynamic-stepper", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSearchEntityComponent<T> implements OnInit {
    private alertService;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    searchInputFormGoup: FormGroup;
    executeSearch: EventEmitter<SearchInputCriteria>;
    matExpansionPanel: MatExpansionPanel;
    constructor(alertService: AlertService);
    ngOnInit(): void;
    searchEntities(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSearchEntityComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSearchEntityComponent<any>, "averos-search-entity", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "searchInputFormGoup": { "alias": "searchInputFormGoup"; "required": false; }; }, { "executeSearch": "executeSearch"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSearchInputFieldComponent<T> implements OnInit {
    fieldViewLayout: FieldViewLayout;
    useCaseConfig: UseCaseConfig<T>;
    searchInputFormGoup: FormGroup;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSearchInputFieldComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSearchInputFieldComponent<any>, "averos-search-input-field", never, { "fieldViewLayout": { "alias": "fieldViewLayout"; "required": false; }; "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "searchInputFormGoup": { "alias": "searchInputFormGoup"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosDynamicDialogComponent<T> implements OnInit, OnDestroy {
    data: AverosViewConfig;
    private breakpointObserver;
    dialogRef: MatDialogRef<unknown>;
    dialog: MatDialog;
    private alertService;
    private formControlService;
    private viewLayoutService;
    private changeDetector;
    useCaseConfig: UseCaseConfig<any>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    propagatedValue: any;
    canActivateEditMode: boolean;
    dataCollection$: Observable<T[] | PaginatedData<T>>;
    onLoadDataSubscription: Subscription;
    onSubmitDataCallBackSubscription: Subscription;
    activateObjectsSelection: boolean;
    displayActions: boolean;
    isHandset$: Observable<boolean>;
    isFormModified: boolean;
    isCompositeRelationModified: boolean;
    submitted: boolean;
    reloadData: boolean;
    privateParentEntityType: T;
    dialogSubscription: Subscription;
    private structureSub;
    private layoutSub;
    private genericDialog;
    goFullScreen: boolean;
    constructor(data: AverosViewConfig, breakpointObserver: BreakpointObserver, dialogRef: MatDialogRef<unknown>, dialog: MatDialog, alertService: AlertService, formControlService: FormControlService, viewLayoutService: ViewLayoutService, changeDetector: ChangeDetectorRef);
    ngOnInit(): void;
    /**
     * Subscribes to parent-driven form structure changes.
     * Safe to call unconditionally — guards against missing observable.
     */
    private wireFormStructureSubscription;
    getEntityViewLayout(): Observable<EntityViewLayout<unknown>>;
    get useCase(): typeof UseCase;
    onCancel(data?: any): void;
    onSelectMany(selectedData: T[]): void;
    onSelect(selectedData: T): void;
    resetForm(): void;
    edit(): void;
    updateEditMode(event: boolean): void;
    onSubmit(): void;
    get notificationService(): AlertService;
    get alertservice(): typeof AlertService;
    expandDialog(): void;
    viewRelation(event: any): void;
    editRelation(event: any): void;
    addRelation(event: any): void;
    deleteRelation(event: any): void;
    formModified(event: boolean): void;
    compositeRelationModified(event: boolean): void;
    ngOnDestroy(): void;
    clone(): void;
    cancelUpdate(): boolean;
    disableSave(): boolean;
    updateRelationCollection(entityAlteredRelationEventData: EntityAlteredRelationEventData): void;
    /**
     * a collection relation process triggered
     * when an item is deleted from a relation that is a collection
     *
     * The function updates the parent with the resulted collection
     */
    private deleteRelationCollectionItem;
    /**
  * a collection relation process triggered
  * when an item is added to a relation that is a collection
  *
  * The function updates the parent with the resulted collection
  */
    private addRelationCollectionItem;
    /**
     * Updates the componentReactiveForm value with the resulting modified relation value
     * according to relationName and resulting relation value
     */
    private updateReactiveFormValueWithUpdatedRelationValues;
    evaluateExpression(parentInstance: T, key: string): any;
    getCollectionCount(parentInstance: T, key: string): any;
    /**
     *
     * @param parentType
     * @param relationFieldName
     * @returns Returns the target composite member "FormGroup" according to
     *              the type of the target member that is subject to
     *              a one to one composite relationship with the parent entity.
     */
    getCompositeRelationEntityReactiveForm(parentType: T, relationFieldName: string): FormGroup;
    /**
     *
     * @param parentType
     * @param relationFieldName
     * @returns Returns the target composite member "EntityViewLayout" according to
     *              the type of the target member that is subject to
     *              a one to one composite relationship with the parent entity.
     */
    getEntityViewLayout_(parentType: T, relationFieldName: string): Observable<EntityViewLayout<unknown>>;
    /**
     *
     * @param parentType
     * @param relationFieldName
     * @returns Returns the target composite member "EntityUseCaseViewLayout" according to
     *              the type of the target member that is subject to
     *              a one to one composite relationship with the parent entity.
     */
    getCompositeRelationUseCaseViewLayout(parentType: T, relationFieldName: string): Observable<EntityViewLayout<unknown>>;
    getCompositeRelationEntityUseCaseConfig(parentType: T, relationFieldName: string): UseCaseConfig<T>;
    getCollectionRelationEntityUseCaseConfig(parentType: T, relationFieldName: string): UseCaseConfig<any>;
    resetTableReloadData(resetReloadData: boolean): void;
    onDeleteRelationCollectionItem(deleteRelationCollectionEventData: {
        itemSubjectToAction: any;
        relationName: string;
    }): void;
    onAddRelationCollectionItem(/*AddRelationCollectionItemEventData: {itemSubjectToAction: any, relationName: string}*/ relationFieldName: string): void;
    transforCompositeEntitiesIDS(resultingItems: string[], idName: string): object[];
    private getCallBackIdsCriteria;
    /**
     * extracts the ids under the form of ['id1', 'id2', 'id3'...]
     *
     * @param memberType
     *
     * @param ids
     * @returns
     */
    private getIdsCollection;
    private getCompositeRelationId;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosDynamicDialogComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosDynamicDialogComponent<any>, "averos-dynamic-dialog", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare abstract class AvService<T> {
    protected httpClient: HttpClient;
    protected applicationSharedService: ApplicationSharedService;
    protected environmentConfiguratorService: EnvironmentConfiguratorService;
    abstract get SERVICE_NAME(): string;
    get apiURL(): string;
    get apiHTTPQueryBuilder(): string;
    abstract get EXTERNAL_ENTITY_IDENTIFIER(): string;
    constructor(httpClient: HttpClient, applicationSharedService: ApplicationSharedService, environmentConfiguratorService: EnvironmentConfiguratorService);
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare abstract class AvCrudService<T> extends AvService<T> {
    protected httpClient: HttpClient;
    protected applicationSharedService: ApplicationSharedService;
    protected environmentConfiguratorService: EnvironmentConfiguratorService;
    protected entityConfigurationManagerService: EntityConfigurationManagerService;
    abstract get MANAGED_ENTITY(): T;
    get MANAGED_ENTITY_NAME(): string;
    /**
     * The EXTERNAL identifier is usually the unique entity identifier that is used by
     * the external managing service to identify and manages the related service.
     *
     * This may be the datasource entity identifier such as a primary key for example,
     * or simply the identifier that the called api uses to handle its entities.
     *
     * THE DEFAULT value is equal to '_id'.
     * If your external service uses a different value to identify the managed entity please create a related service/gateway
     * configuration for this matter
    */
    get EXTERNAL_ENTITY_IDENTIFIER(): string;
    constructor(httpClient: HttpClient, applicationSharedService: ApplicationSharedService, environmentConfiguratorService: EnvironmentConfiguratorService, entityConfigurationManagerService: EntityConfigurationManagerService);
    /**
     * CRUD operations
     */
    abstract createEntity(value: T | Partial<T>, criteria?: SearchInputCriteria): Observable<T>;
    abstract updateEntity(entityTopdate: T | Partial<T>, criteria?: SearchInputCriteria): Observable<T>;
    /**
     * Delete the entity
     * @param entity : could be either an entity / Partial entity / entity's identifier (id)
     * @returns
     */
    abstract deleteEntity(entity?: T | Partial<T> | string, criteria?: SearchInputCriteria): Observable<T>;
    /**
     * Delete the entity collection
     * @param entityCollection : could be either an entity collection or a Partial entity collection
     * @returns
     */
    abstract deleteMany(entityCollection: T[] | Partial<T>[], criteria?: SearchInputCriteria): Observable<T[]>;
    abstract getAllEntities(): Observable<T[] | PaginatedData<T>>;
    abstract getEntityById(id: string, criteria?: SearchInputCriteria): Observable<T>;
    abstract getEntitiesByIds(ids: string[], criteria?: SearchInputCriteria): Observable<T[] | PaginatedData<T>>;
    /**
      * ---------- inline-loading -----------
      *
      * Whenever a backend API is requested the application will display a loading progress component untill a response is got.
      * Using 'inline-loading': true as displayed below, would display a the loading indicator inside the most inner html component (freezes only the current component).
      * If you rather wish to use the the global application loading component (freezes the whole UI while waiting for a response)
      *  then remove this parameter from the http query or set it to false ('inline-loading': false)
      *
      **/
    abstract getEntitiesByCriteria(criteria: SearchInputCriteria, inline?: boolean): Observable<T[] | PaginatedData<T>>;
    /**
     *
     * @param id the parent entity id
     * @param relationName : The collection relation Name
     * @param cids : the ids of the collection to be removed from the parent entity
     * @returns
     *
     * N.B: cids: {id: string}[]) : cids structure depends on the identifier name of the entity:
     * ex: id entity'identifier ==
     *                              + "_entityId" ==> cids: {_entityId: string}[]
     *                              + "_entityId" ==> cids: {_entityId: string}[]
     *                              + "identifier" ==> cids: {identifier: string}[]
     *                              + "some__entityId" ==> cids: {some__entityId: string}[]
     *                              + ...ect...
     */
    abstract deleteRelationCollection(parentId: string, parent: T | Partial<T>, relationName: string, cids: {
        id: string;
    }[]): Observable<T>;
    /**
     *
     * @param parentId the parent entity id
     * @param relationName : The collection relation Name
     * @param cids : the ids of the collection to be added from the parent entity
     * @returns
     */
    abstract addRelationCollection(parentId: string, parent: T | Partial<T>, relationName: string, cids: {
        id: string;
    }[]): Observable<T>;
    /**
     * Default CRUD operations
     */
    defaultCreateEntity(value: T | Partial<T>, criteria?: SearchInputCriteria): Observable<T>;
    defaultUpdateEntity(entityTopdate: T | Partial<T>, criteria?: SearchInputCriteria): Observable<T>;
    /**
     * Delete the entity
     * @param entity : could be either an entity / Partial entity / entity's identifier (id)
     * @returns
     */
    defaultDeleteEntity(entity?: T | Partial<T> | string): Observable<T>;
    /**
     * Delete the entity collection
     * @param entity : could be either a collection of entity / a collection of Partial entity
     * @returns
     */
    defaultDeleteMany(entities?: T[] | Partial<T>[]): Observable<T[]>;
    defaultGetAllEntities(): Observable<T[] | PaginatedData<T>>;
    defaultGetEntityById(id: string, criteria: SearchInputCriteria): Observable<T>;
    defaultGetEntitiesByIds(ids: string[], criteria: SearchInputCriteria): Observable<T[] | PaginatedData<T>>;
    defaultGetEntitiesByCriteria(criteria: SearchInputCriteria, inline?: boolean): Observable<T[] | PaginatedData<T>>;
    /**
     *
     * @param id the parent entity id
     * @param relationName : The collection relation Name
     * @param cids : the ids of the collection to be removed from the parent entity
     * @returns
     *
     * N.B: cids: {id: string}[]) : cids structure depends on the identifier name of the entity:
     * ex: id entity'identifier ==
     *                              + "_entityId" ==> cids: {_entityId: string}[]
     *                              + "_entityId" ==> cids: {_entityId: string}[]
     *                              + "identifier" ==> cids: {identifier: string}[]
     *                              + "some__entityId" ==> cids: {some__entityId: string}[]
     *                              + ...ect...
     */
    defaultDeleteRelationCollection(parentId: string, parent: T | Partial<T>, relationName: string, cids: {
        id: string;
    }[]): Observable<T>;
    /**
     *
     * @param parentId the parent entity id
     * @param relationName : The collection relation Name
     * @param cids : the ids of the collection to be added from the parent entity
     * @returns
     */
    defaultAddRelationCollection(parentId: string, parent: T | Partial<T>, relationName: string, cids: {
        id: string;
    }[]): Observable<T>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosViewEditEntityComponent<T> implements OnInit, OnDestroy {
    private alertService;
    private formControlService;
    useCaseConfig: UseCaseConfig<T>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    editModeActivated: boolean;
    displayActions: boolean;
    submitForm: EventEmitter<T>;
    cloneEvent: EventEmitter<boolean>;
    editEvent: EventEmitter<boolean>;
    updateEditMode: EventEmitter<boolean>;
    updateRelationCollectionEvent: EventEmitter<EntityAlteredRelationEventData>;
    onCompositeRelationActionEvent: EventEmitter<any>;
    set reactiveForm(reactiveForm: FormGroup);
    /**
     * used only when the component is called from within a generic dialog in order to synchronize
     * the dialog reactiveForm with the component reactive form (same as set reactiveForm).
     * The point is to trigger change detection whenever the generic dialog reactive form changes
     * and keep the two forms synchronized in terms of data
     *
     *  */
    get reactiveForm(): FormGroup;
    componentReactiveForm: FormGroup;
    isFormModified: boolean;
    isCompositeRelationModified: boolean;
    submitted: boolean;
    searchCompositeEntity: boolean;
    private currentCompositeChildEntity;
    private currentCompositeRelationField;
    showCompositeEntitySearchResult: boolean;
    compositeRelationUseCaseConfig: UseCaseConfig<unknown>;
    compositeRelationEntityUseCaseViewLayout$: Observable<UseCaseViewLayout<unknown>>;
    compositeRelationSearchInputFormGoup: FormGroup;
    compositeRelationsearchCriteria: SearchInputCriteria;
    compositeRelationEntitiesSearchResultValues$: Observable<unknown[] | PaginatedData<unknown>>;
    compositeRelationEntityViewLayout: Observable<EntityViewLayout<unknown>>;
    compositeRelationEntityService: AvCrudService<unknown>;
    constructor(alertService: AlertService, formControlService: FormControlService);
    formModified(event: boolean): void;
    compositeRelationModified(event: boolean): void;
    get useCase(): typeof UseCase;
    ngOnInit(): void;
    ngOnDestroy(): void;
    clone(): void;
    edit(): void;
    cancelUpdate(): boolean;
    disableSave(): boolean;
    onSubmit(): void;
    updateRelationCollection(entityAlteredRelationEventData: EntityAlteredRelationEventData): void;
    /**
     * a collection relation process triggered
     * when an item is deleted from a relation that is a collection
     *
     * The function updates the parent with the resulted collection
     */
    private deleteRelationCollectionItem;
    /**
  * a collection relation process triggered
  * when an item is added to a relation that is a collection
  *
  * The function updates the parent with the resulted collection
  */
    private addRelationCollectionItem;
    /**
     * Updates the componentReactiveForm value with the resulting modified relation value
     * according to relationName and resulting relation value
     */
    private updateReactiveFormValueWithUpdatedRelationValues;
    onCompositeRelationAction(entityAlteredRelationEventData: EntityAlteredRelationEventData): void;
    removeCompositeRelationEntity(entityAlteredRelationEventData: EntityAlteredRelationEventData): void;
    addCompositeRelationEntity(entityAlteredRelationEventData: EntityAlteredRelationEventData): void;
    initializeCompositeRelationView(): void;
    searchCompositeRelationEntities(searchInputCriteria: SearchInputCriteria): void;
    getCompositeRelationEntityUseCaseConfig(): UseCaseConfig<any>;
    getSearchCompositeRelationEntityUseCaseViewLayout(): Observable<UseCaseViewLayout<any>>;
    searchInputCompositeRelationEntityFormGoup(): FormGroup;
    getCompositeRelationEntityViewLayout(): Observable<EntityViewLayout<unknown>>;
    getCompositeRelationEntityService(): AvCrudService<unknown>;
    onSelectOne(selectedElement: T): void;
    onPageChange(pageEvent: PageEvent): void;
    search(event: SearchInputCriteria): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosViewEditEntityComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosViewEditEntityComponent<any>, "averos-view-edit-entity", never, { "useCaseConfig": { "alias": "useCaseConfig"; "required": false; }; "entityUseCaseViewLayout$": { "alias": "entityUseCaseViewLayout$"; "required": false; }; "editModeActivated": { "alias": "editModeActivated"; "required": false; }; "displayActions": { "alias": "displayActions"; "required": false; }; "reactiveForm": { "alias": "reactiveForm"; "required": false; }; }, { "submitForm": "submitForm"; "cloneEvent": "cloneEvent"; "editEvent": "editEvent"; "updateEditMode": "updateEditMode"; "updateRelationCollectionEvent": "updateRelationCollectionEvent"; "onCompositeRelationActionEvent": "onCompositeRelationActionEvent"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSearchResultComponent<T> implements OnInit {
    viewLayout: Observable<EntityViewLayout<T>>;
    showRowActions: boolean;
    showCustomRowActions: boolean;
    selectable: boolean;
    multipleSelection: boolean;
    forInput: boolean;
    customRowActions: RowAction[];
    data$: Observable<T[] | PaginatedData<T>>;
    showFilterComponent: boolean;
    trackByField: () => any;
    filterComponentLabel: string;
    filterComponentLabelTranslationID: string;
    filterKey: string;
    viewObject: EventEmitter<T>;
    viewCompositeObject: EventEmitter<any>;
    executeCustomRowAction: EventEmitter<any>;
    editObject: EventEmitter<T>;
    deleteObject: EventEmitter<T>;
    addObject: EventEmitter<T>;
    reloadTable: EventEmitter<T>;
    search: EventEmitter<SearchInputCriteria>;
    deleteMany: EventEmitter<T[]>;
    pageChange: EventEmitter<PageEvent>;
    selectOne: EventEmitter<T>;
    selectMany: EventEmitter<T[]>;
    matExpansionPanel: MatExpansionPanel;
    averosDynamicTable: AverosDynamicTableComponent<T>;
    get searchCriteria(): SearchInputCriteria;
    set searchCriteria(searchInputCriteria: SearchInputCriteria);
    searchCriteria_: SearchInputCriteria;
    constructor();
    ngOnInit(): void;
    viewCompObject(compositeObject: {
        value: unknown;
        type: string;
        compositeType?: string;
    }): void;
    executeCustomAction(actionMetaData: RowActionMetaData): void;
    view(event: any): void;
    edit(event: any): void;
    add(event: any): void;
    reloadData(event: any): void;
    delete(event: any): void;
    onDeleteMany(event: any): void;
    searchData(event: any): void;
    onSearch(searchInputCriteria: SearchInputCriteria): void;
    onPageChange(pageEvent: PageEvent): void;
    onSelectOne(event: any): void;
    onSelectMany(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSearchResultComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSearchResultComponent<any>, "averos-search-result", never, { "viewLayout": { "alias": "viewLayout"; "required": false; }; "showRowActions": { "alias": "showRowActions"; "required": false; }; "showCustomRowActions": { "alias": "showCustomRowActions"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "multipleSelection": { "alias": "multipleSelection"; "required": false; }; "forInput": { "alias": "forInput"; "required": false; }; "customRowActions": { "alias": "customRowActions"; "required": false; }; "data$": { "alias": "data$"; "required": false; }; "showFilterComponent": { "alias": "showFilterComponent"; "required": false; }; "trackByField": { "alias": "trackByField"; "required": false; }; "filterComponentLabel": { "alias": "filterComponentLabel"; "required": false; }; "filterComponentLabelTranslationID": { "alias": "filterComponentLabelTranslationID"; "required": false; }; "filterKey": { "alias": "filterKey"; "required": false; }; "searchCriteria": { "alias": "searchCriteria"; "required": false; }; }, { "viewObject": "viewObject"; "viewCompositeObject": "viewCompositeObject"; "executeCustomRowAction": "executeCustomRowAction"; "editObject": "editObject"; "deleteObject": "deleteObject"; "addObject": "addObject"; "reloadTable": "reloadTable"; "search": "search"; "deleteMany": "deleteMany"; "pageChange": "pageChange"; "selectOne": "selectOne"; "selectMany": "selectMany"; }, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosAvatarSelectionDialogComponent implements OnInit {
    data: any;
    dialogRef: MatDialogRef<any>;
    defaultAvatarList: any[];
    private avatarURI;
    goFullScreen: boolean;
    constructor(data: any, dialogRef: MatDialogRef<any>);
    ngOnInit(): void;
    onCancel(data?: any): void;
    onCardClicked(avatarURI: any): void;
    onSubmit(): void;
    disableSave(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosAvatarSelectionDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosAvatarSelectionDialogComponent, "averos-averos-avatar-selection-dialog", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosSettingsPanelComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosSettingsPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosSettingsPanelComponent, "averos-averos-settings-panel", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AboutComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AboutComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AboutComponent, "averos-about", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class DashboardCardComponent implements OnInit {
    id: any;
    title: any;
    titleTranslationID: any;
    showMenu: any;
    value: any;
    valueDescription: any;
    valueDescriptionTranslationID: any;
    headerIcon: any;
    headerIconColor: any;
    animateHeaderIcon: any;
    mainContentIcon: any;
    mainColor: any;
    constructor();
    ngOnInit(): void;
    getColor(color: string): string;
    getBackGroundColor(color: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashboardCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DashboardCardComponent, "averos-dashboard-card", never, { "id": { "alias": "id"; "required": false; }; "title": { "alias": "title"; "required": false; }; "titleTranslationID": { "alias": "titleTranslationID"; "required": false; }; "showMenu": { "alias": "showMenu"; "required": false; }; "value": { "alias": "value"; "required": false; }; "valueDescription": { "alias": "valueDescription"; "required": false; }; "valueDescriptionTranslationID": { "alias": "valueDescriptionTranslationID"; "required": false; }; "headerIcon": { "alias": "headerIcon"; "required": false; }; "headerIconColor": { "alias": "headerIconColor"; "required": false; }; "animateHeaderIcon": { "alias": "animateHeaderIcon"; "required": false; }; "mainContentIcon": { "alias": "mainContentIcon"; "required": false; }; "mainColor": { "alias": "mainColor"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class IconThemeComponent implements OnInit {
    private resourceResourceLoaderService;
    color: any;
    changeIconTheme: EventEmitter<any>;
    protected iconThemesSet: string[];
    mselect: MatSelect;
    constructor(resourceResourceLoaderService: ResourceLoaderService);
    ngOnInit(): void;
    onChangeIconTheme(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconThemeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconThemeComponent, "averos-icon-theme", never, { "color": { "alias": "color"; "required": false; }; }, { "changeIconTheme": "changeIconTheme"; }, never, never, false, never>;
}

/**
 * Dynamic login component supporting multiple authentication flows
 * Automatically adapts UI based on configured providers
 */
declare class LoginComponent implements OnInit, OnDestroy {
    private averosAuth;
    private logger;
    private router;
    private formBuilder;
    private cdref;
    hidePassword: boolean;
    loginForm: FormGroup;
    isLoading: boolean;
    currentProvider: string | null;
    hasCredentialsAuth: boolean;
    hasDelegatedAuth: boolean;
    delegatedProviders: ProviderInfo[];
    defaultProvider: string;
    private destroy$;
    constructor(averosAuth: AverosAuthService, logger: LoggerService, router: Router, formBuilder: FormBuilder, cdref: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    /**
     * Discover and categorize available authentication providers
     */
    private discoverProviders;
    private initializeForm;
    get f(): {
        [key: string]: i3$1.AbstractControl<any, any, any>;
    };
    /**
     * Enable or disable all form controls
     */
    private setFormState;
    /**
     * Handle delegated provider login (OAuth, SSO)
     * @param providerName The authentication provider to use
     */
    loginWithProvider(providerName: string): Promise<void>;
    /**
    * Handle form submission for traditional username/password login
    */
    onSubmit(): Promise<void>;
    /**
     * Execute login with form credentials
     */
    private loginWithCredentials;
    /**
     * Subscribe to authentication errors from the service
     */
    private subscribeToAuthErrors;
    /**
     * Handle authentication errors
     */
    private handleAuthError;
    /**
     * Handle login errors with context
     */
    /**
     * Navigate to home after successful login
     */
    private navigateAfterLogin;
    /**
     * Mark all form fields as touched to show validation errors
     */
    private markFormAsTouched;
    /**
    * Check if a specific provider is currently loading
    */
    isProviderLoading(providerName: string): boolean;
    /**
     * Check if credentials form is currently loading
     */
    isCredentialsLoading(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoginComponent, "app-login", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class PasswordResetComponent implements OnInit, OnDestroy {
    private authenticationService;
    private globalCustomValidationService;
    private route;
    private router;
    private cd;
    routerSubscription: Subscription;
    resetPasswordSubscription: Subscription;
    resetPasswordResponse: {
        code: number;
        message: string;
    };
    rpToken: string;
    reactiveForm: FormGroup;
    hidePassword: boolean;
    constructor(authenticationService: AuthenticationService, globalCustomValidationService: GlobalCustomValidationService, route: ActivatedRoute, router: Router, cd: ChangeDetectorRef);
    ngOnDestroy(): void;
    ngOnInit(): void;
    resetPassword(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PasswordResetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PasswordResetComponent, "averos-password-reset", never, {}, {}, never, never, false, never>;
}

declare class UserService {
    private httpClient;
    private environmentConfiguratorService;
    private averosAuth;
    static readonly SERVICE_NAME = "UserService";
    private get authURL();
    private get userApi();
    constructor(httpClient: HttpClient, environmentConfiguratorService: EnvironmentConfiguratorService, averosAuth: AverosAuthService, averosConfig?: AverosConfig);
    getUserByUserName(userName: string): Observable<any>;
    getUserByEmail(email: string): Observable<any>;
    getAllUsers(): Observable<any[]>;
    getUsersByCriteria(criteria: SearchInputCriteria, inlineSearch?: boolean): Observable<any> | Observable<never>;
    getUserById(id: string | number): Observable<any>;
    /**
     * Is mandatory and should be present in order to give the iplementation
     *  of the method "getEntityById" requested in the decorator "AverosEntity"
     * @param id
     * @returns a user
     */
    getEntityById(id: string | number): Observable<any>;
    /**
     * Is mandatory and should be present in order to give the iplementation
     *  of the method "getEntitiesByIds" requested in the decorator "AverosEntity"
     * @param ids
     * @returns user[]
     */
    getEntitiesByIds(ids: string[]): Observable<any>;
    /**
     * Is mandatory and should be present in order to give the iplementation
     *  of the method "getEntitiesByCriteria" requested in the decorator "AverosEntity"
     * @param criteria
     * @returns user[]
     */
    getEntitiesByCriteria(criteria: SearchInputCriteria, inline?: boolean): Observable<any>;
    getUserFilteredByID(id: number | string): Observable<any>;
    updateUser(id: any, user: any | Partial<any>): Observable<any>;
    createUser(user: any): Observable<any>;
    deleteUser(id: any): Observable<any>;
    /**
     *
     * @param id the parent entity id (User)
     * @param relationName : The collection relation Name (ex. "roles")
     * @param cids : the ids of the collection to be removed from the parent entity (User)
     * @returns
     */
    deleteRelationCollection(id: any, relationName: string, cids: {
        _entityId: string;
    }[]): Observable<any>;
    /**
   *
   * @param id the parent entity id (User)
   * @param relationName : The collection relation Name (ex. "roles")
   * @param cids : the ids of the collection to be added from the parent entity (User)
   * @returns
   */
    addRelationCollection(id: any, relationName: string, cids: {
        _entityId: string;
    }[]): Observable<any>;
    getCurrentLoggedUser(username: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserService, [null, null, null, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class UserCustomValidationService implements OnDestroy {
    private userService;
    static validators: {
        name: string;
    }[];
    private unsubscribe$;
    constructor(userService: UserService);
    /**
     * Async Validator : User name already exists validator
     * validatorID = userNameValidator
     * validatorKey = userNameNotAvailable
     */
    userNameValidator(): AsyncValidatorFn;
    userAlreadyExists(userName: string): Observable<{
        userNameNotAvailable: boolean;
    } | {
        userNameNotAvailable: boolean;
    }>;
    /**
     * Async Validator : email already exists validator
     * validatorID = emailAlreadyexistsValidator
     * validatorKey = emailNotAvailable
     */
    emailAlreadyexistsValidator(): AsyncValidatorFn;
    emailAlreadyExists(email: string): Observable<{
        emailNotAvailable: boolean;
    } | {
        emailNotAvailable: boolean;
    }>;
    userNameValidator1(userControl: AbstractControl): Promise<unknown>;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserCustomValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UserCustomValidationService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class RegisterComponent implements OnInit, OnDestroy {
    private breakpointObserver;
    private globalCustomValidationService;
    private userCustomValidationService;
    private averosAuthService;
    private alertService;
    private router;
    hidePassword: boolean;
    registerUserData: AuthUser;
    hasSecondAdress: boolean;
    registerForm: FormGroup;
    startDate: Date;
    isHandset$: Observable<boolean>;
    subscription: Subscription;
    uniqueIDType: {
        name: string;
        translationID: string;
    }[];
    genders: {
        name: string;
        translationID: string;
    }[];
    cities: {
        name: string;
    }[];
    constructor(breakpointObserver: BreakpointObserver, globalCustomValidationService: GlobalCustomValidationService, userCustomValidationService: UserCustomValidationService, averosAuthService: AverosAuthService, alertService: AlertService, router: Router);
    get alertservice(): typeof AlertService;
    get notificationService(): AlertService;
    ngOnDestroy(): void;
    ngOnInit(): void;
    buildForm(): void;
    findInvalidControls(): any[];
    registerUser(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RegisterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RegisterComponent, "app-register", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class RequestPasswordResetComponent implements OnInit, OnDestroy {
    private authenticationService;
    private cd;
    requestResetPasswordSubscription: Subscription;
    requestResetPasswordResponse: {
        code: number;
        message: string;
    };
    rpToken: string;
    requestSubmitted: boolean;
    reactiveForm: FormGroup;
    constructor(authenticationService: AuthenticationService, cd: ChangeDetectorRef);
    ngOnDestroy(): void;
    ngOnInit(): void;
    getErrorMessage(form: FormGroup, fieldKey?: string): string;
    requestResetPassword(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestPasswordResetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RequestPasswordResetComponent, "averos-request-password-reset", never, {}, {}, never, never, false, never>;
}

declare class UserDashboardComponent {
    private breakpointObserver;
    /** Based on the screen size, switch from standard to one column per row */
    cards: rxjs.Observable<{
        title: string;
        cols: number;
        rows: number;
    }[]>;
    constructor(breakpointObserver: BreakpointObserver);
    static ɵfac: i0.ɵɵFactoryDeclaration<UserDashboardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UserDashboardComponent, "app-user-dashboard", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class ValidateAccountComponent implements OnInit, OnDestroy {
    private authenticationService;
    private route;
    private router;
    private cd;
    routerSubscription: Subscription;
    validateAccountSubscription: Subscription;
    verifyAccountResponse: {
        code: number;
        message: string;
    };
    constructor(authenticationService: AuthenticationService, route: ActivatedRoute, router: Router, cd: ChangeDetectorRef);
    ngOnDestroy(): void;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidateAccountComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ValidateAccountComponent, "averos-validate-account", never, {}, {}, never, never, false, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosGenericTextDialogComponent<T> implements OnInit, OnDestroy {
    data: AverosViewConfig;
    private breakpointObserver;
    dialogRef: MatDialogRef<unknown>;
    dialog: MatDialog;
    private alertService;
    private formControlService;
    useCaseConfig: UseCaseConfig<any>;
    entityUseCaseViewLayout$: Observable<UseCaseViewLayout<T>>;
    reactiveForm: FormGroup;
    editModeActivated: boolean;
    propagatedValue: any;
    canActivateEditMode: boolean;
    dataCollection$: Observable<[]>;
    onLoadDataSubscription: Subscription;
    onSubmitDataCallBackSubscription: Subscription;
    activateObjectsSelection: boolean;
    displayActions: boolean;
    isHandset$: Observable<boolean>;
    isFormModified: boolean;
    isCompositeRelationModified: boolean;
    submitted: boolean;
    reloadData: boolean;
    privateParentEntityType: T;
    dialogSubscription: Subscription;
    goFullScreen: boolean;
    constructor(data: AverosViewConfig, breakpointObserver: BreakpointObserver, dialogRef: MatDialogRef<unknown>, dialog: MatDialog, alertService: AlertService, formControlService: FormControlService);
    ngOnInit(): void;
    getEntityViewLayout(): Observable<EntityViewLayout<unknown>>;
    get useCase(): typeof UseCase;
    onCancel(data?: any): void;
    resetForm(): void;
    edit(): void;
    updateEditMode(event: boolean): void;
    onSubmit(): void;
    get notificationService(): AlertService;
    get alertservice(): typeof AlertService;
    expandDialog(): void;
    formModified(event: boolean): void;
    ngOnDestroy(): void;
    cancelUpdate(): boolean;
    disableSave(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosGenericTextDialogComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AverosGenericTextDialogComponent<any>, "averos-averos-generic-text-dialog", never, {}, {}, never, never, false, never>;
}

declare class ViewModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ViewModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ViewModule, [typeof AverosMenuComponent, typeof AverosMenuHeaderComponent, typeof AverosMenuBodyComponent, typeof AverosMenuFooterComponent, typeof AnimatedIconComponent, typeof AverosMenuItemComponent, typeof AverosAppNotificationComponent, typeof AverosMessageDialogComponent, typeof AverosSearchInputTextFieldComponent, typeof AverosSearchInputDateFieldComponent, typeof AverosDynamicTableComponent, typeof BottomSheetDataExportFormatComponent, typeof AverosViewEntityDialogComponent, typeof AverosCreateEntityDialogComponent, typeof AverosEditEntityDialogComponent, typeof AverosViewEntityComponent, typeof AverosEditEntityComponent, typeof AverosCreateEntityComponent, typeof AverosSettingsComponent, typeof BrandComponent, typeof GithubComponent, typeof NotifierComponent, typeof TranslatorComponent, typeof AverosSearchComponent, typeof UserComponent, typeof AverosSidemenuComponent, typeof AverosSidemenuUserpanelComponent, typeof AverosSidemenuMenuComponent, typeof AverosViewEditInputFieldComponent, typeof AverosDynamicSimpleViewComponent, typeof AverosDynamicCompositeViewComponent, typeof AverosDynamicStepperComponent, typeof AverosSearchEntityComponent, typeof AverosSearchInputFieldComponent, typeof AverosDynamicDialogComponent, typeof AverosViewEditEntityComponent, typeof AverosSearchResultComponent, typeof AverosAvatarSelectionDialogComponent, typeof AverosSettingsPanelComponent, typeof AboutComponent, typeof DashboardCardComponent, typeof IconThemeComponent, typeof LoginComponent, typeof PasswordResetComponent, typeof RegisterComponent, typeof RequestPasswordResetComponent, typeof UserDashboardComponent, typeof ValidateAccountComponent, typeof AverosGenericTextDialogComponent], [typeof i2$1.CommonModule, typeof AverosSharedModule, typeof MaterialModule, typeof i1$1.RouterModule, typeof i3$1.ReactiveFormsModule, typeof i3$1.FormsModule], [typeof AverosMenuComponent, typeof AverosMenuHeaderComponent, typeof AverosMenuBodyComponent, typeof AverosMenuFooterComponent, typeof AnimatedIconComponent, typeof AverosMenuItemComponent, typeof AverosAppNotificationComponent, typeof AverosMessageDialogComponent, typeof AverosSearchInputTextFieldComponent, typeof AverosSearchInputDateFieldComponent, typeof AverosDynamicTableComponent, typeof BottomSheetDataExportFormatComponent, typeof AverosViewEntityDialogComponent, typeof AverosCreateEntityDialogComponent, typeof AverosEditEntityDialogComponent, typeof AverosViewEntityComponent, typeof AverosEditEntityComponent, typeof AverosCreateEntityComponent, typeof AverosSettingsComponent, typeof BrandComponent, typeof GithubComponent, typeof NotifierComponent, typeof TranslatorComponent, typeof AverosSearchComponent, typeof UserComponent, typeof AverosSidemenuComponent, typeof AverosSidemenuUserpanelComponent, typeof AverosSidemenuMenuComponent, typeof AverosViewEditInputFieldComponent, typeof AverosDynamicSimpleViewComponent, typeof AverosDynamicCompositeViewComponent, typeof AverosDynamicStepperComponent, typeof AverosSearchEntityComponent, typeof AverosSearchInputFieldComponent, typeof AverosDynamicDialogComponent, typeof AverosViewEditEntityComponent, typeof AverosSearchResultComponent, typeof AverosAvatarSelectionDialogComponent, typeof AverosSettingsPanelComponent, typeof AboutComponent, typeof DashboardCardComponent, typeof IconThemeComponent, typeof LoginComponent, typeof PasswordResetComponent, typeof RegisterComponent, typeof RequestPasswordResetComponent, typeof UserDashboardComponent, typeof ValidateAccountComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ViewModule>;
}

declare class ReferentialRoutingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReferentialRoutingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReferentialRoutingModule, never, [typeof i1$1.RouterModule], [typeof i1$1.RouterModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReferentialRoutingModule>;
}

declare class ReferentialModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReferentialModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ReferentialModule, never, [typeof i2$1.CommonModule, typeof i3$1.FormsModule, typeof ReferentialRoutingModule, typeof AverosSharedModule, typeof i3$1.ReactiveFormsModule, typeof MaterialModule, typeof ViewModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ReferentialModule>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file has-role.directive.ts
 * @description Structural directive for role-based UI rendering.
 *
 * Usage:
 * <button *hasRole="'admin'">Admin Only</button>
 * <div *hasRole="['admin', 'editor']">Multiple Roles (ANY)</div>
 * <div *hasRole="['admin', 'editor']; requireAll: true">Multiple Roles (ALL)</div>
 */

declare class HasRoleDirective implements OnInit {
    private readonly authService;
    private readonly templateRef;
    private readonly viewContainer;
    private role;
    private requireAll;
    private hasView;
    /**
     * The role(s) to check. Can be a single string or array of strings.
     */
    set hasRole(role: string | string[]);
    /**
     * Whether ALL roles are required (true) or ANY role (false).
     * Defaults to false (ANY).
     */
    set hasRoleRequireAll(requireAll: boolean);
    ngOnInit(): void;
    private updateView;
    static ɵfac: i0.ɵɵFactoryDeclaration<HasRoleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HasRoleDirective, "[hasRole]", never, { "hasRole": { "alias": "hasRole"; "required": false; }; "hasRoleRequireAll": { "alias": "hasRoleRequireAll"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file has-permission.directive.ts
 * @description Structural directive for permission-based UI rendering.
 *
 * Usage:
 * <button *hasPermission="'posts:write'">Edit Post</button>
 * <div *hasPermission="['posts:write', 'posts:delete']">Multiple Permissions (ANY)</div>
 * <div *hasPermission="['posts:read', 'posts:write']; requireAll: true">Multiple Permissions (ALL)</div>
 */

declare class HasPermissionDirective implements OnInit {
    private readonly authService;
    private readonly templateRef;
    private readonly viewContainer;
    private permission;
    private requireAll;
    private hasView;
    /**
     * The permission(s) to check. Can be a single string or array of strings.
     */
    set hasPermission(permission: string | string[]);
    /**
     * Whether ALL permissions are required (true) or ANY permission (false).
     * Defaults to false (ANY).
     */
    set hasPermissionRequireAll(requireAll: boolean);
    ngOnInit(): void;
    private updateView;
    static ɵfac: i0.ɵɵFactoryDeclaration<HasPermissionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HasPermissionDirective, "[hasPermission]", never, { "hasPermission": { "alias": "hasPermission"; "required": false; }; "hasPermissionRequireAll": { "alias": "hasPermissionRequireAll"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file can-access.directive.ts
 * @description Structural directive for resource-action based UI rendering.
 * Delegates access control logic to the auth provider's canAccess() method.
 *
 * This provides fine-grained, provider-specific access control beyond simple
 * roles and permissions. Useful for complex authorization scenarios like:
 * - Resource ownership checks
 * - Contextual permissions (e.g., can edit own posts but not others')
 * - Dynamic policy evaluation
 *
 * Usage:
 * <button *canAccess="'posts:write'">Create Post</button>
 * <button *canAccess="'users:delete'">Delete User</button>
 * <div *canAccess="{ resource: 'documents', action: 'approve' }">Approve Document</div>
 *
 * Short syntax (resource:action):
 * <button *canAccess="'posts:write'">Edit</button>
 *
 * Object syntax (for complex scenarios):
 * <button *canAccess="{ resource: 'posts', action: 'write' }">Edit</button>
 */

/**
 * Input type for canAccess directive.
 * Supports both string shorthand (resource:action) and explicit object notation.
 */
type CanAccessInput = string | {
    resource: string;
    action?: string;
};
declare class CanAccessDirective implements OnInit {
    private readonly authService;
    private readonly templateRef;
    private readonly viewContainer;
    private resource;
    private action?;
    private hasView;
    /**
     * The resource and optional action to check access for.
     *
     * Accepts:
     * 1. String format: "resource:action" (e.g., "posts:write")
     * 2. Object format: { resource: "posts", action: "write" }
     */
    set canAccess(input: CanAccessInput);
    ngOnInit(): void;
    private updateView;
    static ɵfac: i0.ɵɵFactoryDeclaration<CanAccessDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CanAccessDirective, "[canAccess]", never, { "canAccess": { "alias": "canAccess"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosCoreModule {
    constructor(parentModule?: AverosCoreModule);
    /**
   * @deprecated Use `provideAverosCore(config)` in your application providers instead.
   * This method will be removed in a future major version.
   */
    static forRoot(averosConfig?: FrameworkConfiguration): ModuleWithProviders<AverosCoreModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosCoreModule, [{ optional: true; skipSelf: true; }]>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AverosCoreModule, [typeof AverosApplicationComponent], [typeof i2$1.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i3$1.FormsModule, typeof MaterialModule, typeof i1.LayoutModule, typeof AverosSharedModule, typeof AverosCoreRoutingModule, typeof PublicSpaceModule, typeof ViewModule, typeof ReferentialModule, typeof HasRoleDirective, typeof HasPermissionDirective, typeof CanAccessDirective], [typeof i2$1.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i3$1.FormsModule, typeof MaterialModule, typeof AverosApplicationComponent, typeof AverosSharedModule, typeof ViewModule, typeof HasRoleDirective, typeof HasPermissionDirective, typeof CanAccessDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AverosCoreModule>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

/**
 * USAGE GUIDE
 *
 * For NgModule-based applications:
 * ================================
 *
 * @NgModule({
 *   imports: [
 *     AverosCoreModule.forRoot(config)  // ← Recommended: includes components + providers
 *   ]
 * })
 *
 * OR (if you don't need module exports):
 *
 * @NgModule({
 *   providers: [
 *     provideAverosCore(config)  // ← Only provides services, no components
 *   ]
 * })
 *
 * For Standalone applications:
 * ============================
 *
 * // app.config.ts
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideAverosCore(config)
 *   ]
 * };
 */
declare function provideAverosCore(config?: FrameworkConfiguration): EnvironmentProviders;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare const AVEROS_CONFIG: InjectionToken<AverosConfig>;

declare class AuthenticationGuard {
    private averosAuthService;
    private router;
    private logger;
    private readonly averosConfig;
    constructor(averosAuthService: AverosAuthService, router: Router, logger: LoggerService);
    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean | UrlTree>;
    canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean | UrlTree>;
    private handleAuthFail;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthenticationGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthenticationGuard>;
}

declare class RoleGuard {
    private averosAuthService;
    private logger;
    private router;
    private alertService;
    private readonly averosConfig;
    constructor(averosAuthService: AverosAuthService, logger: LoggerService, router: Router, alertService: AlertService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<RoleGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RoleGuard>;
}

declare class AccountVerifiedGuard {
    private averosAuthService;
    private alertService;
    private readonly averosConfig;
    constructor(averosAuthService: AverosAuthService, alertService: AlertService);
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<AccountVerifiedGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AccountVerifiedGuard>;
}

interface CanComponentDeactivate {
    canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}
declare class CanDeactivateGuard {
    canDeactivate(component: CanComponentDeactivate, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    static ɵfac: i0.ɵɵFactoryDeclaration<CanDeactivateGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CanDeactivateGuard>;
}

declare class UnauthenticatedSpaceGuard {
    private averosAuthService;
    private router;
    private readonly averosConfig;
    constructor(averosAuthService: AverosAuthService, router: Router);
    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree;
    canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree>;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnauthenticatedSpaceGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<UnauthenticatedSpaceGuard>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare const averosAuthInterceptor: HttpInterceptorFn;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare const averosErrorInterceptor: HttpInterceptorFn;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare const averosLoadingInterceptor: HttpInterceptorFn;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare const averosMappingInterceptor: HttpInterceptorFn;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum EntityRelationType {
    ONE_TO_ONE = "OneToOne",
    ONE_TO_MANY = "OneToMany",
    MANY_TO_ONE = "ManyToOne"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class CompositeRelationMetadata {
    /**
     * The key value that defines the relation
     *
     */
    private relationName_;
    /**
     * Parent entity
     */
    private parentEntity_;
    /**
     * relationType could be:
     * - OneToOne
     * - OneToMany
     * - ManyToOne
     */
    private relationType_;
    /**
    * delete strategy
    * - OneToOne
    * - OneToMany
    * - ManyToOne
    */
    private deleteStrategy_;
    constructor(relationName: any, parentEntity: any, relationType?: EntityRelationType, deleteStrategy?: string);
    get relationName(): string;
    get parentEntity(): string;
    get relationType(): string;
    get deleteStrategy(): string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class TypeScriptTypeMetaDatatHandler {
    static readonly instance: TypeScriptTypeMetaDatatHandler;
    /**
     * compositeRelationsMetadata_ keep records of all composite relations metadata for a given parent entity:
     * [parentEntity: [compositerelation1, compositeRelation2...]]
     */
    private entityRelationsMetadata_;
    type: new () => any;
    private constructor();
    getFieldValue<T, K extends keyof T>(obj: T, key: K): T[K];
    getFields<T, K extends keyof T>(obj: T): Array<K>;
    getFieldNames<T>(obj: T): string[];
    getMemberType<T, K extends keyof T>(type: T, fieldKeyName: string): any;
    getIdName(type: any): string;
    getBusinessIdName(type: any): string;
    getClassName(type: any): string;
    getCompositeMemberService<T>(parentEntityType: T, relationName: string): AvCrudService<T>;
    create<T extends unknown>(c: new () => T): T;
    evaluateExpression<T>(element: T, key: string, defaultValue?: any): any;
    isSimpleType(obj: any): boolean;
    get entityRelationsMetadata(): Record<string, CompositeRelationMetadata[]>[];
    getEntityRelationsMetadata<T>(parentEntity: T): CompositeRelationMetadata[];
    getCompositeRelationMetadata(parentEntity: string, relationName: string): CompositeRelationMetadata;
    addEntityRelationMetadata(parentEntity: string, relationName: string, relationType: EntityRelationType, deleteStrategy: string): void;
    createCompositeRelationMetadata(relationName: string, parentEntity: string, relationType: EntityRelationType, deleteStrategy: string): CompositeRelationMetadata;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class ComponentRegistrationHandler {
    static readonly instance: ComponentRegistrationHandler;
    private componentValidators_;
    private domainControllers_;
    private constructor();
    get componentValidators(): ApplicationValidator[];
    get domainControllers(): ApplicationDomainController[];
    registerAverosValidator(validatorClassName: string, lookupFunction: Function): void;
    getValidator(validatorName: string): any;
    registerDomainController(domainControllerClassName: string, lookupFunction: Function): void;
    getDomainController(domainControllerName: string): any;
}
declare class ApplicationValidator {
    validatorName: string;
    validatorLookup: Function;
    description: string;
    constructor(validator: any, lookup: Function, description?: string);
}
declare class ApplicationDomainController {
    domainControllerName: string;
    domainControllerLookup: Function;
    description: string;
    constructor(validator: any, lookup: Function, description?: string);
}

declare class SelectivePreloadingStrategyService implements PreloadingStrategy {
    preloadedModules: string[];
    preload(route: Route, load: () => Observable<any>): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectivePreloadingStrategyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SelectivePreloadingStrategyService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare function OneToMany(itemClassName: string, importedClass: any, deleteStrategy?: string): Function;
declare function OneToOne(targetClassName: any, importedClass: any, deleteStrategy?: string): Function;
declare function ManyToOne(targetClassName: any, importedClass: any): Function;
declare function AverosEntity(entityCustomService?: any): (target: object) => void;
declare function AverosValidator(validatorClassName: string): (target: object) => void;
declare function DomainController(domainControllerClassName: string): (target: object) => void;
/**
 * adds getIdName() to the class in order to retrieve the class id name as defined by user.
 * Default id name = '_entityId'.
 * If both a member called '_entityId' and a @ID decorated member (let's say 'id') exists then the identifier that will
 * be applied is '_entityId'.
 * In order to customize your identifier, avoid using the '_entityId' notation along with other customized id.
 *
 */
declare function ID(): Function;
/**
 * adds a function called getBusinessIdName() to the entity class in order to retrieve the business id name as defined by user.
 * If other member than the default one "_entityLogicalName" is declared as BusinessID() then the new member will override the default one
 */
declare function BusinessID(): Function;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class ServiceLocator {
    static injector: Injector;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum LanguageCode {
    AR = "ar",
    CN = "cn",
    EN = "en",
    ES = "es",
    FR = "fr",
    DE = "de",
    JP = "jp",
    NL = "nl",
    NO = "no",
    RU = "ru",
    SE = "se"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum AuthenticationProvider {
    CUSTOM = "custom",
    DUMMY = "dummy",
    FIREBASE = "firebase",
    KEYCLOAK = "keycloak",
    GOOGLE = "google"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:averos-config --id=Test2Service --type=service --host=localhost --port=8980 --protocol=http --end-point=/test/test
 * ng g @wiforge/averos:averos-config --type=gateway --host=localhost1 --port=8981 --protocol=https
 */

interface AverosConfiguration {
    name: string;
    type: EnvironmentConfigurationType;
    id: string;
}
declare class ServiceConfiguration implements AverosConfiguration {
    name: string;
    type: EnvironmentConfigurationType;
    id: string;
    apiHost?: string;
    apiPort?: number;
    apiProtocol?: ApiProtocol;
    apiEndPoint?: string;
    apiHTTPQueryBuilder?: ApiHTTPQueryBuilder;
    externalEntityId?: string;
}
declare class GatewayConfiguration implements AverosConfiguration {
    name: string;
    type: EnvironmentConfigurationType;
    id: string;
    gatewayHost?: string;
    gatewayPort?: number;
    gatewayProtocol?: ApiProtocol;
    apiEndpoints: ApiEndpoint$1[];
    externalEntityId?: string;
}
declare class ApiEndpoint$1 {
    id: string;
    endpoint: string;
    queryBuilder?: ApiHTTPQueryBuilder;
    externalEntityId?: string;
}
declare enum ApiProtocol {
    HTTP = "http",
    HTTPS = "https"
}
declare enum ApiHTTPQueryBuilder {
    REGULAR = "regular",
    JSON_SERVER = "json-server",
    MONGODB = "mongodb",
    CUSTOM = "custom"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum MemberNature {
    SIMPLE = "simple",// simple member
    COMPOSITE = "composite"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask --mname=simpleStringField --member-type=string
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask --mname=taskStatus --memberType=enumeration --list-of-enum-values=closed,active,pending
 * ng g @wiforge/averos:add-composite-member --ename=MyEntity --fename=MyChildEntity --field-relation-type=ManyToOne
 */

declare class AverosMember {
    ename: string;
    memberNature: MemberNature;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:averos-entity --name=TestEntity   // default --sname = TestEntityService
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask --mname=simpleStringField --memberType=string
 */

declare class AEntity {
    name: string;
    sname: string;
    members: AverosMember[];
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum AverosSpace {
    PRIVATE = "logged",
    PUBLIC = "public"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum TargetMenu {
    SIDE = "side",
    TOP = "top",
    BOTH = "both"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:create-page --name=MyPage --update-route-menu --target-menu=both --space=public
 */

declare class AverosPage {
    name: string;
    updateRouteMenu: boolean;
    targetMenu: TargetMenu;
    targetSpace: AverosSpace;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:averos-service --name=TestEntity --ename=TestEntity
 */
declare class AverosService {
    name: string;
    ename: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum UseCaseType {
    CREATE_Entity = "Create_Entity",// create-entity-uc 
    SEARCH_ENTITY = "Search_Entity",// search-entity-uc
    CRUD = "CRUD"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * Resulting Workflow Command Call Example:
 *
 * ng g @wiforge/averos:create-entity-uc --name=CreateMyEntity --ename=MyEntity  (--sname=MyEntityService // (default sname == MyEntityService))
 * ng g @wiforge/averos:search-entity-uc --name=SearchMyEntity --ename=MyEntity  (--sname=MyEntityService // (default sname == MyEntityService))
 * ng g @wiforge/averos:advanced-crud --ename=MyEntity --sname=MyEntityService   (--sname=MyEntityService // (default sname == MyEntityService))
 *
 */

declare class AverosUseCase {
    name: string;
    ename: string;
    useCaseType: UseCaseType;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class AverosEntityFieldMapping {
    name: string;
    ename: string;
    mapping: FieldMappingRecord[];
}
declare class FieldMappingRecord {
    fieldKey: string;
    mapTo: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosAuthenticationProvider {
    id: string;
    name: string;
    providerType: AverosAuthProviderType;
    config: AverosAuthProviderConfigEntry[];
}
declare class AverosAuthProviderConfigEntry {
    key: string;
    value: string | number | boolean;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare class AverosHttpAuthConfig {
    name: string;
    tokenHeader?: string;
    tokenPrefix?: string;
    publicRoutes?: string[];
    unauthorizedRedirect?: string;
    withCredentials?: boolean;
    maxRefreshRetries?: number;
    constructor();
}
/**
 * Default HTTP authentication configuration values.
 * Used when no custom configuration is provided.
 */
declare const DEFAULT_AVEROS_HTTP_AUTH_CONFIG: {
    tokenHeader: string;
    tokenPrefix: string;
    publicRoutes: any[];
    unauthorizedRedirect: string;
    withCredentials: boolean;
    maxRefreshRetries: number;
};

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 *
 * ng g @wiforge/averos:add-translation-entry --key=menu.todoarea.search --value=Recherche de domaine --lang=fr
 */
declare class AverosTranslationEntry {
    targetEntity?: string;
    localeID: string;
    localeValue: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:add-language --language-code=fr
 * ng g @wiforge/averos:add-translation-entry --key=menu.todoarea.search --value=Recherche de domaine --lang=fr
 */

declare class AverosLanguage {
    languageCode: LanguageCode;
    translationEntries?: AverosTranslationEntry[];
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 *
 *
 * Resulting Workflow Command Call Example:
 * ng new averos-io-starter --style=scss --routing --strict &&
 * cd averos-io-starter &&
 * ng add @wiforge/averos --applicationName=AverosIOStarter
 *                        --authBackendUrl=http://localhost:3000 //// this field is deprecated
 *                        --defaultLanguageCode=en
 *                        --defaults
 *                        --skip-confirmation &&
 * ng g @wiforge/averos:acrud --ename=ToDoArea &&
 * ng g @wiforge/averos:acrud --ename=ToDoTask &&
 * ng g @wiforge/averos:add-composite-member --ename=ToDoArea
 *                                           --fename=ToDoTask
 *                                           --fieldRelationType=OneToMany
 *                                           --member-update-strategy=multiple &&
 * ng g @wiforge/averos:add-composite-member --ename=ToDoTask
 *                                           --fename=ToDoArea
 *                                           --fieldRelationType=ManyToOne &&
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask
 *                                        --mname=taskStatus
 *                                        --memberType=enumeration
 *                                        --listOfEnumValues=closed,active,pending
 */

declare class AverosApplication {
    applicationId: string;
    applicationName: string;
    description: string;
    enableAuthentication: boolean;
    enableExternalEntityMapping: boolean;
    defaultAuthenticationProvider: AuthenticationProvider;
    defaultLanguageCode?: LanguageCode;
    entities: AEntity[];
    services: AverosService[];
    serviceConfigurations: ServiceConfiguration[] | GatewayConfiguration[];
    useCases: AverosUseCase[];
    blankPages: AverosPage[];
    languages: AverosLanguage[];
    fieldMappings: AverosEntityFieldMapping[];
    authentication: AverosAuthenticationProvider[];
    httpAuthConfig: AverosHttpAuthConfig;
    exportedApplicationData?: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum AverosEntityRelationDeleteStrategy {
    KEEP_CHILDREN = "keep-children",// default
    DELETE_CHILDREN = "delete-children"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum AverosRelationType {
    ONE_TO_ONE = "OneToOne",
    ONE_TO_MANY = "OneToMany",
    MANY_TO_ONE = "ManyToOne"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:add-composite-member --ename=MyEntity --fename=MyChildEntity --fieldRelationType=ManyToOne
 */

declare class AverosCompositeMember extends AverosMember {
    memberNature: MemberNature;
    fename: string;
    memberName: string;
    fieldRelationType: AverosRelationType;
    deleteStrategy: AverosEntityRelationDeleteStrategy | string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum AverosTag {
    ID = "ID",
    BUSINESSID = "BusinessID"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask --mname=simpleStringField --memberType=string
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask --mname=taskStatus --memberType=enumeration --listOfEnumValues=closed,active,pending
 */
declare enum AverosType {
    ENUMERATION = "enumeration",
    STRING = "string",
    NUMBER = "number",
    BOOLEAN = "boolean",
    DATE = "date",
    TEXTAREA = "textarea",
    PASSWORD = "password",
    PHONE = "phone"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 *
 * Resulting Workflow Command Call Example:
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask --mname=simpleStringField --memberType=string
 * ng g @wiforge/averos:add-simple-member --ename=ToDoTask --mname=taskStatus --memberType=enumeration --listOfEnumValues=closed,active,pending
 * ng g @wiforge/averos:add-composite-member --ename=MyEntity --fename=MyChildEntity --fieldRelationType=ManyToOne
 */

declare class AverosSimpleMember extends AverosMember {
    memberNature: MemberNature;
    mname: string;
    memberType: AverosType;
    enableTag: boolean;
    memberTag: AverosTag;
    listOfEnumValues?: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum AverosUpdateStrategy {
    SINGLE = "single",// default
    MULTIPLE = "multiple"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare type ApiEndpoint = {
    id: string;
    endpoint: string;
    queryBuilder?: string;
    externalEntityId?: string;
};
declare class GatewayConfigurationItem extends EnvironmentConfigurationItem {
    id: string;
    type: EnvironmentConfigurationType;
    gatewayHost: string;
    gatewayPort: number;
    gatewayProtocol: string;
    apiEndpoints: ApiEndpoint[];
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class RuntimeConfigurationItem extends EnvironmentConfigurationItem {
    type: EnvironmentConfigurationType;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class ResourceConfigurationItem extends EnvironmentConfigurationItem {
    type: EnvironmentConfigurationType;
    resourceLocation: string;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
declare enum EntityRelationDeleteStrategy {
    DELETE_CASCADE = "delete-children",
    KEEP_CHILDREN = "keep-children"
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

declare class AverosCodeGenService {
    private httpClient;
    private alertService;
    private environmentConfiguratorService;
    static readonly SERVICE_NAME = "AverosCodeGenService";
    get apiURL(): string;
    get apiHTTPQueryBuilder(): string;
    constructor(httpClient: HttpClient, alertService: AlertService, environmentConfiguratorService: EnvironmentConfiguratorService);
    generateApplication(averosApplication: AverosApplication): Observable<any>;
    downloadApplication(applicationID: string): Observable<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosCodeGenService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AverosCodeGenService>;
}

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */

/**
 * finds all invalid controls in an angular formGroup
 */
declare const findInvalidControls: (formGroup: FormGroup) => any[];
/**
 * checks wether the given field is simple or composite:
 * a composite field follows the pattern: field1.relation1.relation2
 * a simple filed doest not contain a '.'
 * Or is of type 'composite'
 */
declare const isCompositeField: (fieldViewLayoutItem: FieldViewLayout) => boolean;
/**
* checks wether the given field is simple or composite:
* a composite field follows the pattern: field1.relation1.relation2
* a simple filed doest not contain a '.'
* Or is of type 'composite'
*/
declare const isCompositeNavigationKey: (fieldViewLayoutItem: FieldViewLayout) => boolean;
/**
 *
 * @param entityFieldName
 * @param reactiveForm
 *
 * Gets the form control field value. Applies to both composite (field1.relation1.relation2) as well as simple fields (field1)
 */
declare const getFieldValue: (entityFieldName: string, reactiveForm: FormGroup) => any;
/**
 * Gets the composite field group name to be shown in the group label section
 */
declare const getCompositeFieldGroupName: (compositeKey: string) => string;
/**
 * Gets the field controll name from a composite field name:
 * example : composite Field = "field1.relation1.relation2"
 *           relation2 field control = "relation2"
 */
declare const getCompositeFormControlName: (fieldName: string) => string;
/**
 * Gets the fields array that is composing a composite field:
 * example: getCompositeFieldsArrayKeys("field1.relation1.relation2") = ["field1","relation1","relation2"]
 */
declare const getCompositeFieldsArrayKeys: (compositeKey: string) => string[];
/**
 * Gets a composite field related fields array lenght:
 * example: getCompositeFieldsArrayKeysLenght("field1.relation1.relation2") = 3
 */
declare const getCompositeFieldsArrayKeysLenght: (compositeKey: string) => number;
/**
 * returns wether the validationcontrol was violated or not
 */
declare const fieldValidationControlViolated: (reactiveForm: FormGroup, entityFieldName: string, validationControlName: string) => boolean;
/**
 * Translates a message using Angular's $localize with support for dynamic parameters.
 *
 * This utility transforms template literal placeholders (${param}) into Angular i18n format
 * and performs runtime translation using $localize.
 *
 * @param keyTobeTranslated - The message string with optional ${parameter} placeholders.
 *                            Use escaped template literals: \${param} to prevent early evaluation.
 * @param translationID - Optional translation identifier for looking up translations.
 *                        If omitted or empty, returns the original message.
 * @param parameterValues - Optional object mapping parameter names to their runtime values.
 *                          Keys should match the parameter names used in ${...} placeholders.
 *
 * @returns The translated and parameter-substituted string
 *
 * @example
 * // Simple message without parameters
 * translate("Hello World", "app.greeting");
 * // Returns: Translated version of "Hello World" based on translation ID
 *
 * @example
 * // Message with a single parameter
 * const entity = { name: "MyEntity_0" };
 * translate(
 *   `Entity \${entity.name} is not linked`,
 *   'app.entity.not_linked',
 *   { "entity.name": entity.name }
 * );
 * // Translation JSON: "app.entity.not_linked": "Die Entität {$PH} ist nicht verknüpft"
 * // Returns: "Die Entität MyEntity_0 ist nicht verknüpft"
 *
 * @example
 * // Message with multiple parameters
 * const user = { name: "John", count: 5, status: "active" };
 * translate(
 *   `User \${user.name} has \${user.count} items and is \${user.status}`,
 *   'app.user.status',
 *   {
 *     "user.name": user.name,
 *     "user.count": user.count,
 *     "user.status": user.status
 *   }
 * );
 * // Translation JSON: "app.user.status": "Benutzer {$PH_1} hat {$PH_2} Elemente und ist {$PH_3}"
 * // Returns: "Benutzer John hat 5 Elemente und ist active"
 *
 * @example
 * // Message without translation ID (returns original with parameter substitution)
 * translate(
 *   `Error: \${error.message}`,
 *   undefined,
 *   { "error.message": "Network timeout" }
 * );
 * // Returns: "Error: ${error.message}" (no substitution without translation ID)
 *
 * @remarks
 * Translation JSON format:
 * - Single parameter: Use {$PH} as placeholder
 * - Multiple parameters: Use {$PH_1}, {$PH_2}, {$PH_3}, etc. in order of appearance
 *
 * Important: Always escape $ in template literals: \${param} instead of ${param}
 * to prevent JavaScript from evaluating the expression before passing it to translate().
 */
declare const translate: (keyTobeTranslated: string, translationID?: string, parameterValues?: Record<string, any>) => string;
/**
 * returns an Observable UseCaseViewLayout
 */
declare const getUseCaseViewLayout: (type: any, useCase: UseCase) => Observable<UseCaseViewLayout<typeof type>>;
declare const getDefaultUserProfileLanguage: () => string;
declare const getBooleanValue: (sourceValue: any) => boolean;
declare const normalizeAverosMenuFieldsBooleanValues: (averosMenu: ApplicationNavigationItem[]) => ApplicationNavigationItem[];
/**
 * takes a collection {id: string}[] and replaces entity_id key by api_id key
 * example:
 *    entity_id = "myID"
 *    api_id = "external_entity_id"
 * source collection = [{myID: "1"}, {"myID": "2"}] => replaced by target collection = [{external_entity_id: "1"}, {"external_entity_id": "2"}]
 *
 * Backend APIs may deal with different ids for entities. Could be a private key in a database or a unique identifier,
 * so if your application entity unique id is different from your backend entity id then
 * you should map your application ids to the api ids so that the backend could identify the entities subject to the action.
 *
 */
declare const normalizeWithExternalEntityId: (api_id: string, cids: {
    id: string;
}[] | string[]) => any[];
/**
 * takes two collections of type {id: string}[] and merge while removing duplicate entries
 *
 *
 */
declare const mergeIDCollection: (sourceCollection: {
    id: string;
}[], addedCollection: {
    id: string;
}[], apiID: string) => {
    id: string;
}[];
/**
 * A utility helper that extract the data array from any type of api data retrieval response.
 * Api data retrieval response could be either an array of elements or a PaginatedData object.
 */
declare const retrievePaginatedData: (apiDataResponse: any[] | PaginatedData<any>) => any[];
/**
 * Converts a value to a boolean.
 * Handles actual booleans, strings like "true", "false", "yes", "no" (case-insensitive),
 * and numbers like 1 and 0.
 *
 * @param value - The input value to evaluate. Can be of any type.
 * @returns A boolean: true or false.
 */
declare const toBoolean: (value: unknown) => boolean;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file provide-averos-auth.ts
 * @description Helper function for configuring Averos authentication.
 * Supports both single and multiple auth provider configurations.
 */

/**
 * Provide Averos authentication for standalone or module-based applications.
 *
 * Supports two modes:
 * 1. Single provider mode - One auth provider
 * 2. Multi provider mode - Multiple providers with runtime switching
 *
 * @param options Configuration object with provider(s) and optional config
 * @returns Array of providers to include in application config
 *
 * @example Single Provider Mode
 * ```typescript
 * import { provideAverosAuth } from '@averos/auth';
 * import { AverosDummyAuthProvider } from '@averos/auth/providers/dummy';
 *
 * providers: [
 *   provideAverosAuth({
 *     provider: AverosDummyAuthProvider,
 *     config: {
 *       debug: true,
 *       persistState: true,
 *       networkDelay: 500,
 *       autoLoginAs: 'ADMIN'
 *     }
 *   })
 * ]
 * ```
 *
 * @example Multi Provider Mode
 * ```typescript
 * import { MyJwtAuthProvider } from './auth/jwt-provider';
 * import { GoogleAuthProvider } from './auth/google-provider';
 * import { FacebookAuthProvider } from './auth/facebook-provider';
 *
 * providers: [
 *   provideAverosAuth({
 *     defaultProvider: 'jwt',
 *     providers: [
 *       {
 *         name: 'jwt',
 *         provider: MyJwtAuthProvider,
 *         config: { apiUrl: 'https://api.example.com' }
 *       },
 *       {
 *         name: 'google',
 *         provider: GoogleAuthProvider,
 *         config: { clientId: 'YOUR_GOOGLE_CLIENT_ID' }
 *       },
 *       {
 *         name: 'facebook',
 *         provider: FacebookAuthProvider,
 *         config: { appId: 'YOUR_FACEBOOK_APP_ID' }
 *       }
 *     ],
 *     config: {
 *       debug: true,
 *       persistState: true
 *     }
 *   })
 * ]
 * ```
 */
declare function provideAverosAuth<C = {}>(options: AverosAuthProviderConfig<C>): EnvironmentProviders;
/**
 * Provide Averos authentication with custom instance.
 * Use this when you need to provide a pre-configured provider instance
 * instead of a class (advanced use case).
 *
 * Note: This only works for single provider mode.
 *
 * @param instance Pre-configured provider instance
 * @param config Optional auth service configuration
 * @returns Array of providers to include in application config
 *
 * @example
 * ```typescript
 * const customProvider = new MyCustomAuthProvider({
 *   apiUrl: 'https://api.example.com',
 *   clientId: 'my-client'
 * });
 *
 * export const appConfig: ApplicationConfig = {
 *   providers: [
 *     provideAverosAuthInstance(customProvider, {
 *       debug: true
 *     })
 *   ]
 * };
 * ```
 */
declare function provideAverosAuthInstance(instance: AverosAuthProvider, config?: AverosAuthConfig): EnvironmentProviders;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file auth.tokens.ts
 * @description Dependency injection tokens for Averos authentication system.
 */

/**
 * Injection token for the auth provider implementation.
 * Consumers must provide their implementation using this token.
 *
 * @example
 * ```typescript
 * providers: [
 *   {
 *     provide: AVEROS_AUTH_PROVIDER,
 *     useClass: MyAuthProvider
 *   }
 * ]
 * ```
 */
declare const AVEROS_AUTH_PROVIDER: InjectionToken<AverosAuthProvider>;
/**
 * Injection token for auth service configuration.
 * Optional - provides default values if not specified.
 *
 * @example
 * ```typescript
 * providers: [
 *   {
 *     provide: AVEROS_AUTH_CONFIG,
 *     useValue: {
 *       debug: true
 *     }
 *   }
 * ]
 * ```
 */
declare const AVEROS_AUTH_CONFIG: InjectionToken<AverosAuthConfig>;
/**
 * Token used to trigger the single provider registration factory during app startup.
 * Injecting this ensures the AuthProviderRegistry is populated before AverosAuthService uses it.
 */
declare const AVEROS_SINGLE_REGISTRATION: InjectionToken<null>;
/**
 * Token used to trigger the multiple provider registration factory during app startup.
 * Injecting this ensures the AuthProviderRegistry is populated before AverosAuthService uses it.
 */
declare const AVEROS_MULTI_REGISTRATION: InjectionToken<null>;

/**
 * @file dummy-credentials.interface.ts
 * @description Login credentials structure for dummy auth provider.
 * Demonstrates how providers define their authentication input format.
 */
/**
 * Credentials format for dummy provider login.
 * Different providers require different credential structures:
 * - JWT: username + password
 * - OAuth: authorization code or access token
 * - SAML: SAML assertion
 * - API Key: just the key
 * - Social: provider token
 */
interface DummyCredentials {
    /** Username or email address */
    username: string;
    /** Password (plain text - only for testing!) */
    password: string;
    /** Optional: Remember me flag (extends session duration) */
    rememberMe?: boolean;
}
/**
 * Response structure from dummy login endpoint.
 * Real providers would receive this from their auth server.
 */
interface DummyLoginResponse {
    /** Authentication token */
    token: string;
    /** Token expiration timestamp (ISO 8601) */
    expiresAt: string;
    /** Refresh token (for token renewal) */
    refreshToken?: string;
    /** User information */
    user: {
        id: string;
        username: string;
        email: string;
        displayName: string;
        roles: string[];
        permissions: string[];
    };
}
/**
 * Predefined test users for the dummy provider.
 * Makes testing and demos consistent and easy.
 */
declare const DUMMY_TEST_USERS: {
    readonly ADMIN: {
        readonly username: "admin@test.com";
        readonly password: "admin123";
        readonly description: "Administrator with full access";
    };
    readonly ADMIN2: {
        readonly username: "admin";
        readonly password: "admin123";
        readonly description: "Administrator 2 with full access";
    };
    readonly USER: {
        readonly username: "user@test.com";
        readonly password: "user123";
        readonly description: "Regular user with standard access";
    };
    readonly EDITOR: {
        readonly username: "editor@test.com";
        readonly password: "editor123";
        readonly description: "Content editor with write permissions";
    };
    readonly VIEWER: {
        readonly username: "viewer@test.com";
        readonly password: "viewer123";
        readonly description: "Read-only user";
    };
    readonly GUEST: {
        readonly username: "guest@test.com";
        readonly password: "guest123";
        readonly description: "Guest user with minimal access";
    };
};
/**
 * Type for test user keys.
 * Enables type-safe access to test users.
 */
type DummyTestUserKey = keyof typeof DUMMY_TEST_USERS;

/**
 * @file dummy-auth.config.ts
 * @description Configuration options for the dummy auth provider.
 * Demonstrates how providers can expose configuration options.
 */

/**
 * Configuration options for the dummy auth provider.
 * Real providers would have their own configuration:
 * - JWT: API endpoint, token storage location
 * - Keycloak: realm, client ID, server URL
 * - OAuth: client ID, scopes, redirect URI
 */
interface DummyAuthConfig {
    /**
     * Simulate network delay (in milliseconds).
     * Makes the dummy provider feel more realistic by adding latency.
     * Set to 0 for instant responses.
     * @default 1000
     */
    networkDelay?: number;
    /**
     * Auto-login on initialization.
     * Automatically logs in as the specified test user.
     * Useful for development/testing workflows.
     * @default undefined (no auto-login)
     */
    autoLoginAs?: DummyTestUserKey;
    /**
     * Session duration in minutes.
     * How long before tokens expire.
     * @default 60 (1 hour)
     */
    sessionDuration?: number;
    /**
     * Simulate random login failures.
     * Probability of login failure (0-1).
     * Useful for testing error handling.
     * @default 0 (never fail)
     */
    failureRate?: number;
    /**
     * Enable token refresh.
     * Whether the provider supports token refresh.
     * @default true
     */
    enableRefresh?: boolean;
    /**
     * Store tokens in localStorage.
     * If false, tokens are only stored in memory.
     * @default true
     */
    persistTokens?: boolean;
    /**
     * Custom test users.
     * Allows overriding the default test user database.
     * Format: { username: { password, roles, permissions, ... } }
     */
    customUsers?: Record<string, {
        password: string;
        roles: string[];
        permissions?: string[];
        displayName?: string;
        email?: string;
        tier?: 'free' | 'premium' | 'enterprise';
    }>;
}

/**
 * Dummy authentication provider.
 * Provides a fully functional auth system for testing and development.
 *
 * @example
 * ```typescript
 * // In app.config.ts
 * import { provideAverosAuth } from '@your-lib/auth';
 * import { AverosDummyAuthProvider } from '@your-lib/auth/providers/dummy';
 *
 * export const appConfig = {
 *   providers: [
 *     provideAverosAuth({
 *       provider: AverosDummyAuthProvider
 *     })
 *   ]
 * };
 * ```
 */
declare class AverosDummyAuthProvider extends AverosAuthProvider {
    static readonly typeName = "AverosDummyAuthProvider";
    private readonly logger;
    private config;
    private currentUser;
    private currentToken;
    private tokenIssuedAt;
    /** Observable stream of authentication state changes */
    private readonly _authState$;
    readonly authState$: Observable<AuthUser | null>;
    /** Observable stream of authentication errors */
    private readonly _authError$;
    readonly authError$: Observable<AuthError>;
    private readonly testUsers;
    /**
     * Initialize the provider.
     * Checks for existing sessions and optionally auto-logs in.
     */
    initialize(config?: AuthProviderConfig & DummyAuthConfig): Promise<AuthUser | null>;
    /**
     * Login with username and password.
     */
    login(credentials?: DummyCredentials): Promise<AuthUser | null>;
    /**
     * Logout and clear session.
     */
    logout(): Promise<void>;
    /**
     * Refresh authentication token.
     */
    refreshToken(): Promise<AuthUser | null>;
    /**
     * Get current access token.
     */
    getToken(): string | null;
    /**
     * Check if session is valid.
     */
    isSessionValid(): Promise<boolean>;
    /**
     * Get token expiration time.
     */
    getTokenExpiration(): string | null;
    /**
     * Get the token issuance time (iat claim).
     */
    getTokenIssuedAt(): string | null;
    /**
     * Check if user has role(s).
     */
    hasRole(role: string | string[], requireAll?: boolean): boolean;
    /**
     * Check if user has permission(s).
     */
    hasPermission(permission: string | string[], requireAll?: boolean): boolean;
    /**
    * Checks if the user can perform a specific action on a resource.
    * * Strategy for Dummy Provider:
    * This implementation demonstrates a flexible approach:
    * 1. Check for wildcard permission (admin has access to everything)
    * 2. Check for resource-specific permissions (resource:action format)
    * 3. Check for role-based access (certain roles get certain resources)
    * 4. Fallback to resource-only permission check
    *
    * Real providers (Keycloak, OAuth) would integrate with their
    * policy engines or permission APIs.
    *
    * @param resource The resource identifier (e.g., 'posts', 'users')
    * @param action Optional action (e.g., 'read', 'write', 'delete')
    * @returns true if user can access the resource for the given action
    */
    canAccess(resource: string, action?: string): boolean;
    /**
     * Get current roles.
     */
    getRoles(): string[];
    /**
     * Get current permissions.
     */
    getPermissions(): string[];
    /**
   * Storage keys for persisting dummy auth state
   */
    private readonly STORAGE_KEYS;
    /**
     * Persist session to localStorage.
     */
    private persistSession;
    /**
     * Restore session from localStorage.
     */
    private restoreSession;
    /**
     * Restore the issued time from localStorage.
     */
    private restoreIssuedAt;
    /**
     * Clear any persistant data related to the session.
     */
    clearSession(): void;
    /**
     * Simulate network delay (ms).
     */
    private delay;
    /**
     * Create structured auth error.
     */
    private createError;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosDummyAuthProvider, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AverosDummyAuthProvider>;
}

/**
 * @file dummy-user.interface.ts
 * @description Extended user model for the dummy auth provider.
 * Demonstrates how providers can extend the canonical AuthUser interface
 * with provider-specific fields.
 */

/**
 * Custom metadata for dummy users.
 * Providers can define their own metadata structure.
 */
interface DummyUserMetadata {
    /** Simulated user tier (for testing role-based features) */
    tier: 'free' | 'premium' | 'enterprise';
    /** Account status flags */
    isTestAccount: boolean;
    /** Simulated last login timestamp */
    lastLogin?: string;
    /** Department (for testing organizational features) */
    department?: string;
    /** Manager ID (for testing hierarchical permissions) */
    managerId?: string;
}
/**
 * Dummy user implementation.
 * Extends AuthUser with dummy-specific fields for testing purposes.
 *
 * Real providers would extend similarly with provider-specific fields:
 * - JWT Provider: might add `jti` (JWT ID), `aud` (audience)
 * - Keycloak: might add `realm`, `clientId`, `sessionState`
 * - OAuth: might add `providerId`, `accessToken`, `refreshToken`
 */
interface DummyUser extends AuthUser<DummyUserMetadata> {
    /**
     * Dummy-specific: Simulated token for this session
     * Real providers would manage tokens internally, not expose them
     */
    token?: string;
    /**
     * Dummy-specific: When this session expires
     * Demonstrates token expiration handling
     */
    expiresAt: string;
    /**
     * Strongly-typed metadata (uses generic from AuthUser)
     */
    metadata: DummyUserMetadata;
}
/**
 * Helper function to create a dummy user.
 * Demonstrates how providers might construct AuthUser instances.
 */
declare function createDummyUser(id: string, username: string, roles: string[], options?: {
    email?: string;
    displayName?: string;
    tier?: 'free' | 'premium' | 'enterprise';
    department?: string;
    permissions?: string[];
}): DummyUser;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file firebase-auth.config.ts
 * @description Configuration utilities for Firebase authentication provider.
 */

/**
 * Supported social authentication providers
 */
type FirebaseSocialProvider = 'google' | 'github' | 'facebook' | 'twitter' | 'microsoft' | 'apple';
/**
 * Firebase provider configuration
 */
interface FirebaseAuthConfig extends AuthProviderConfig {
    /** Firebase configuration object from Firebase Console */
    firebaseConfig: {
        apiKey: string;
        authDomain: string;
        projectId: string;
        storageBucket?: string;
        messagingSenderId?: string;
        appId: string;
        measurementId?: string;
    };
    /** Default provider to use if none specified */
    defaultProvider?: FirebaseSocialProvider;
    /** Enable popup blocker detection and fallback to redirect */
    enablePopupFallback?: boolean;
    /** Default scopes to request for each provider */
    defaultScopes?: Partial<Record<FirebaseSocialProvider, string[]>>;
    /** Debug mode */
    debug?: boolean;
    /** Persist tokens to localStorage */
    persistTokens?: boolean;
    /** Session duration in minutes (for expiry calculation fallback) */
    sessionDuration?: number;
}
/**
 * Merge default Firebase config with provided config
 */
declare function mergeFirebaseAuthConfig(config?: Partial<FirebaseAuthConfig>): FirebaseAuthConfig;

/**
 * @license
 * Copyright © Wiforge. All rights reserved.
 *
 * This source code is governed by the terms of the AVEROS LICENSE,
 * which can be found in the LICENSE file located at:
 * https://www.wiforge.com/averos/license
 *
 * Unauthorized use, modification, or distribution of this code is strictly prohibited.
 * Please refer to the LICENSE file for full details regarding usage permissions.
 */
/**
 * @file firebase-credentials.interface.ts
 * @description Credentials structure for Firebase authentication.
 */

/**
 * Credentials for Firebase authentication
 */
interface FirebaseCredentials {
    /** Social provider to use (google, github, facebook, etc.) */
    provider?: FirebaseSocialProvider;
    /** Additional OAuth scopes to request */
    scopes?: string[];
    /** Use redirect flow instead of popup (default: popup) */
    useRedirect?: boolean;
    /** Custom parameters for OAuth provider */
    customParameters?: Record<string, string>;
    /** Language preference for OAuth UI */
    languageCode?: string;
}

/**
 * Firebase authentication provider.
 * Provides social login via Firebase Auth.
 *
 * @example
 * ```typescript
 * // In AverosCoreModule.forRoot()
 * authProvidersConfig: {
 *   defaultProvider: 'firebase',
 *   providers: [
 *     {
 *       name: 'firebase',
 *       provider: AverosFirebaseAuthProvider,
 *       config: {
 *         firebaseConfig: {
 *           apiKey: "...",
 *           authDomain: "...",
 *           projectId: "...",
 *           appId: "..."
 *         }
 *       }
 *     }
 *   ]
 * }
 * ```
 *
 * @note Firebase package must be installed: npm install firebase
 * Firebase modules are loaded dynamically when initialize() is called
 */
declare class AverosFirebaseAuthProvider extends AverosAuthProvider {
    static readonly typeName = "AverosFirebaseAuthProvider";
    private readonly logger;
    private refreshAttempts;
    private lastRefreshAttempt;
    private readonly REFRESH_COOLDOWN_MS;
    private config;
    private app;
    private auth;
    private authStateUnsubscribe?;
    private currentUser;
    private currentToken;
    private idTokenResult;
    /** Observable stream of authentication state changes */
    private readonly _authState$;
    readonly authState$: Observable<AuthUser | null>;
    /** Observable stream of authentication errors */
    private readonly _authError$;
    readonly authError$: Observable<AuthError>;
    private readonly STORAGE_KEYS;
    /**
     * Dynamically loaded Firebase modules
     * These are loaded only when initialize() is called
     */
    private firebaseModules;
    /**
     * Load Firebase modules dynamically
     * This prevents bundling errors when Firebase is not installed
     */
    private loadFirebaseModules;
    /**
     * Initialize Firebase and restore existing session
     */
    initialize(config?: FirebaseAuthConfig): Promise<AuthUser | null>;
    /**
   * Generate a unique app name based on Firebase config
   * This ensures different Firebase projects get different app instances
   * @param config Firebase configuration
   * @returns Unique app name derived from projectId
   */
    private getAppName;
    /**
     * Login with social provider
     */
    login(credentials?: FirebaseCredentials): Promise<AuthUser | null>;
    /**
     * Logout and clear session
     */
    logout(): Promise<void>;
    /**
     * Refresh the ID token
     */
    refreshToken(): Promise<AuthUser | null>;
    /**
     * Get current ID token
     */
    getToken(): string | null;
    /**
     * Check if session is valid
     */
    isSessionValid(): Promise<boolean>;
    /**
     * Synchronous token validation with automatic refresh attempt.
     *
     * Checks token expiration and attempts refresh if:
     * - Token is expired or near expiration (within 5 minutes)
     * - Haven't exceeded max refresh retries
     *
     * @param user - The Firebase user to validate
     * @returns true if token is valid or successfully refreshed
     */
    isTokenValid(user: AuthUser): boolean;
    /**
     * Check if we should attempt a token refresh based on retry limits
     */
    private shouldAttemptRefresh;
    /**
     * Attempt to refresh the token (async background operation)
     */
    private attemptTokenRefresh;
    /**
     * Get token expiration time as ISO 8601 string
     */
    getTokenExpiration(): string | null;
    /**
     * Get token issued-at time as ISO 8601 string
     */
    getTokenIssuedAt(): string | null;
    hasRole(role: string | string[], requireAll?: boolean): boolean;
    hasPermission(permission: string | string[], requireAll?: boolean): boolean;
    canAccess(resource: string, action?: string): boolean;
    getRoles(): string[];
    getPermissions(): string[];
    /**
     * Handle authenticated Firebase user
     */
    private handleAuthUser;
    /**
     * Create appropriate Firebase auth provider
     */
    private createAuthProvider;
    /**
     * Map Firebase User to FirebaseUser
     */
    private mapToFirebaseUser;
    /**
     * Map Firebase errors to Averos error types
     */
    private mapFirebaseError;
    /**
     * Create structured auth error
     */
    private createError;
    /**
     * Clear all authentication state
     */
    private clearAuthState;
    /**
     * Persist session to localStorage
     */
    private persistSession;
    /**
     * Clear persisted session
     */
    clearSession(): void;
    /**
     * Cleanup subscriptions (called by framework if provider is destroyed)
     */
    ngOnDestroy?(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosFirebaseAuthProvider, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AverosFirebaseAuthProvider>;
}

/**
 * Keycloak provider configuration
 */
interface KeycloakAuthConfig extends AuthProviderConfig {
    /**
     * Keycloak server URL
     * @example 'https://keycloak.example.com'
     */
    url: string;
    /**
     * Keycloak realm name
     * @example 'my-app-realm'
     */
    realm: string;
    /**
     * Keycloak client ID
     * @example 'my-angular-app'
     */
    clientId: string;
    /**
     * Initialize Keycloak on app load
     * @default true
     */
    initOnLoad?: boolean;
    /**
     * Check login iframe for SSO
     * @default true
     */
    checkLoginIframe?: boolean;
    /**
     * Check login iframe interval in seconds
     * @default 5
     */
    checkLoginIframeInterval?: number;
    /**
     * Enable PKCE (Proof Key for Code Exchange)
     * Recommended for public clients
     * @default true
     */
    enablePkce?: boolean;
    /**
     * Token minimum validity in seconds before refresh
     * @default 70
     */
    minValidity?: number;
    /**
     * Post-login redirect URI
     * @default window.location.origin
     */
    redirectUri?: string;
    /**
     * Post-logout redirect URI
     * @default window.location.origin
     */
    postLogoutRedirectUri?: string;
    /**
     * Silent check SSO redirect URI
     * @default window.location.origin + '/silent-check-sso.html'
     */
    silentCheckSsoRedirectUri?: string;
    /**
     * Flow type for authentication
     * @default 'standard'
     */
    flow?: 'standard' | 'implicit' | 'hybrid';
    /**
     * Response mode
     * @default 'fragment'
     */
    responseMode?: 'query' | 'fragment';
    /**
     * Enable automatic token refresh
     * @default true
     */
    enableTokenRefresh?: boolean;
    /**
     * Custom scope to request
     * @default 'openid profile email'
     */
    scope?: string;
    /**
     * Debug mode
     * @default false
     */
    debug?: boolean;
    /**
     * Whether to load user profile on initialization
     * @default true
     */
    loadUserProfileOnInit?: boolean;
    /**
     * Custom adapter (advanced usage)
     */
    adapter?: 'default' | 'cordova' | 'cordova-native';
}
/**
 * Merge default Keycloak config with provided config
 */
declare function mergeKeycloakConfig(config?: Partial<KeycloakAuthConfig>): KeycloakAuthConfig;

/**
 * Keycloak authentication provider for enterprise SSO.
 * Implements OpenID Connect (OIDC) with Keycloak server.
 *
 * @example
 * ```typescript
 * // In AverosCoreModule.forRoot()
 * authProvidersConfig: {
 *   defaultProvider: 'keycloak',
 *   providers: [
 *     {
 *       name: 'keycloak',
 *       provider: AverosKeycloakAuthProvider,
 *       config: {
 *         url: 'https://keycloak.example.com',
 *         realm: 'my-realm',
 *         clientId: 'my-client'
 *       }
 *     }
 *   ]
 * }
 * ```
 *
 * @note Keycloak package must be installed: npm install keycloak-js
 * Keycloak modules are loaded dynamically when initialize() is called
 *
 */
declare class AverosKeycloakAuthProvider extends AverosAuthProvider {
    static readonly typeName = "AverosKeycloakAuthProvider";
    private readonly logger;
    private readonly router;
    /**
     * Dynamically loaded Keycloak module
     * This is loaded only when initialize() is called
     */
    private KeycloakConstructor?;
    /**
     * Load Keycloak module dynamically
     * This prevents bundling errors when Keycloak is not installed
     */
    private loadKeycloakModule;
    private config;
    private keycloak;
    private refreshInterval?;
    private currentUser;
    /** Observable stream of authentication state changes */
    private readonly _authState$;
    readonly authState$: Observable<AuthUser | null>;
    /** Observable stream of authentication errors */
    private readonly _authError$;
    readonly authError$: Observable<AuthError>;
    private readonly STORAGE_KEYS;
    /**
     * Initialize Keycloak and restore existing session
     * This is where Keycloak module is dynamically loaded
     */
    initialize(config?: KeycloakAuthConfig): Promise<AuthUser | null>;
    /**
     * Login with Keycloak
     */
    login(credentials?: {
        loginHint?: string;
        prompt?: 'none' | 'login' | 'consent';
        maxAge?: number;
        locale?: string;
        scope?: string;
    }): Promise<AuthUser | null>;
    /**
     * Perform direct grant authentication with Keycloak
     * (Resource Owner Password Credentials flow)
     */
    private directGrantLogin;
    /**
     * Manually set tokens in Keycloak instance after direct grant
     */
    private setKeycloakTokens;
    /**
     * Parse JWT token to extract claims
     */
    private parseJwt;
    /**
     * Logout and clear session
     */
    logout(): Promise<void>;
    /**
     * Refresh the access token
     */
    refreshToken(): Promise<AuthUser | null>;
    /**
     * Get current access token
     */
    getToken(): string | null;
    /**
     * Check if session is valid
     */
    isSessionValid(): Promise<boolean>;
    /**
     * Get token expiration time as ISO 8601 string
     */
    getTokenExpiration(): string | null;
    /**
     * Get token issued-at time as ISO 8601 string
     */
    getTokenIssuedAt(): string | null;
    /**
     * Validate token (Keycloak manages this internally)
     */
    isTokenValid(user: AuthUser): boolean;
    /**
     * Clear session data from storage
     */
    clearSession(): void;
    hasRole(role: string | string[], requireAll?: boolean): boolean;
    hasPermission(permission: string | string[], requireAll?: boolean): boolean;
    canAccess(resource: string, action?: string): boolean;
    getRoles(): string[];
    getPermissions(): string[];
    navigateToLogin(): void;
    navigateAfterLogin(returnUrl?: string): void;
    navigateAfterLogout(): void;
    /**
     * Load user profile from Keycloak
     */
    private loadUserProfile;
    /**
     * Map Keycloak profile to KeycloakUser
     */
    private mapKeycloakUser;
    /**
     * Set up automatic token refresh before expiration
     */
    private setupTokenRefresh;
    /**
     * Clear token refresh interval
     */
    private clearTokenRefresh;
    /**
     * Set up token expiration handler
     */
    private setupTokenExpirationHandler;
    /**
     * Map Keycloak errors to Averos error types
     */
    private mapKeycloakError;
    /**
     * Create structured auth error
     */
    private createError;
    /**
     * Clear all authentication state
     */
    private clearAuthState;
    /**
     * Persist session to localStorage
     */
    private persistSession;
    /**
     * Clear persisted session
     */
    private clearStoredSession;
    /**
     * Debug logging
     */
    private log;
    /**
     * Error logging
     */
    private logError;
    /**
     * Cleanup subscriptions (called by framework if provider is destroyed)
     */
    ngOnDestroy?(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AverosKeycloakAuthProvider, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AverosKeycloakAuthProvider>;
}

/**
 * Keycloak-specific user extending base AuthUser
 */
interface KeycloakUser extends AuthUser<KeycloakUserMetadata> {
    /** Keycloak subject ID */
    sub: string;
    /** Token expiration time (ISO 8601) */
    expiresAt: string;
    /** Token issuance time (ISO 8601) */
    issuedAt: string;
    /** Current access token */
    token?: string;
    /** Refresh token */
    refreshToken?: string;
    /** ID token (OpenID Connect) */
    idToken?: string;
    /** Strongly-typed metadata */
    metadata: KeycloakUserMetadata;
}
/**
 * Custom metadata for Keycloak users
 */
interface KeycloakUserMetadata {
    /** Keycloak realm */
    realm: string;
    /** Keycloak session state */
    sessionState?: string;
    /** Resource access (client-specific roles) */
    resourceAccess?: Record<string, {
        roles: string[];
    }>;
    /** Realm access (realm-level roles) */
    realmAccess?: {
        roles: string[];
    };
    /** Token type (usually 'Bearer') */
    tokenType?: string;
    /** Allowed origins for CORS */
    allowedOrigins?: string[];
    /** Scope granted */
    scope?: string;
    /** Whether email is verified */
    emailVerified?: boolean;
    /** User's preferred username */
    preferredUsername?: string;
    /** User's given name */
    givenName?: string;
    /** User's family name */
    familyName?: string;
}

export { AEntity, AVEROS_AUTH_CONFIG, AVEROS_AUTH_FLOWS, AVEROS_AUTH_PROVIDER, AVEROS_AUTH_PROVIDER_METADATA, AVEROS_CONFIG, AVEROS_MULTI_REGISTRATION, AVEROS_SINGLE_REGISTRATION, AboutComponent, AccordionAnchorDirective, AccordionDirective, AccordionLinkDirective, AccountVerifiedGuard, AlertService, AnimatedIconComponent, ApplicationDomainController, ApplicationMenuService, ApplicationNavigationItem, ApplicationSharedService, ApplicationValidator, AuthErrorType, AuthenticationGuard, AuthenticationProvider, AuthenticationService, AvCrudService, AvService, AverosAppNotificationComponent, AverosApplication, AverosApplicationComponent, AverosAuthProvider, AverosAuthProviderType, AverosAuthService, AverosAvatarSelectionDialogComponent, AverosCodeGenService, AverosCompositeMember, AverosConfig, AverosCoreModule, AverosCreateEntityComponent, AverosCreateEntityDialogComponent, AverosCriteria, AverosDialogViewConfig, AverosDummyAuthProvider, AverosDynamicCompositeViewComponent, AverosDynamicDialogComponent, AverosDynamicSimpleViewComponent, AverosDynamicStepperComponent, AverosDynamicTableComponent, AverosEditEntityComponent, AverosEditEntityDialogComponent, AverosEntity, AverosEntityFieldMapping, AverosEntityRelationDeleteStrategy, AverosFirebaseAuthProvider, AverosHttpAuthConfig, AverosKeycloakAuthProvider, AverosLanguage, AverosLocalServiceCall, AverosMember, AverosMenuBodyComponent, AverosMenuComponent, AverosMenuFooterComponent, AverosMenuHeaderComponent, AverosMenuItemComponent, AverosMessageDialogComponent, AverosPage, AverosRelationType, AverosSearchComponent, AverosSearchEntityComponent, AverosSearchInputDateFieldComponent, AverosSearchInputFieldComponent, AverosSearchInputTextFieldComponent, AverosSearchOperator, AverosSearchResultComponent, AverosService, AverosSettingsComponent, AverosSettingsPanelComponent, AverosSharedModule, AverosSidemenuComponent, AverosSidemenuMenuComponent, AverosSidemenuUserpanelComponent, AverosSimpleMember, AverosSpace, AverosTicker, AverosTranslationEntry, AverosTranslationModule, AverosType, AverosUpdateStrategy, AverosUseCase, AverosValidator, AverosViewConfig, AverosViewEditEntityComponent, AverosViewEditInputFieldComponent, AverosViewEntityComponent, AverosViewEntityDialogComponent, BottomSheetDataExportFormatComponent, BrandComponent, BusinessID, CanAccessDirective, CanDeactivateGuard, ComponentRegistrationHandler, CompositeRelationMetadata, CreateViewEditUseCase, DEFAULT_AVEROS_HTTP_AUTH_CONFIG, DUMMY_TEST_USERS, DashboardCardComponent, DataExportDirective, DataExporterService, DataRetrievalMethod, DomainController, DomainEntry, EntityAlteredRelationEventData, EntityConfigurationManagerService, EntityMetaData, EntityRelationDeleteStrategy, EntityRelationType, EntityViewLayout, EnvironmentConfiguration, EnvironmentConfigurationItem, EnvironmentConfigurationType, EnvironmentConfigurator, EnvironmentConfiguratorService, FieldMappingRecord, FieldType, FieldValidator, FileService, FormControlService, GatewayConfigurationItem, GithubComponent, HasPermissionDirective, HasRoleDirective, HomeComponent, ID, IconThemeComponent, LanguageCode, LocalStorageService, LoggerService, LoginComponent, ManyToOne, MaterialElevationDirective, MaterialModule, MemberNature, NavigationItemTag, NotifierComponent, OneToMany, OneToOne, PaginatedData, PasswordResetComponent, PublicSpaceModule, ReferentialModule, RegisterComponent, RequestPasswordResetComponent, ResourceConfigurationItem, ResourceLoaderService, RoleGuard, RowAction, RowActionMetaData, RuntimeConfigurationItem, SafeIconDirective, SearchInputCriteria, SearchUseCase, SelectivePreloadingStrategyService, ServiceConfigurationItem, ServiceLocator, SortCollectionByPipe, TargetDomainField, TargetMenu, ToBooleanPipe, ToCompositeViewLayoutPipe, ToObservablePipe, ToTabbedViewLayoutPipe, ToViewLayoutPipe, TransformViewLayoutPipe, TranslatePipe, TranslationService, TranslatorComponent, TypeScriptTypeMetaDatatHandler, UnauthenticatedSpaceGuard, UseCase, UseCaseAction, UseCaseConfig, UseCaseDialogData, UseCaseType, UseCaseViewLayout, UserComponent, UserDashboardComponent, ValidateAccountComponent, ValidatorMetaData, ValueDomainController, ViewEventHandlerService, ViewLayoutService, ViewModule, averosAuthInterceptor, averosErrorInterceptor, averosLoadingInterceptor, averosMappingInterceptor, createDummyUser, defaultOptions, fieldValidationControlViolated, findInvalidControls, getBooleanValue, getCompositeFieldGroupName, getCompositeFieldsArrayKeys, getCompositeFieldsArrayKeysLenght, getCompositeFormControlName, getDefaultUserProfileLanguage, getFieldValue, getProviderMetadata, getUseCaseViewLayout, isCompositeField, isCompositeNavigationKey, isCredentialsProvider, isDelegatedProvider, isMultiProviderConfig, isSingleProviderConfig, mergeFirebaseAuthConfig, mergeIDCollection, mergeKeycloakConfig, normalizeAverosMenuFieldsBooleanValues, normalizeWithExternalEntityId, provideAverosAuth, provideAverosAuthInstance, provideAverosCore, retrievePaginatedData, toBoolean, translate, translationInitializer };
export type { AlertMessage, AlertType, AppSettings$1 as AppSettings, AuthError, AuthProviderConfig, AuthProviderRegistration, AuthUser, AverosAuthConfig, AverosAuthFlow, AverosAuthProviderConfig, AverosAuthProviderMetadata, CanAccessInput, CanComponentDeactivate, CompositeViewLayoutGroup, DummyCredentials, DummyLoginResponse, DummyTestUserKey, DummyUser, DummyUserMetadata, EntityClassLookupMetadata, FirebaseAuthConfig, FirebaseCredentials, FirebaseSocialProvider, FrameworkConfiguration, KeycloakAuthConfig, KeycloakUser, KeycloakUserMetadata, MultiProviderConfig, ProfileLanguage, ProviderInfo, SearchChip, SimpleGroupedViewLayout, SingleProviderConfig, TabbedViewLayout, TransformedCompositeViewLayout, TransformedSimpleViewLayoutGroup, TransformedTabbedViewLayout };
